import type { NextRequest } from "next/server"

interface RateLimitResult {
  success: boolean
  limit?: number
  remaining?: number
  reset?: number
  retryAfter?: number
}

interface RateLimitConfig {
  windowMs: number
  maxRequests: number
  skipSuccessfulRequests?: boolean
  skipFailedRequests?: boolean
}

// In-memory store for rate limiting (in production, use Redis or similar)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

const configs: Record<string, RateLimitConfig> = {
  default: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 100,
  },
  auth: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 5, // Strict limit for auth endpoints
  },
  admin: {
    windowMs: 5 * 60 * 1000, // 5 minutes
    maxRequests: 20, // Moderate limit for admin endpoints
  },
  api: {
    windowMs: 1 * 60 * 1000, // 1 minute
    maxRequests: 60, // API rate limit
  },
}

export async function rateLimit(request: NextRequest): Promise<RateLimitResult> {
  const ip = request.ip || request.headers.get("x-forwarded-for") || "unknown"
  const pathname = request.nextUrl.pathname

  // Determine rate limit config based on path
  let config = configs.default
  if (pathname.includes("/auth")) {
    config = configs.auth
  } else if (pathname.startsWith("/admin")) {
    config = configs.admin
  } else if (pathname.startsWith("/api")) {
    config = configs.api
  }

  const key = `${ip}:${pathname.split("/")[1] || "root"}`
  const now = Date.now()
  const windowStart = now - config.windowMs

  // Clean up old entries
  for (const [storeKey, data] of rateLimitStore.entries()) {
    if (data.resetTime < now) {
      rateLimitStore.delete(storeKey)
    }
  }

  const current = rateLimitStore.get(key)

  if (!current || current.resetTime < now) {
    // First request in window or window expired
    rateLimitStore.set(key, {
      count: 1,
      resetTime: now + config.windowMs,
    })

    return {
      success: true,
      limit: config.maxRequests,
      remaining: config.maxRequests - 1,
      reset: now + config.windowMs,
    }
  }

  if (current.count >= config.maxRequests) {
    // Rate limit exceeded
    return {
      success: false,
      limit: config.maxRequests,
      remaining: 0,
      reset: current.resetTime,
      retryAfter: Math.ceil((current.resetTime - now) / 1000),
    }
  }

  // Increment counter
  current.count++
  rateLimitStore.set(key, current)

  return {
    success: true,
    limit: config.maxRequests,
    remaining: config.maxRequests - current.count,
    reset: current.resetTime,
  }
}

export function clearRateLimit(ip: string, path?: string): void {
  if (path) {
    const key = `${ip}:${path.split("/")[1] || "root"}`
    rateLimitStore.delete(key)
  } else {
    // Clear all entries for this IP
    for (const key of rateLimitStore.keys()) {
      if (key.startsWith(`${ip}:`)) {
        rateLimitStore.delete(key)
      }
    }
  }
}
