import Link from "next/link"
import { ArrowLeft, FileText } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link
              href="/"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>홈으로 돌아가기</span>
            </Link>
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <span className="font-semibold text-primary">이용약관</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-3xl font-bold text-foreground">서비스 이용약관</h1>
            <p className="text-muted-foreground">시간표 최적화 서비스 이용에 관한 약관입니다.</p>
            <p className="text-sm text-muted-foreground">최종 업데이트: 2024년 1월 1일</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>제1조 (목적)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                본 약관은 시간표 최적화 서비스(이하 "서비스")를 제공하는 교무타임(이하 "회사")과 서비스를 이용하는 회원
                간의 권리, 의무 및 책임사항을 규정함을 목적으로 합니다.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제2조 (정의)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">1. "서비스"</h4>
                  <p className="text-muted-foreground ml-4">
                    회사가 제공하는 AI 기반 시간표 최적화 및 선택과목 분반 알고리즘 서비스를 의미합니다.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">2. "회원"</h4>
                  <p className="text-muted-foreground ml-4">
                    본 약관에 따라 회사와 서비스 이용계약을 체결하고 서비스를 이용하는 자를 의미합니다.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">3. "계정"</h4>
                  <p className="text-muted-foreground ml-4">
                    회원이 서비스 이용을 위해 설정한 고유한 식별자와 비밀번호의 조합을 의미합니다.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제3조 (서비스의 제공)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">1. 시간표 최적화 서비스</h4>
                  <p className="text-muted-foreground ml-4">AI 알고리즘을 활용한 최적의 시간표 생성 및 추천 서비스</p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">2. 선택과목 분반 서비스</h4>
                  <p className="text-muted-foreground ml-4">
                    학생들의 선택과목 분반을 효율적으로 배정하는 알고리즘 서비스
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">3. 데이터 관리 서비스</h4>
                  <p className="text-muted-foreground ml-4">시간표 및 학생 정보의 안전한 저장 및 관리 서비스</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제4조 (회원의 의무)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>정확하고 최신의 정보를 제공할 의무</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>계정 정보의 보안 유지 의무</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>서비스의 정상적인 운영을 방해하지 않을 의무</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>관련 법령 및 본 약관을 준수할 의무</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제5조 (개인정보 보호)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 회원의 개인정보를 보호하기 위해 개인정보처리방침을 수립하고 이를 준수합니다. 개인정보의 수집,
                이용, 제공, 보관, 파기 등에 관한 자세한 사항은 개인정보처리방침을 참조하시기 바랍니다.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제6조 (서비스 이용의 제한)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 다음 각 호에 해당하는 경우 서비스 이용을 제한하거나 중단할 수 있습니다:
              </p>
              <ul className="space-y-2 text-foreground ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-primary">1.</span>
                  <span>본 약관을 위반한 경우</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">2.</span>
                  <span>서비스의 정상적인 운영을 방해한 경우</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">3.</span>
                  <span>관련 법령을 위반한 경우</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">4.</span>
                  <span>기타 회사가 필요하다고 판단하는 경우</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제7조 (면책조항)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 천재지변, 전쟁, 기간통신사업자의 서비스 중지, 정전, 서버 다운 등 불가항력적 사유로 인한 서비스
                중단에 대해서는 책임을 지지 않습니다.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>제8조 (분쟁해결)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                본 약관과 관련하여 발생한 분쟁은 대한민국 법률에 따라 해결하며, 관할법원은 회사의 본사 소재지를 관할하는
                법원으로 합니다.
              </p>
            </CardContent>
          </Card>

          <div className="text-center pt-8">
            <p className="text-sm text-muted-foreground">
              문의사항이 있으시면{" "}
              <Link href="/contact" className="text-primary hover:underline">
                고객지원
              </Link>
              으로 연락해주세요.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
