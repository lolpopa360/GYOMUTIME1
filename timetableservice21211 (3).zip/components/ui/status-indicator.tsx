import { cn } from "@/lib/utils"
import { CheckCircle, Clock, AlertCircle, Play, XCircle } from "lucide-react"

interface StatusIndicatorProps {
  status: "pending" | "processing" | "completed" | "failed" | "error"
  size?: "sm" | "md" | "lg"
  showText?: boolean
  className?: string
}

export function StatusIndicator({ status, size = "md", showText = true, className }: StatusIndicatorProps) {
  const config = {
    pending: {
      icon: Clock,
      color: "text-blue-600",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      text: "대기중",
    },
    processing: {
      icon: Play,
      color: "text-yellow-600",
      bgColor: "bg-yellow-500/10",
      borderColor: "border-yellow-500/20",
      text: "처리중",
    },
    completed: {
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      text: "완료",
    },
    failed: {
      icon: XCircle,
      color: "text-red-600",
      bgColor: "bg-red-500/10",
      borderColor: "border-red-500/20",
      text: "실패",
    },
    error: {
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-500/10",
      borderColor: "border-red-500/20",
      text: "오류",
    },
  }

  const { icon: Icon, color, bgColor, borderColor, text } = config[status]

  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  }

  return (
    <div
      className={cn(
        "inline-flex items-center space-x-1 px-2 py-1 rounded-full border status-badge-enhanced",
        bgColor,
        borderColor,
        className,
      )}
    >
      <Icon className={cn(sizeClasses[size], color, status === "processing" && "animate-pulse")} />
      {showText && <span className={cn("text-xs font-medium", color)}>{text}</span>}
    </div>
  )
}
