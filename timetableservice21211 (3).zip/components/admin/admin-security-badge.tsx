"use client"

import { Badge } from "@/components/ui/badge"
import { Shield, AlertTriangle, CheckCircle } from "lucide-react"

interface AdminSecurityBadgeProps {
  level: "basic" | "enhanced" | "maximum"
  className?: string
}

export function AdminSecurityBadge({ level, className }: AdminSecurityBadgeProps) {
  const getConfig = () => {
    switch (level) {
      case "maximum":
        return {
          icon: Shield,
          text: "최고 보안",
          variant: "destructive" as const,
          description: "2단계 인증 + 도메인 검증",
        }
      case "enhanced":
        return {
          icon: AlertTriangle,
          text: "강화 보안",
          variant: "secondary" as const,
          description: "이메일 검증 + 강화된 비밀번호",
        }
      default:
        return {
          icon: CheckCircle,
          text: "기본 보안",
          variant: "outline" as const,
          description: "표준 인증",
        }
    }
  }

  const config = getConfig()
  const Icon = config.icon

  return (
    <Badge variant={config.variant} className={`flex items-center gap-2 ${className}`}>
      <Icon className="h-3 w-3" />
      {config.text}
    </Badge>
  )
}
