import { createServerClient } from "@/lib/supabase/server"
import { createBrowserClient } from "@/lib/supabase/client"

export interface AdminRole {
  id: string
  user_id: string
  role: "super_admin" | "admin" | "user"
  granted_by: string
  granted_at: string
  created_at: string
  updated_at: string
  profiles?: {
    name: string
    email: string
  }
}

export interface DataFile {
  id: string
  filename: string
  original_name: string
  file_path: string
  file_size: number
  file_type: string
  category: "template" | "example" | "document" | "result"
  description?: string
  uploaded_by: string
  download_count: number
  is_public: boolean
  created_at: string
  updated_at: string
}

export interface Inquiry {
  id: string
  user_id: string
  title: string
  content: string
  category: "technical" | "billing" | "feature" | "general"
  priority: "low" | "medium" | "high" | "urgent"
  status: "new" | "in_progress" | "resolved" | "closed"
  admin_response?: string
  responded_by?: string
  responded_at?: string
  created_at: string
  updated_at: string
  profiles?: {
    name: string
    email: string
  }
}

// Admin role management
export async function getUserRole(userId: string) {
  const supabase = createServerClient()

  const { data, error } = await supabase.from("admin_roles").select("role").eq("user_id", userId).single()

  if (error) return "user"
  return data?.role || "user"
}

export async function getAllAdminRoles() {
  const supabase = createServerClient()

  const { data, error } = await supabase
    .from("admin_roles")
    .select(`
      *,
      profiles (name, email)
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as AdminRole[]
}

export async function updateUserRole(userId: string, role: string, grantedBy: string) {
  const supabase = createServerClient()

  const { data, error } = await supabase
    .from("admin_roles")
    .upsert({
      user_id: userId,
      role,
      granted_by: grantedBy,
      updated_at: new Date().toISOString(),
    })
    .select()

  if (error) throw error
  return data
}

// Data file management
export async function getAllDataFiles() {
  const supabase = createBrowserClient()

  const { data, error } = await supabase.from("data_files").select("*").order("created_at", { ascending: false })

  if (error) throw error
  return data as DataFile[]
}

export async function uploadDataFile(file: File, category: string, description: string, uploadedBy: string) {
  const supabase = createBrowserClient()

  // Upload file to storage
  const filename = `${Date.now()}-${file.name}`
  const { data: uploadData, error: uploadError } = await supabase.storage.from("data-files").upload(filename, file)

  if (uploadError) throw uploadError

  // Save file metadata to database
  const { data, error } = await supabase
    .from("data_files")
    .insert({
      filename,
      original_name: file.name,
      file_path: uploadData.path,
      file_size: file.size,
      file_type: file.type,
      category,
      description,
      uploaded_by: uploadedBy,
    })
    .select()

  if (error) throw error
  return data[0] as DataFile
}

export async function deleteDataFile(fileId: string) {
  const supabase = createBrowserClient()

  // Get file info first
  const { data: fileData, error: fetchError } = await supabase
    .from("data_files")
    .select("file_path")
    .eq("id", fileId)
    .single()

  if (fetchError) throw fetchError

  // Delete from storage
  const { error: storageError } = await supabase.storage.from("data-files").remove([fileData.file_path])

  if (storageError) throw storageError

  // Delete from database
  const { error } = await supabase.from("data_files").delete().eq("id", fileId)

  if (error) throw error
}

// Inquiry management
export async function getAllInquiries() {
  const supabase = createServerClient()

  const { data, error } = await supabase
    .from("inquiries")
    .select(`
      *,
      profiles (name, email)
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as Inquiry[]
}

export async function createInquiry(inquiry: Omit<Inquiry, "id" | "created_at" | "updated_at">) {
  const supabase = createBrowserClient()

  const { data, error } = await supabase.from("inquiries").insert(inquiry).select()

  if (error) throw error
  return data[0] as Inquiry
}

export async function updateInquiry(inquiryId: string, updates: Partial<Inquiry>) {
  const supabase = createBrowserClient()

  const { data, error } = await supabase
    .from("inquiries")
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq("id", inquiryId)
    .select()

  if (error) throw error
  return data[0] as Inquiry
}

export async function respondToInquiry(inquiryId: string, response: string, respondedBy: string) {
  const supabase = createBrowserClient()

  const { data, error } = await supabase
    .from("inquiries")
    .update({
      admin_response: response,
      responded_by: respondedBy,
      responded_at: new Date().toISOString(),
      status: "resolved",
      updated_at: new Date().toISOString(),
    })
    .eq("id", inquiryId)
    .select()

  if (error) throw error
  return data[0] as Inquiry
}
