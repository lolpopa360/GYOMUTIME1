"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  updateProfile,
  type User,
} from "firebase/auth"
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore"
import { getFirebaseAuth, getFirebaseDb } from "@/lib/firebase/config"

export interface UserProfile {
  id: string
  email: string
  name: string
  role: "admin" | "user" | "super-admin"
  createdAt: Date
  lastLoginAt?: Date
  isEmailVerified: boolean
  preferences?: {
    theme: "light" | "dark" | "system"
    language: "ko" | "en"
    notifications: boolean
  }
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  logout: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>
  clearError: () => void
  isAuthenticated: boolean
  isAdmin: boolean
  isSuperAdmin: boolean
  verifyAdminAccess: (password: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({
  prompt: "select_account",
})

const ADMIN_SECONDARY_PASSWORD = "20081113"
const SUPER_ADMIN_EMAIL = "yangchanhee11@gmail.com"

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      console.error("[v0] Firebase Auth or Firestore not available")
      setError("Firebase 서비스를 초기화할 수 없습니다.")
      setIsLoading(false)
      return
    }

    console.log("[v0] Firebase Auth initialized successfully")

    try {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        console.log("[v0] Auth state changed:", user?.email)
        setUser(user)

        if (user && db) {
          try {
            const userDoc = await getDoc(doc(db, "users", user.uid))
            if (userDoc.exists()) {
              const data = userDoc.data()
              const profile: UserProfile = {
                id: user.uid,
                email: user.email || "",
                name: data.name || user.displayName || "",
                role: data.role || (user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"),
                createdAt: data.createdAt?.toDate() || new Date(),
                lastLoginAt: data.lastLoginAt?.toDate(),
                isEmailVerified: user.emailVerified,
                preferences: data.preferences || {
                  theme: "system",
                  language: "ko",
                  notifications: true,
                },
              }
              setUserProfile(profile)

              // Update last login time
              await updateDoc(doc(db, "users", user.uid), {
                lastLoginAt: new Date(),
              })
            } else {
              // Create user profile if it doesn't exist
              const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"
              const newProfile: UserProfile = {
                id: user.uid,
                email: user.email || "",
                name: user.displayName || user.email?.split("@")[0] || "",
                role,
                createdAt: new Date(),
                lastLoginAt: new Date(),
                isEmailVerified: user.emailVerified,
                preferences: {
                  theme: "system",
                  language: "ko",
                  notifications: true,
                },
              }

              await setDoc(doc(db, "users", user.uid), {
                name: newProfile.name,
                email: newProfile.email,
                role: newProfile.role,
                createdAt: newProfile.createdAt,
                lastLoginAt: newProfile.lastLoginAt,
                preferences: newProfile.preferences,
              })

              setUserProfile(newProfile)
            }
          } catch (error: any) {
            console.error("[v0] Error fetching user profile:", error)
            setError("사용자 프로필을 불러오는데 실패했습니다.")
          }
        } else {
          setUserProfile(null)
        }

        setIsLoading(false)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error("[v0] Error setting up auth listener:", error)
      setError("인증 시스템 초기화에 실패했습니다.")
      setIsLoading(false)
    }
  }, [])

  const clearError = () => setError(null)

  const verifyAdminAccess = (password: string): boolean => {
    return password === ADMIN_SECONDARY_PASSWORD
  }

  const login = async (email: string, password: string) => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      await signInWithEmailAndPassword(auth, email, password)
      console.log("[v0] Login successful")
    } catch (error: any) {
      console.error("[v0] Login error:", error)
      setError("로그인에 실패했습니다. 이메일과 비밀번호를 확인해주세요.")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithGoogle = async () => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      const result = await signInWithPopup(auth, googleProvider)
      const user = result.user

      // Check if user profile exists, create if not
      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (!userDoc.exists()) {
        const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"
        await setDoc(doc(db, "users", user.uid), {
          name: user.displayName || user.email!.split("@")[0],
          email: user.email,
          role,
          createdAt: new Date(),
          lastLoginAt: new Date(),
          preferences: {
            theme: "system",
            language: "ko",
            notifications: true,
          },
        })
      }

      console.log("[v0] Google login successful")
    } catch (error: any) {
      console.error("[v0] Google login error:", error)

      if (error.code === "auth/unauthorized-domain") {
        setError(
          "도메인 인증 오류: Firebase 콘솔에서 현재 도메인을 승인된 도메인 목록에 추가해야 합니다.\n\n" +
            "해결 방법:\n" +
            "1. Firebase 콘솔 (console.firebase.google.com)에 접속\n" +
            "2. 프로젝트 선택 → Authentication → Settings → Authorized domains\n" +
            "3. 현재 도메인을 추가: " +
            window.location.hostname +
            "\n" +
            "4. 변경사항 저장 후 다시 시도",
        )
      } else if (error.code === "auth/popup-blocked") {
        setError("팝업이 차단되었습니다. 브라우저 설정에서 팝업을 허용해주세요.")
      } else if (error.code === "auth/popup-closed-by-user") {
        setError("Google 로그인이 취소되었습니다.")
      } else {
        setError("Google 로그인에 실패했습니다. 다시 시도해주세요.")
      }
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const signUp = async (email: string, password: string, name: string) => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password)
      const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"

      await updateProfile(user, { displayName: name })

      await setDoc(doc(db, "users", user.uid), {
        name,
        email,
        role,
        createdAt: new Date(),
        lastLoginAt: new Date(),
        preferences: {
          theme: "system",
          language: "ko",
          notifications: true,
        },
      })

      console.log("[v0] Signup successful")
    } catch (error: any) {
      console.error("[v0] Signup error:", error)
      setError("회원가입에 실패했습니다. 다시 시도해주세요.")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const resetPassword = async (email: string) => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setError(null)

    try {
      await sendPasswordResetEmail(auth, email)
    } catch (error: any) {
      console.error("[v0] Password reset error:", error)
      setError("비밀번호 재설정 이메일 전송에 실패했습니다.")
      throw error
    }
  }

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user || !userProfile) return

    const db = getFirebaseDb()
    if (!db) return

    try {
      await updateDoc(doc(db, "users", user.uid), updates)
      setUserProfile({ ...userProfile, ...updates })
    } catch (error: any) {
      console.error("[v0] Profile update error:", error)
      setError("프로필 업데이트에 실패했습니다.")
      throw error
    }
  }

  const logout = async () => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    try {
      await signOut(auth)
      console.log("[v0] Logout successful")
    } catch (error: any) {
      console.error("[v0] Logout error:", error)
      setError("로그아웃에 실패했습니다.")
      throw error
    }
  }

  const value = {
    user,
    userProfile,
    isLoading,
    error,
    login,
    signUp,
    loginWithGoogle,
    logout,
    resetPassword,
    updateUserProfile,
    clearError,
    isAuthenticated: !!user,
    isAdmin: userProfile?.role === "admin" || userProfile?.role === "super-admin" || false,
    isSuperAdmin: userProfile?.role === "super-admin" || false,
    verifyAdminAccess,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
