import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getFirestore, type Firestore } from "firebase/firestore"
import { getStorage, type FirebaseStorage } from "firebase/storage"
import { getAnalytics, type Analytics } from "firebase/analytics"
import { getFunctions, type Functions } from "firebase/functions"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "AIzaSyDMIIfQ8P0iWVOfaVwLwF0Q3unKlAWj-04",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "gyomutime-61a6f.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "gyomutime-61a6f",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "gyomutime-61a6f.firebasestorage.app",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "863417171989",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:863417171989:web:a8d0226053509e206e8e1c",
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID || "G-DQHPYVXS97",
}

let app: FirebaseApp | null = null
let auth: Auth | null = null
let db: Firestore | null = null
let storage: FirebaseStorage | null = null
let functions: Functions | null = null
let analytics: Analytics | null = null

let isFirebaseAvailable = false

function initializeFirebase(): boolean {
  try {
    // Initialize Firebase app
    if (getApps().length === 0) {
      app = initializeApp(firebaseConfig)
      console.log("[v0] Firebase app initialized")
    } else {
      app = getApp()
    }

    // Initialize all Firebase services including Auth
    if (app) {
      auth = getAuth(app)
      db = getFirestore(app)
      storage = getStorage(app)
      functions = getFunctions(app)

      // Only initialize analytics in browser
      if (typeof window !== "undefined") {
        analytics = getAnalytics(app)
      }

      console.log("[v0] All Firebase services initialized successfully")
    }

    isFirebaseAvailable = true
    return true
  } catch (error) {
    console.error("[v0] Firebase initialization failed:", error)
    isFirebaseAvailable = false
    return false
  }
}

// Initialize Firebase on module load
initializeFirebase()

export const getFirebaseAuth = (): Auth | null => {
  if (!isFirebaseAvailable || !auth) {
    console.warn("[v0] Firebase Auth not available")
    return null
  }
  return auth
}

export const getFirebaseDb = (): Firestore | null => {
  if (!isFirebaseAvailable) {
    console.warn("[v0] Firestore not available")
    return null
  }
  return db
}

export const getFirebaseAuthSync = (): Auth | null => {
  return auth
}

export const getFirebaseDbSync = (): Firestore | null => {
  return db
}

export const getFirebaseStorage = (): FirebaseStorage | null => {
  return storage
}

export const getFirebaseFunctions = (): Functions | null => {
  return functions
}

export const getFirebaseAnalytics = (): Analytics | null => {
  return analytics
}

export const isFirebaseReady = (): boolean => {
  return isFirebaseAvailable && auth !== null && db !== null
}

export { auth, db, storage, functions, analytics }
export default app
