"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  Shield,
  ArrowRight,
  AlertTriangle,
  CheckCircle,
  Clock,
  Fingerprint,
  Smartphone,
  Key,
  Chrome,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Logo } from "@/components/ui/logo"

export default function AdminAuthPage() {
  const { login, loginWithGoogle, isLoading, error, clearError, verifyAdminAccess } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [showSecondaryPassword, setShowSecondaryPassword] = useState(false)
  const [success, setSuccess] = useState("")
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})
  const [securityLevel, setSecurityLevel] = useState<"basic" | "enhanced" | "maximum">("basic")
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [isLocked, setIsLocked] = useState(false)
  const [lockoutTime, setLockoutTime] = useState(0)
  const [authStep, setAuthStep] = useState<"login" | "secondary">("login")
  const router = useRouter()

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
    secondaryPassword: "",
    totpCode: "",
  })

  useEffect(() => {
    const attempts = localStorage.getItem("admin_login_attempts")
    const lastAttempt = localStorage.getItem("admin_last_attempt")

    if (attempts && lastAttempt) {
      const attemptCount = Number.parseInt(attempts)
      const lastAttemptTime = Number.parseInt(lastAttempt)
      const timeDiff = Date.now() - lastAttemptTime

      if (attemptCount >= 3 && timeDiff < 900000) {
        // 15 minutes lockout
        setIsLocked(true)
        setLockoutTime(900000 - timeDiff)
        setLoginAttempts(attemptCount)
      }
    }
  }, [])

  useEffect(() => {
    if (isLocked && lockoutTime > 0) {
      const timer = setInterval(() => {
        setLockoutTime((prev) => {
          if (prev <= 1000) {
            setIsLocked(false)
            setLoginAttempts(0)
            localStorage.removeItem("admin_login_attempts")
            localStorage.removeItem("admin_last_attempt")
            return 0
          }
          return prev - 1000
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [isLocked, lockoutTime])

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const isAdminEmail = (email: string) => {
    const adminDomains = ["@gyomutime.com", "@admin.gyomutime.com"]
    const adminEmails = ["yangchanhee11@gmail.com"]

    return (
      adminEmails.includes(email.toLowerCase()) || adminDomains.some((domain) => email.toLowerCase().endsWith(domain))
    )
  }

  const handleInputChange = (field: string, value: string) => {
    setLoginData({ ...loginData, [field]: value })

    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: "" })
    }
    clearError()

    if (field === "email" && value) {
      if (isAdminEmail(value)) {
        setSecurityLevel("maximum")
      } else if (validateEmail(value)) {
        setSecurityLevel("enhanced")
      } else {
        setSecurityLevel("basic")
      }
    }
  }

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    if (isLocked) {
      return
    }

    clearError()
    setValidationErrors({})

    if (authStep === "login") {
      const errors: Record<string, string> = {}

      if (!validateEmail(loginData.email)) {
        errors.email = "올바른 이메일 형식이 아닙니다."
      } else if (!isAdminEmail(loginData.email)) {
        errors.email = "관리자 도메인 이메일만 사용할 수 있습니다."
      }

      if (loginData.password.length < 8) {
        errors.password = "관리자 비밀번호는 최소 8자 이상이어야 합니다."
      }

      if (securityLevel === "maximum" && !loginData.totpCode) {
        errors.totpCode = "2단계 인증 코드가 필요합니다."
      }

      if (Object.keys(errors).length > 0) {
        setValidationErrors(errors)
        return
      }

      try {
        await login(loginData.email, loginData.password)
        setAuthStep("secondary")
        setSuccess("1차 인증 완료! 관리자 보안 비밀번호를 입력해주세요.")
      } catch (error: any) {
        const newAttempts = loginAttempts + 1
        setLoginAttempts(newAttempts)
        localStorage.setItem("admin_login_attempts", newAttempts.toString())
        localStorage.setItem("admin_last_attempt", Date.now().toString())

        if (newAttempts >= 3) {
          setIsLocked(true)
          setLockoutTime(900000) // 15 minutes
        }
      }
    } else if (authStep === "secondary") {
      if (!loginData.secondaryPassword) {
        setValidationErrors({ secondaryPassword: "관리자 보안 비밀번호를 입력해주세요." })
        return
      }

      if (!verifyAdminAccess(loginData.secondaryPassword)) {
        setValidationErrors({ secondaryPassword: "관리자 보안 비밀번호가 올바르지 않습니다." })
        const newAttempts = loginAttempts + 1
        setLoginAttempts(newAttempts)

        if (newAttempts >= 3) {
          setIsLocked(true)
          setLockoutTime(900000)
        }
        return
      }

      // Clear failed attempts on success
      localStorage.removeItem("admin_login_attempts")
      localStorage.removeItem("admin_last_attempt")

      setSuccess("관리자 인증 완료! 관리 콘솔로 이동합니다.")
      setTimeout(() => router.push("/admin"), 1500)
    }
  }

  const handleGoogleAdminLogin = async () => {
    if (isLocked) return

    try {
      await loginWithGoogle()
      setAuthStep("secondary")
      setSuccess("Google 인증 완료! 관리자 보안 비밀번호를 입력해주세요.")
    } catch (error) {
      // Error handled by auth context
    }
  }

  const getSecurityBadgeColor = () => {
    switch (securityLevel) {
      case "maximum":
        return "bg-red-500"
      case "enhanced":
        return "bg-amber-500"
      default:
        return "bg-green-500"
    }
  }

  const formatLockoutTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted via-card to-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Shield className="h-8 w-8 text-primary" />
          </div>
          <Link href="/" className="inline-block">
            <Logo size="md" />
          </Link>
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-primary font-heading">관리자 보안 인증</h1>
            <p className="text-muted-foreground text-balance">
              {authStep === "login" ? "시간표 최적화 서비스 관리자 전용 보안 로그인" : "2단계 보안 인증"}
            </p>
          </div>
        </div>

        {/* Security Level Indicator */}
        <div className="flex justify-center">
          <Badge variant="outline" className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${getSecurityBadgeColor()}`} />
            {authStep === "login" ? (
              <>보안 수준: {securityLevel === "maximum" ? "최고" : securityLevel === "enhanced" ? "강화" : "기본"}</>
            ) : (
              <>2단계 인증 진행 중</>
            )}
          </Badge>
        </div>

        {/* Admin Auth Card */}
        <Card className="admin-auth-card bounce-in">
          <CardHeader className="space-y-1 pb-6">
            <CardTitle className="text-xl text-center text-card-foreground flex items-center justify-center gap-2 font-heading">
              <Shield className="h-5 w-5" />
              {authStep === "login" ? "관리자 인증 시스템" : "보안 비밀번호 확인"}
            </CardTitle>
            <CardDescription className="text-center text-balance">
              {authStep === "login"
                ? "다단계 보안 인증을 통해 시스템을 안전하게 보호합니다"
                : "관리자 전용 보안 비밀번호를 입력해주세요"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLocked ? (
              <div className="text-center space-y-4">
                <div className="mx-auto w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center">
                  <Lock className="h-8 w-8 text-destructive" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-destructive">계정 일시 잠금</h3>
                  <p className="text-sm text-muted-foreground">보안을 위해 계정이 일시적으로 잠겼습니다.</p>
                  <div className="flex items-center justify-center gap-2 text-sm">
                    <Clock className="h-4 w-4" />
                    <span>해제까지: {formatLockoutTime(lockoutTime)}</span>
                  </div>
                </div>
                <Alert className="notification-error">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    {loginAttempts}회 연속 로그인 실패로 인해 15분간 계정이 잠겼습니다.
                  </AlertDescription>
                </Alert>
              </div>
            ) : authStep === "secondary" ? (
              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="secondary-password" className="text-sm font-medium flex items-center gap-2">
                    <Key className="h-4 w-4" />
                    관리자 보안 비밀번호
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="secondary-password"
                      type={showSecondaryPassword ? "text" : "password"}
                      placeholder="관리자 전용 보안 비밀번호"
                      className={`auth-input pl-10 pr-10 ${validationErrors.secondaryPassword ? "border-destructive focus:border-destructive" : ""}`}
                      value={loginData.secondaryPassword}
                      onChange={(e) => handleInputChange("secondaryPassword", e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowSecondaryPassword(!showSecondaryPassword)}
                      className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSecondaryPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {validationErrors.secondaryPassword && (
                    <div className="validation-error">
                      <AlertTriangle className="h-4 w-4" />
                      {validationErrors.secondaryPassword}
                    </div>
                  )}
                </div>

                <div className="bg-muted/50 border border-border/50 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-foreground">최종 보안 단계</p>
                      <p className="text-xs text-muted-foreground text-balance">
                        이 비밀번호는 관리자만 알고 있는 특별한 보안 코드입니다. 시스템의 최고 권한에 접근하기 위해
                        필요합니다.
                      </p>
                    </div>
                  </div>
                </div>

                <Button type="submit" className="auth-button-primary w-full h-12" disabled={isLoading}>
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      보안 확인 중...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Key className="h-4 w-4" />
                      관리자 권한 확인
                      <ArrowRight className="h-4 w-4" />
                    </div>
                  )}
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  className="w-full bg-transparent"
                  onClick={() => {
                    setAuthStep("login")
                    setLoginData({ ...loginData, secondaryPassword: "" })
                    setValidationErrors({})
                    clearError()
                  }}
                >
                  이전 단계로 돌아가기
                </Button>
              </form>
            ) : (
              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="admin-email" className="text-sm font-medium">
                    관리자 이메일
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="admin-email"
                      type="email"
                      placeholder="admin@gyomutime.com"
                      className={`auth-input pl-10 ${validationErrors.email ? "border-destructive focus:border-destructive" : ""}`}
                      value={loginData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      required
                    />
                  </div>
                  {validationErrors.email && (
                    <div className="validation-error">
                      <AlertTriangle className="h-4 w-4" />
                      {validationErrors.email}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="admin-password" className="text-sm font-medium">
                    관리자 비밀번호
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="admin-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="보안 비밀번호"
                      className={`auth-input pl-10 pr-10 ${validationErrors.password ? "border-destructive focus:border-destructive" : ""}`}
                      value={loginData.password}
                      onChange={(e) => handleInputChange("password", e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {validationErrors.password && (
                    <div className="validation-error">
                      <AlertTriangle className="h-4 w-4" />
                      {validationErrors.password}
                    </div>
                  )}
                </div>

                {securityLevel === "maximum" && (
                  <div className="space-y-2">
                    <Label htmlFor="totp-code" className="text-sm font-medium flex items-center gap-2">
                      <Smartphone className="h-4 w-4" />
                      2단계 인증 코드
                    </Label>
                    <div className="relative">
                      <Key className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="totp-code"
                        type="text"
                        placeholder="6자리 인증 코드"
                        className={`auth-input pl-10 text-center tracking-widest ${validationErrors.totpCode ? "border-destructive focus:border-destructive" : ""}`}
                        value={loginData.totpCode}
                        onChange={(e) => handleInputChange("totpCode", e.target.value.replace(/\D/g, "").slice(0, 6))}
                        maxLength={6}
                      />
                    </div>
                    {validationErrors.totpCode && (
                      <div className="validation-error">
                        <AlertTriangle className="h-4 w-4" />
                        {validationErrors.totpCode}
                      </div>
                    )}
                  </div>
                )}

                {/* Security Notice */}
                <div className="bg-muted/50 border border-border/50 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Fingerprint className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-foreground">고급 보안 알림</p>
                      <p className="text-xs text-muted-foreground text-balance">
                        관리자 계정은 시스템의 모든 데이터와 설정에 접근할 수 있습니다. 로그인 정보를 절대 타인과
                        공유하지 마세요.
                      </p>
                      {loginAttempts > 0 && (
                        <p className="text-xs text-amber-600">경고: {loginAttempts}/3 로그인 시도 실패</p>
                      )}
                    </div>
                  </div>
                </div>

                <Button type="submit" className="auth-button-primary w-full h-12" disabled={isLoading}>
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      보안 인증 중...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      관리자 보안 로그인
                      <ArrowRight className="h-4 w-4" />
                    </div>
                  )}
                </Button>

                <div className="auth-divider">
                  <span>또는</span>
                </div>

                <Button
                  type="button"
                  variant="outline"
                  className="auth-button-outline w-full bg-transparent"
                  onClick={handleGoogleAdminLogin}
                  disabled={isLoading}
                >
                  <Chrome className="h-4 w-4 mr-2" />
                  Google 관리자 인증
                </Button>
              </form>
            )}

            {/* Error/Success Messages */}
            {error && (
              <Alert className="mt-4 notification-error">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="mt-4 notification-success">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">
            일반 사용자이신가요?{" "}
            <Link href="/auth" className="auth-link">
              일반 로그인
            </Link>
          </p>
          <p className="text-xs text-muted-foreground">
            관리자 계정 문의:{" "}
            <Link href="/contact" className="auth-link">
              admin@gyomutime.com
            </Link>
          </p>
          <p className="text-xs text-muted-foreground text-balance">이 시스템은 다단계 보안 인증으로 보호됩니다</p>
        </div>
      </div>
    </div>
  )
}
