"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Users,
  Shield,
  FileText,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Crown,
  BarChart3,
  Database,
} from "lucide-react"
import { Logo } from "@/components/ui/logo"
import { useAuth } from "@/lib/auth-context"
import { collection, query, where, getCountFromServer } from "firebase/firestore"
import { getFirebaseDb } from "@/lib/firebase/config"

interface SidebarProps {
  className?: string
}

export function AdminSidebar({ className }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [counts, setCounts] = useState({
    users: 0,
    inquiries: 0,
    files: 0,
  })
  const pathname = usePathname()
  const { logout, userProfile } = useAuth()

  useEffect(() => {
    loadCounts()
  }, [])

  const loadCounts = async () => {
    try {
      const db = getFirebaseDb()
      if (!db) return

      const [usersSnapshot, inquiriesSnapshot, filesSnapshot] = await Promise.all([
        getCountFromServer(collection(db, "users")),
        getCountFromServer(query(collection(db, "inquiries"), where("status", "==", "new"))),
        getCountFromServer(collection(db, "data_files")),
      ])

      setCounts({
        users: usersSnapshot.data().count,
        inquiries: inquiriesSnapshot.data().count,
        files: filesSnapshot.data().count,
      })
    } catch (error) {
      console.error("[v0] Error loading sidebar counts:", error)
      // Keep counts at 0 if there's an error
    }
  }

  const navigation = [
    {
      name: "대시보드",
      href: "/admin",
      icon: LayoutDashboard,
      current: pathname === "/admin",
    },
    {
      name: "사용자 관리",
      href: "/admin/users",
      icon: Users,
      current: pathname === "/admin/users",
      badge: counts.users > 0 ? counts.users.toString() : undefined,
    },
    {
      name: "관리자 관리",
      href: "/admin/admins",
      icon: Shield,
      current: pathname === "/admin/admins",
    },
    {
      name: "파일 관리",
      href: "/admin/files",
      icon: FileText,
      current: pathname === "/admin/files",
      badge: counts.files > 0 ? counts.files.toString() : undefined,
    },
    {
      name: "문의 관리",
      href: "/admin/inquiries",
      icon: MessageSquare,
      current: pathname === "/admin/inquiries",
      badge: counts.inquiries > 0 ? counts.inquiries.toString() : undefined,
      badgeVariant: counts.inquiries > 0 ? ("destructive" as const) : undefined,
    },
    {
      name: "시스템 분석",
      href: "/admin/analytics",
      icon: BarChart3,
      current: pathname === "/admin/analytics",
    },
    {
      name: "데이터베이스",
      href: "/admin/database",
      icon: Database,
      current: pathname === "/admin/database",
    },
  ]

  return (
    <div
      className={cn(
        "flex flex-col h-full bg-card border-r border-border transition-all duration-300",
        collapsed ? "w-16" : "w-64",
        className,
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <Logo size="sm" />
            <div>
              <h2 className="text-sm font-semibold text-foreground">교무타임</h2>
              <p className="text-xs text-muted-foreground">관리자 콘솔</p>
            </div>
          </div>
        )}
        <Button variant="ghost" size="sm" onClick={() => setCollapsed(!collapsed)} className="h-8 w-8 p-0">
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon
          return (
            <Link key={item.name} href={item.href}>
              <Button
                variant={item.current ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start h-10",
                  collapsed && "justify-center px-0",
                  item.current && "bg-primary text-primary-foreground",
                )}
              >
                <Icon className={cn("h-4 w-4", !collapsed && "mr-3")} />
                {!collapsed && (
                  <>
                    <span className="flex-1 text-left">{item.name}</span>
                    {item.badge && (
                      <Badge variant={item.badgeVariant || "secondary"} className="ml-auto text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </>
                )}
              </Button>
            </Link>
          )
        })}
      </nav>

      {/* User Info & Logout */}
      <div className="p-4 border-t border-border">
        {!collapsed && (
          <div className="mb-3 p-3 bg-muted/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                {userProfile?.role === "admin" && <Crown className="h-4 w-4 text-primary" />}
                {userProfile?.role === "user" && <Users className="h-4 w-4 text-primary" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{userProfile?.name || "관리자"}</p>
                <p className="text-xs text-muted-foreground">
                  {userProfile?.role === "admin" ? "시스템 관리자" : "사용자"}
                </p>
              </div>
            </div>
          </div>
        )}

        <Button variant="outline" onClick={logout} className={cn("w-full", collapsed && "justify-center px-0")}>
          <LogOut className={cn("h-4 w-4", !collapsed && "mr-2")} />
          {!collapsed && "로그아웃"}
        </Button>
      </div>
    </div>
  )
}
