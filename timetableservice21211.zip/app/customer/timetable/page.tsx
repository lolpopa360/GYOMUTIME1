"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Logo } from "@/components/ui/logo"
import {
  Cpu,
  ArrowLeft,
  Upload,
  FileSpreadsheet,
  CheckCircle,
  Info,
  Settings,
  Clock,
  AlertTriangle,
  Network,
} from "lucide-react"

function TimetableSubmissionContent() {
  const [formData, setFormData] = useState({
    contactName: "",
    file: null as File | null,
    mondayPeriods: 7,
    tuesdayPeriods: 7,
    wednesdayPeriods: 7,
    thursdayPeriods: 7,
    fridayPeriods: 7,
    movementClassGrades: [] as string[],
    maxConsecutiveMovement: 2,
    hasTeacherExclusions: false,
    teacherExclusions: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.name.endsWith(".xlsx")) {
      setFormData((prev) => ({ ...prev, file }))
    }
  }

  const handleGradeChange = (grade: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      movementClassGrades: checked
        ? [...prev.movementClassGrades, grade]
        : prev.movementClassGrades.filter((g) => g !== grade),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.contactName || !formData.file) return

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitted(true)
      setIsLoading(false)
    }, 2000)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center space-x-3">
              <Logo size="md" />
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <div className="mx-auto mb-6 p-4 bg-primary/10 rounded-full w-fit">
              <CheckCircle className="h-12 w-12 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-4">최적화 알고리즘 실행 중</h1>
            <p className="text-lg text-muted-foreground mb-8">
              시간표 최적화 요청이 성공적으로 접수되었습니다. 고급 제약 조건 기반 알고리즘이 실행 중입니다.
            </p>
            <div className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  담당자: {formData.contactName} | 파일: {formData.file?.name} | 요일별 교시: {formData.mondayPeriods}-
                  {formData.fridayPeriods}교시
                </AlertDescription>
              </Alert>
              <Link href="/">
                <Button variant="outline">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  홈으로 돌아가기
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <Logo size="md" />
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                홈으로
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Network className="h-4 w-4" />
              <span>시간표 최적화 엔진</span>
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-4">시간표 생성 요청</h1>
            <p className="text-lg text-muted-foreground">
              고급 제약 조건을 설정하여 최적화된 시간표를 자동 생성합니다. 복잡한 스케줄링 문제를 지능형 알고리즘으로
              해결합니다.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Submission Form */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-2xl text-card-foreground flex items-center space-x-2">
                  <Settings className="h-6 w-6 text-primary" />
                  <span>시간표 제약 조건 설정</span>
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  시간표 최적화를 위한 상세 제약 조건과 파라미터를 설정해주세요.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="contactName" className="text-card-foreground">
                      담당자 이름 *
                    </Label>
                    <Input
                      id="contactName"
                      type="text"
                      placeholder="담당자 성함을 입력해주세요"
                      value={formData.contactName}
                      onChange={(e) => setFormData((prev) => ({ ...prev, contactName: e.target.value }))}
                      required
                      className="bg-input border-border text-foreground"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="file" className="text-card-foreground">
                      시간표 데이터 파일 (.xlsx) *
                    </Label>
                    <div className="relative">
                      <Input
                        id="file"
                        type="file"
                        accept=".xlsx"
                        onChange={handleFileChange}
                        required
                        className="bg-input border-border text-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
                      />
                      <Upload className="absolute right-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
                    </div>
                    {formData.file && <p className="text-sm text-primary">선택된 파일: {formData.file.name}</p>}
                  </div>

                  <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                    <h4 className="font-semibold text-card-foreground flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <span>요일별 교시 수 설정</span>
                    </h4>

                    <div className="grid grid-cols-5 gap-3">
                      <div className="space-y-2">
                        <Label className="text-xs text-card-foreground">월요일</Label>
                        <Select
                          value={formData.mondayPeriods.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, mondayPeriods: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[5, 6, 7, 8, 9].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-card-foreground">화요일</Label>
                        <Select
                          value={formData.tuesdayPeriods.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, tuesdayPeriods: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[5, 6, 7, 8, 9].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-card-foreground">수요일</Label>
                        <Select
                          value={formData.wednesdayPeriods.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, wednesdayPeriods: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[5, 6, 7, 8, 9].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-card-foreground">목요일</Label>
                        <Select
                          value={formData.thursdayPeriods.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, thursdayPeriods: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[5, 6, 7, 8, 9].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-card-foreground">금요일</Label>
                        <Select
                          value={formData.fridayPeriods.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, fridayPeriods: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[5, 6, 7, 8, 9].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                    <h4 className="font-semibold text-card-foreground flex items-center space-x-2">
                      <Network className="h-4 w-4 text-primary" />
                      <span>이동수업 연속 제한</span>
                    </h4>

                    <div className="space-y-4">
                      <div className="space-y-3">
                        <Label className="text-card-foreground">이동수업 적용 학년 선택</Label>
                        <div className="grid grid-cols-3 gap-3">
                          {["1학년", "2학년", "3학년"].map((grade) => (
                            <div key={grade} className="flex items-center space-x-2">
                              <Checkbox
                                id={grade}
                                checked={formData.movementClassGrades.includes(grade)}
                                onCheckedChange={(checked) => handleGradeChange(grade, checked as boolean)}
                              />
                              <Label htmlFor={grade} className="text-sm text-card-foreground">
                                {grade}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="maxConsecutive" className="text-card-foreground">
                          최대 연속 이동수업 교시 수
                        </Label>
                        <Select
                          value={formData.maxConsecutiveMovement.toString()}
                          onValueChange={(value) =>
                            setFormData((prev) => ({ ...prev, maxConsecutiveMovement: Number.parseInt(value) }))
                          }
                        >
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num}교시 연속
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          선택한 학년의 선택과목을 연속으로 몇 교시까지 배치할지 설정
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="teacherExclusions"
                        checked={formData.hasTeacherExclusions}
                        onCheckedChange={(checked) =>
                          setFormData((prev) => ({ ...prev, hasTeacherExclusions: checked as boolean }))
                        }
                      />
                      <Label htmlFor="teacherExclusions" className="text-card-foreground font-medium">
                        특정 교사 시간 제외 설정
                      </Label>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      특정 교사의 특정 시간대를 제외하시겠습니까? (예: 김선생님 월요일 1교시 제외)
                    </p>

                    {formData.hasTeacherExclusions && (
                      <div className="space-y-2">
                        <Label htmlFor="teacherExclusionsDetail" className="text-card-foreground">
                          교사별 제외 시간 상세 설명
                        </Label>
                        <Textarea
                          id="teacherExclusionsDetail"
                          placeholder="예: 김영희 - 월요일 1,2교시 / 박철수 - 금요일 6,7교시 / 이미영 - 수요일 전체"
                          value={formData.teacherExclusions}
                          onChange={(e) => setFormData((prev) => ({ ...prev, teacherExclusions: e.target.value }))}
                          rows={3}
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                    )}
                  </div>

                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>최적화 성능 경고:</strong> 교사 시간 제외 조건이 많을수록 최적해를 찾기 어려워집니다. 꼭
                      필요한 제외 조건만 설정하시기 바랍니다.
                    </AlertDescription>
                  </Alert>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={!formData.contactName || !formData.file || isLoading}
                  >
                    {isLoading ? "최적화 알고리즘 실행 중..." : "시간표 최적화 알고리즘 실행"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Guidelines */}
            <div className="space-y-6">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-card-foreground">
                    <FileSpreadsheet className="h-5 w-5 text-primary" />
                    <span>데이터 입력 형식</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-card-foreground">엑셀 파일 구성</h4>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>교사 정보 시트: 교사명, 담당과목, 가능시간</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>교실 정보 시트: 교실명, 수용인원, 사용가능시간</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>과목 정보 시트: 과목명, 시수, 학급별 배정</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                        <span>학급 정보 시트: 학급명, 학년, 학생수</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-card-foreground">
                    <Cpu className="h-5 w-5 text-primary" />
                    <span>최적화 알고리즘 프로세스</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">1</span>
                      </div>
                      <span className="text-sm text-muted-foreground">제약 조건 매트릭스 생성</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">2</span>
                      </div>
                      <span className="text-sm text-muted-foreground">리소스 할당 최적화 실행</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">3</span>
                      </div>
                      <span className="text-sm text-muted-foreground">충돌 검증 및 해결</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-secondary">4</span>
                      </div>
                      <span className="text-sm text-muted-foreground">최적 시간표 결과 생성</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">알고리즘 최적화 목표</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>교사-교실-시간 충돌 최소화</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>이동수업 연속성 제약 준수</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>교사 워크로드 균형 최적화</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>교실 활용도 극대화</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>처리 시간:</strong> 제약 조건 복잡도에 따라 1-24시간 소요. 복잡한 제약일수록 처리 시간이
                  증가할 수 있습니다.
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function TimetableSubmissionPage() {
  return (
    <ProtectedRoute>
      <TimetableSubmissionContent />
    </ProtectedRoute>
  )
}
