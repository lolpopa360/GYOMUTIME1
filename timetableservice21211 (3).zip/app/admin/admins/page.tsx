"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import ProtectedRoute from "@/components/auth/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Shield, Users, Crown } from "lucide-react"
import { getAllAdminRoles, updateUserRole, type AdminRole } from "@/lib/supabase/admin"
import { toast } from "@/hooks/use-toast"

export default function AdminManagement() {
  const { user } = useAuth()
  const [admins, setAdmins] = useState<AdminRole[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRole, setSelectedRole] = useState<string>("all")
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false)
  const [selectedAdmin, setSelectedAdmin] = useState<AdminRole | null>(null)
  const [newRole, setNewRole] = useState<string>("")

  useEffect(() => {
    loadAdmins()
  }, [])

  const loadAdmins = async () => {
    try {
      const data = await getAllAdminRoles()
      setAdmins(data)
    } catch (error) {
      console.error("Error loading admins:", error)
      toast({
        title: "오류",
        description: "관리자 목록을 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleRoleChange = async () => {
    if (!selectedAdmin || !newRole || !user) return

    try {
      await updateUserRole(selectedAdmin.user_id, newRole, user.id)
      await loadAdmins()
      setIsRoleDialogOpen(false)
      setSelectedAdmin(null)
      setNewRole("")
      toast({
        title: "성공",
        description: "관리자 권한이 업데이트되었습니다.",
      })
    } catch (error) {
      console.error("Error updating role:", error)
      toast({
        title: "오류",
        description: "권한 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const filteredAdmins = admins.filter((admin) => {
    const matchesSearch =
      (admin.profiles?.name?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
      (admin.profiles?.email?.toLowerCase() || "").includes(searchTerm.toLowerCase())

    const matchesRole = selectedRole === "all" || admin.role === selectedRole

    return matchesSearch && matchesRole
  })

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "super_admin":
        return (
          <Badge variant="destructive" className="gap-1">
            <Crown className="w-3 h-3" />
            슈퍼 관리자
          </Badge>
        )
      case "admin":
        return (
          <Badge variant="default" className="gap-1">
            <Shield className="w-3 h-3" />
            관리자
          </Badge>
        )
      default:
        return (
          <Badge variant="secondary" className="gap-1">
            <Users className="w-3 h-3" />
            사용자
          </Badge>
        )
    }
  }

  const stats = {
    total: admins.length,
    superAdmins: admins.filter((a) => a.role === "super_admin").length,
    admins: admins.filter((a) => a.role === "admin").length,
    users: admins.filter((a) => a.role === "user").length,
  }

  if (loading) {
    return (
      <ProtectedRoute requiredRole="super_admin">
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">로딩 중...</p>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requiredRole="super_admin">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">관리자 관리</h1>
          <p className="text-gray-600">시스템 관리자 권한을 관리합니다.</p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">전체 사용자</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">슈퍼 관리자</CardTitle>
              <Crown className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.superAdmins}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">관리자</CardTitle>
              <Shield className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.admins}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">일반 사용자</CardTitle>
              <Users className="h-4 w-4 text-gray-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-600">{stats.users}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="이름 또는 이메일로 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedRole} onValueChange={setSelectedRole}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="권한 필터" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">모든 권한</SelectItem>
              <SelectItem value="super_admin">슈퍼 관리자</SelectItem>
              <SelectItem value="admin">관리자</SelectItem>
              <SelectItem value="user">일반 사용자</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Admin List */}
        <div className="grid gap-4">
          {filteredAdmins.map((admin) => (
            <Card key={admin.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-semibold">{admin.profiles?.name?.charAt(0) || "U"}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{admin.profiles?.name || "이름 없음"}</h3>
                      <p className="text-sm text-gray-600">{admin.profiles?.email || "이메일 없음"}</p>
                      <p className="text-xs text-gray-500">
                        권한 부여일: {new Date(admin.granted_at).toLocaleDateString("ko-KR")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getRoleBadge(admin.role)}
                    <Dialog
                      open={isRoleDialogOpen && selectedAdmin?.id === admin.id}
                      onOpenChange={(open) => {
                        setIsRoleDialogOpen(open)
                        if (!open) {
                          setSelectedAdmin(null)
                          setNewRole("")
                        }
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedAdmin(admin)
                            setNewRole(admin.role)
                          }}
                        >
                          권한 변경
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>관리자 권한 변경</DialogTitle>
                          <DialogDescription>{admin.profiles?.name}님의 권한을 변경합니다.</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="role">새 권한</Label>
                            <Select value={newRole} onValueChange={setNewRole}>
                              <SelectTrigger>
                                <SelectValue placeholder="권한 선택" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="super_admin">슈퍼 관리자</SelectItem>
                                <SelectItem value="admin">관리자</SelectItem>
                                <SelectItem value="user">일반 사용자</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsRoleDialogOpen(false)}>
                            취소
                          </Button>
                          <Button onClick={handleRoleChange}>권한 변경</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredAdmins.length === 0 && (
          <div className="text-center py-12">
            <Users className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-semibold text-gray-900">관리자가 없습니다</h3>
            <p className="mt-1 text-sm text-gray-500">검색 조건에 맞는 관리자를 찾을 수 없습니다.</p>
          </div>
        )}
      </div>
    </ProtectedRoute>
  )
}
