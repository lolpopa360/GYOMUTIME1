"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Download, FileSpreadsheet, FileText, FolderOpen, Archive } from "lucide-react"
import { getUserSubmissions } from "@/lib/supabase/database"
import type { Submission } from "@/lib/supabase/database"
import { useToast } from "@/hooks/use-toast"

interface DownloadableFile {
  id: string
  name: string
  type: "excel" | "pdf" | "csv"
  size: string
  submissionId: string
  submissionTitle: string
  submissionType: "timetable" | "electives"
  completedAt: Date
  downloadCount: number
}

export default function DownloadsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [files, setFiles] = useState<DownloadableFile[]>([])
  const [filteredFiles, setFilteredFiles] = useState<DownloadableFile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [submissionTypeFilter, setSubmissionTypeFilter] = useState<string>("all")

  useEffect(() => {
    loadDownloads()
  }, [user])

  useEffect(() => {
    filterFiles()
  }, [files, searchTerm, typeFilter, submissionTypeFilter])

  const loadDownloads = async () => {
    if (!user) return

    try {
      const userSubmissions = await getUserSubmissions(user.id)
      const completedSubmissions = userSubmissions.filter((s) => s.status === "completed")
      setSubmissions(completedSubmissions)

      const downloadableFiles: DownloadableFile[] = completedSubmissions.flatMap((submission) => {
        const baseFiles: DownloadableFile[] = []

        if (submission.type === "timetable") {
          baseFiles.push(
            {
              id: `${submission.id}-excel`,
              name: `${submission.title}_시간표.xlsx`,
              type: "excel",
              size: "2.4 MB",
              submissionId: submission.id!,
              submissionTitle: submission.title,
              submissionType: submission.type,
              completedAt: submission.completed_at
                ? new Date(submission.completed_at)
                : new Date(submission.updated_at),
              downloadCount: Math.floor(Math.random() * 5),
            },
            {
              id: `${submission.id}-pdf`,
              name: `${submission.title}_시간표_보고서.pdf`,
              type: "pdf",
              size: "1.8 MB",
              submissionId: submission.id!,
              submissionTitle: submission.title,
              submissionType: submission.type,
              completedAt: submission.completed_at
                ? new Date(submission.completed_at)
                : new Date(submission.updated_at),
              downloadCount: Math.floor(Math.random() * 3),
            },
          )
        } else {
          baseFiles.push(
            {
              id: `${submission.id}-excel`,
              name: `${submission.title}_분반결과.xlsx`,
              type: "excel",
              size: "1.9 MB",
              submissionId: submission.id!,
              submissionTitle: submission.title,
              submissionType: submission.type,
              completedAt: submission.completed_at
                ? new Date(submission.completed_at)
                : new Date(submission.updated_at),
              downloadCount: Math.floor(Math.random() * 4),
            },
            {
              id: `${submission.id}-csv`,
              name: `${submission.title}_분반데이터.csv`,
              type: "csv",
              size: "0.8 MB",
              submissionId: submission.id!,
              submissionTitle: submission.title,
              submissionType: submission.type,
              completedAt: submission.completed_at
                ? new Date(submission.completed_at)
                : new Date(submission.updated_at),
              downloadCount: Math.floor(Math.random() * 2),
            },
          )
        }

        return baseFiles
      })

      setFiles(downloadableFiles)
    } catch (error) {
      console.error("Error loading downloads:", error)
      toast({
        title: "오류",
        description: "다운로드 목록을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterFiles = () => {
    let filtered = files

    if (searchTerm) {
      filtered = filtered.filter(
        (file) =>
          file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          file.submissionTitle.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter((file) => file.type === typeFilter)
    }

    if (submissionTypeFilter !== "all") {
      filtered = filtered.filter((file) => file.submissionType === submissionTypeFilter)
    }

    setFilteredFiles(filtered)
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "excel":
        return <FileSpreadsheet className="h-5 w-5 text-green-600" />
      case "pdf":
        return <FileText className="h-5 w-5 text-red-600" />
      case "csv":
        return <FileText className="h-5 w-5 text-blue-600" />
      default:
        return <FileText className="h-5 w-5 text-muted-foreground" />
    }
  }

  const getFileTypeBadge = (type: string) => {
    switch (type) {
      case "excel":
        return (
          <Badge variant="secondary" className="bg-green-500/10 text-green-600">
            EXCEL
          </Badge>
        )
      case "pdf":
        return (
          <Badge variant="secondary" className="bg-red-500/10 text-red-600">
            PDF
          </Badge>
        )
      case "csv":
        return (
          <Badge variant="secondary" className="bg-blue-500/10 text-blue-600">
            CSV
          </Badge>
        )
      default:
        return <Badge variant="outline">{type.toUpperCase()}</Badge>
    }
  }

  const getSubmissionTypeBadge = (type: string) => {
    return type === "timetable" ? (
      <Badge variant="outline">시간표 최적화</Badge>
    ) : (
      <Badge variant="outline">선택과목 분반</Badge>
    )
  }

  const handleDownload = (file: DownloadableFile) => {
    toast({
      title: "다운로드 시작",
      description: `${file.name} 파일을 다운로드합니다.`,
    })

    console.log(`Downloading: ${file.name}`)
  }

  const totalFiles = files.length
  const totalSize = files.reduce((acc, file) => {
    const size = Number.parseFloat(file.size.split(" ")[0])
    return acc + size
  }, 0)

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">다운로드 목록을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground">문서 다운로드</h1>
          <p className="text-muted-foreground">완료된 작업의 결과 파일을 다운로드하고 관리하세요</p>
        </div>

        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            {totalFiles}개 파일
          </Badge>
          <Badge variant="outline">총 {totalSize.toFixed(1)} MB</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">총 파일</p>
                <p className="text-2xl font-bold text-primary">{totalFiles}</p>
              </div>
              <FolderOpen className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Excel 파일</p>
                <p className="text-2xl font-bold text-green-600">{files.filter((f) => f.type === "excel").length}</p>
              </div>
              <FileSpreadsheet className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">PDF 파일</p>
                <p className="text-2xl font-bold text-red-600">{files.filter((f) => f.type === "pdf").length}</p>
              </div>
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">총 용량</p>
                <p className="text-2xl font-bold text-primary">{totalSize.toFixed(1)} MB</p>
              </div>
              <Archive className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="파일 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="파일 형식" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 형식</SelectItem>
                <SelectItem value="excel">Excel</SelectItem>
                <SelectItem value="pdf">PDF</SelectItem>
                <SelectItem value="csv">CSV</SelectItem>
              </SelectContent>
            </Select>

            <Select value={submissionTypeFilter} onValueChange={setSubmissionTypeFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="작업 유형" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 유형</SelectItem>
                <SelectItem value="timetable">시간표 최적화</SelectItem>
                <SelectItem value="electives">선택과목 분반</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {filteredFiles.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>다운로드 가능한 파일</CardTitle>
            <CardDescription>{filteredFiles.length}개의 파일이 있습니다</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>파일명</TableHead>
                    <TableHead>형식</TableHead>
                    <TableHead>작업 유형</TableHead>
                    <TableHead>크기</TableHead>
                    <TableHead>완료일</TableHead>
                    <TableHead>다운로드</TableHead>
                    <TableHead>작업</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredFiles.map((file) => (
                    <TableRow key={file.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          {getFileIcon(file.type)}
                          <div>
                            <p className="font-medium">{file.name}</p>
                            <p className="text-sm text-muted-foreground">{file.submissionTitle}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{getFileTypeBadge(file.type)}</TableCell>
                      <TableCell>{getSubmissionTypeBadge(file.submissionType)}</TableCell>
                      <TableCell className="font-mono text-sm">{file.size}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {file.completedAt.toLocaleDateString("ko-KR")}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {file.downloadCount}회
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleDownload(file)}
                          className="bg-primary hover:bg-primary/90"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          다운로드
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <FolderOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">다운로드 가능한 파일이 없습니다</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || typeFilter !== "all" || submissionTypeFilter !== "all"
                ? "검색 조건에 맞는 파일이 없습니다"
                : "완료된 작업이 없어 다운로드할 파일이 없습니다"}
            </p>
            <Button asChild>
              <a href="/customer/timetable">새 작업 시작하기</a>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
