import { initializeApp } from "firebase/app"
import { getFirestore, collection, addDoc, Timestamp } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyDMIIfQ8P0iWVOfaVwLwF0Q3unKlAWj-04",
  authDomain: "gyomutime-61a6f.firebaseapp.com",
  projectId: "gyomutime-61a6f",
  storageBucket: "gyomutime-61a6f.firebasestorage.app",
  messagingSenderId: "863417171989",
  appId: "1:863417171989:web:a8d0226053509e206e8e1c",
  measurementId: "G-DQHPYVXS97",
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

async function seedSampleData() {
  console.log("[v0] Seeding sample data...")

  try {
    const sampleSubmissions = [
      {
        userId: "sample-user-1",
        title: "2024년 1학기 시간표 최적화",
        description: "수학과 1학년 필수과목 중심으로 시간표를 생성해주세요.",
        status: "completed",
        type: "timetable",
        data: {
          courses: ["MATH101", "PHYS101", "ENG101"],
          preferences: {
            preferredDays: ["월", "화", "수", "목"],
            avoidEarlyMorning: true,
            maxGapHours: 2,
          },
        },
        completedAt: new Date(),
      },
      {
        userId: "sample-user-2",
        title: "교양선택 과목 추천",
        description: "인문학 계열 교양선택 과목을 추천해주세요.",
        status: "processing",
        type: "electives",
        data: {
          interests: ["문학", "역사", "철학"],
          creditTarget: 6,
          timePreferences: ["오후"],
        },
      },
    ]

    for (const submission of sampleSubmissions) {
      await addDoc(collection(db, "submissions"), {
        ...submission,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        ...(submission.completedAt && { completedAt: Timestamp.fromDate(submission.completedAt) }),
      })
    }

    const sampleFeedback = [
      {
        userId: "sample-user-1",
        rating: 5,
        comment: "시간표 최적화 기능이 정말 유용합니다. 공강시간도 적절히 배치되어 만족스럽습니다.",
        category: "feature",
        status: "open",
      },
      {
        userId: "sample-user-2",
        rating: 4,
        comment: "전반적으로 좋지만 UI가 조금 더 직관적이면 좋겠습니다.",
        category: "general",
        status: "open",
      },
      {
        userId: "sample-user-3",
        rating: 3,
        comment: "가끔 시스템이 느려질 때가 있어요. 성능 개선이 필요할 것 같습니다.",
        category: "bug",
        status: "in-progress",
      },
    ]

    for (const feedback of sampleFeedback) {
      await addDoc(collection(db, "feedback"), {
        ...feedback,
        createdAt: Timestamp.now(),
      })
    }

    const sampleInquiries = [
      {
        userId: "sample-user-1",
        title: "시간표 수정 방법 문의",
        content: "생성된 시간표에서 특정 과목의 시간을 변경하고 싶은데 어떻게 해야 하나요?",
        category: "technical",
        priority: "medium",
        status: "new",
      },
      {
        userId: "sample-user-2",
        title: "새로운 기능 제안",
        content: "과목별 난이도 정보도 함께 표시되면 좋겠습니다. 학습 계획 수립에 도움이 될 것 같아요.",
        category: "feature",
        priority: "low",
        status: "new",
      },
    ]

    for (const inquiry of sampleInquiries) {
      await addDoc(collection(db, "inquiries"), {
        ...inquiry,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    }

    console.log("[v0] Sample data seeded successfully!")
    console.log("[v0] Created:", sampleSubmissions.length, "sample submissions")
    console.log("[v0] Created:", sampleFeedback.length, "sample feedback")
    console.log("[v0] Created:", sampleInquiries.length, "sample inquiries")
  } catch (error) {
    console.error("[v0] Error seeding sample data:", error)
    throw error
  }
}

// Run seeding
seedSampleData()
  .then(() => {
    console.log("[v0] Sample data seeding complete!")
    process.exit(0)
  })
  .catch((error) => {
    console.error("[v0] Sample data seeding failed:", error)
    process.exit(1)
  })
