-- Create submissions table
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  status text default 'pending' check (status in ('pending', 'processing', 'completed', 'failed')),
  type text check (type in ('timetable', 'electives')),
  data jsonb,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  completed_at timestamp with time zone
);

-- Create notes table
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  content text,
  priority text default 'medium' check (priority in ('low', 'medium', 'high')),
  tags text[] default '{}',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Create feedback table
create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  rating integer check (rating >= 1 and rating <= 5),
  comment text,
  category text check (category in ('bug', 'feature', 'general')),
  status text default 'open' check (status in ('open', 'in-progress', 'resolved')),
  created_at timestamp with time zone default now()
);

-- Create notifications table
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  message text,
  type text check (type in ('info', 'success', 'warning', 'error')),
  category text check (category in ('submission', 'system', 'reminder', 'update')),
  is_read boolean default false,
  action_url text,
  action_text text,
  metadata jsonb,
  created_at timestamp with time zone default now(),
  read_at timestamp with time zone
);

-- Enable RLS on all tables
alter table public.submissions enable row level security;
alter table public.notes enable row level security;
alter table public.feedback enable row level security;
alter table public.notifications enable row level security;

-- Create RLS policies for submissions
create policy "submissions_select_own"
  on public.submissions for select
  using (auth.uid() = user_id);

create policy "submissions_insert_own"
  on public.submissions for insert
  with check (auth.uid() = user_id);

create policy "submissions_update_own"
  on public.submissions for update
  using (auth.uid() = user_id);

create policy "submissions_delete_own"
  on public.submissions for delete
  using (auth.uid() = user_id);

-- Create RLS policies for notes
create policy "notes_select_own"
  on public.notes for select
  using (auth.uid() = user_id);

create policy "notes_insert_own"
  on public.notes for insert
  with check (auth.uid() = user_id);

create policy "notes_update_own"
  on public.notes for update
  using (auth.uid() = user_id);

create policy "notes_delete_own"
  on public.notes for delete
  using (auth.uid() = user_id);

-- Create RLS policies for feedback
create policy "feedback_select_own"
  on public.feedback for select
  using (auth.uid() = user_id);

create policy "feedback_insert_own"
  on public.feedback for insert
  with check (auth.uid() = user_id);

-- Admin can view all feedback
create policy "feedback_select_admin"
  on public.feedback for select
  using (exists (
    select 1 from public.profiles 
    where id = auth.uid() and role = 'admin'
  ));

-- Create RLS policies for notifications
create policy "notifications_select_own"
  on public.notifications for select
  using (auth.uid() = user_id);

create policy "notifications_insert_own"
  on public.notifications for insert
  with check (auth.uid() = user_id);

create policy "notifications_update_own"
  on public.notifications for update
  using (auth.uid() = user_id);

create policy "notifications_delete_own"
  on public.notifications for delete
  using (auth.uid() = user_id);

-- Create indexes for better performance
create index if not exists submissions_user_id_idx on public.submissions(user_id);
create index if not exists submissions_created_at_idx on public.submissions(created_at desc);
create index if not exists notes_user_id_idx on public.notes(user_id);
create index if not exists notes_updated_at_idx on public.notes(updated_at desc);
create index if not exists feedback_created_at_idx on public.feedback(created_at desc);
create index if not exists notifications_user_id_idx on public.notifications(user_id);
create index if not exists notifications_created_at_idx on public.notifications(created_at desc);
create index if not exists notifications_is_read_idx on public.notifications(user_id, is_read);
