import type { NextRequest } from "next/server"
import { createHash } from "crypto"

const CSRF_SECRET = process.env.CSRF_SECRET || "default-csrf-secret-change-in-production"

export function generateCSRFToken(sessionId: string): string {
  const timestamp = Date.now().toString()
  const data = `${sessionId}:${timestamp}`
  const hash = createHash("sha256").update(`${data}:${CSRF_SECRET}`).digest("hex")

  return Buffer.from(`${data}:${hash}`).toString("base64")
}

export function validateCSRFToken(token: string, sessionId: string): boolean {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf-8")
    const [session, timestamp, hash] = decoded.split(":")

    if (session !== sessionId) {
      return false
    }

    // Check if token is not older than 1 hour
    const tokenTime = Number.parseInt(timestamp)
    const now = Date.now()
    if (now - tokenTime > 3600000) {
      return false
    }

    // Verify hash
    const expectedHash = createHash("sha256").update(`${session}:${timestamp}:${CSRF_SECRET}`).digest("hex")

    return hash === expectedHash
  } catch {
    return false
  }
}

export async function validateCSRF(request: NextRequest): Promise<boolean> {
  const csrfToken = request.headers.get("x-csrf-token") || request.cookies.get("csrf-token")?.value

  if (!csrfToken) {
    return false
  }

  const sessionId =
    request.cookies.get("__session")?.value ||
    request.cookies.get("user-token")?.value ||
    request.cookies.get("admin-token")?.value

  if (!sessionId) {
    return false
  }

  return validateCSRFToken(csrfToken, sessionId)
}
