export class AnalyticsService {
  private static isInitialized = false

  private static checkInitialization() {
    if (typeof window === "undefined") return false

    try {
      // Try to access analytics from config
      const { analytics } = require("./config")
      return !!analytics
    } catch (error) {
      console.warn("[v0] Analytics not available:", error)
      return false
    }
  }

  static logUserAction(action: string, parameters?: Record<string, any>) {
    if (!this.checkInitialization()) return

    try {
      const { analytics } = require("./config")
      const { logEvent } = require("firebase/analytics")

      if (analytics) {
        logEvent(analytics, action, {
          timestamp: new Date().toISOString(),
          ...parameters,
        })
      }
    } catch (error) {
      console.warn("[v0] Analytics logging failed:", error)
    }
  }

  static logAuthEvent(event: "login" | "signup" | "logout", method?: string) {
    this.logUserAction(`auth_${event}`, { method })
  }

  static logError(error: string, context?: string) {
    this.logUserAction("error_occurred", { error, context })
  }

  static setUserProfile(userId: string, properties: Record<string, any>) {
    if (!this.checkInitialization()) return

    try {
      const { analytics } = require("./config")
      const { setUserProperties } = require("firebase/analytics")

      if (analytics) {
        setUserProperties(analytics, {
          user_id: userId,
          ...properties,
        })
      }
    } catch (error) {
      console.warn("[v0] Analytics user properties failed:", error)
    }
  }

  static logPageView(pageName: string) {
    this.logUserAction("page_view", { page_name: pageName })
  }

  static logFeatureUsage(feature: string, action: string) {
    this.logUserAction("feature_usage", { feature, action })
  }
}
