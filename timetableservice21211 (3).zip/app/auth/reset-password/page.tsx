"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Mail, ArrowLeft, CheckCircle, AlertCircle, Send } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { Logo } from "@/components/ui/logo"

export default function ResetPasswordPage() {
  const { resetPassword, isLoading, error, clearError } = useAuth()
  const [email, setEmail] = useState("")
  const [success, setSuccess] = useState(false)
  const [validationError, setValidationError] = useState("")

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    clearError()
    setValidationError("")

    if (!validateEmail(email)) {
      setValidationError("올바른 이메일 형식이 아닙니다.")
      return
    }

    try {
      await resetPassword(email)
      setSuccess(true)
    } catch (error) {
      // Error handled by auth context
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-card/30 flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center space-y-2">
            <Link href="/" className="inline-block">
              <Logo size="md" />
            </Link>
          </div>

          <Card className="auth-card bounce-in">
            <CardHeader className="text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                <Send className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-xl font-heading">이메일을 확인하세요</CardTitle>
              <CardDescription className="text-balance">
                비밀번호 재설정 링크를 <strong>{email}</strong>로 보내드렸습니다.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="notification-success">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>이메일을 확인하고 링크를 클릭하여 새 비밀번호를 설정하세요.</AlertDescription>
              </Alert>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground text-center">
                  이메일이 도착하지 않았나요? 스팸 폴더를 확인해보세요.
                </p>
                <Button variant="outline" className="w-full bg-transparent" onClick={() => setSuccess(false)}>
                  다른 이메일로 다시 시도
                </Button>
              </div>

              <Link href="/auth">
                <Button variant="ghost" className="w-full">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  로그인으로 돌아가기
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-card/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <Link href="/" className="inline-block">
            <Logo size="md" />
          </Link>
          <p className="text-muted-foreground text-balance">비밀번호를 재설정하여 계정에 다시 접근하세요</p>
        </div>

        <Card className="auth-card bounce-in">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-xl text-center text-card-foreground font-heading">비밀번호 재설정</CardTitle>
            <CardDescription className="text-center text-balance">
              가입할 때 사용한 이메일 주소를 입력하면 비밀번호 재설정 링크를 보내드립니다.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">
                  이메일 주소
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    className={`auth-input pl-10 ${validationError ? "border-destructive focus:border-destructive" : ""}`}
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value)
                      setValidationError("")
                      clearError()
                    }}
                    required
                  />
                </div>
                {validationError && (
                  <div className="validation-error">
                    <AlertCircle className="h-4 w-4" />
                    {validationError}
                  </div>
                )}
              </div>

              <Button type="submit" className="auth-button-primary w-full" disabled={isLoading}>
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    전송 중...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="h-4 w-4" />
                    재설정 링크 보내기
                  </div>
                )}
              </Button>
            </form>

            {error && (
              <Alert className="mt-4 notification-error">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="mt-6 text-center">
              <Link href="/auth" className="inline-flex items-center text-sm auth-link">
                <ArrowLeft className="h-4 w-4 mr-1" />
                로그인으로 돌아가기
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-xs text-muted-foreground text-balance">
            계정이 없으신가요?{" "}
            <Link href="/auth" className="auth-link">
              회원가입하기
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
