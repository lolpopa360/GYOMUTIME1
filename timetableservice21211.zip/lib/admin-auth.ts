import { db } from "./firebase/config"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import type { User } from "firebase/auth"
import { AnalyticsService } from "./firebase/analytics"

export interface AdminUser extends User {
  isAdmin: boolean
  role: "admin" | "super-admin" | "user"
  permissions: string[]
  lastLoginAt?: Date
  loginAttempts?: number
  isLocked?: boolean
}

export async function checkAdminStatus(user: User): Promise<boolean> {
  try {
    const userDoc = await getDoc(doc(db, "users", user.uid))
    const userData = userDoc.data()

    if (!userData) return false

    const isAdmin = userData?.role === "admin" || userData?.role === "super-admin" || userData?.isAdmin === true

    if (isAdmin) {
      // Update last login time for admin users
      await updateDoc(doc(db, "users", user.uid), {
        lastLoginAt: new Date(),
        loginAttempts: 0, // Reset on successful login
      })

      AnalyticsService.logUserAction("admin_login_success", {
        userId: user.uid,
        email: user.email,
        role: userData.role,
      })
    }

    return isAdmin
  } catch (error) {
    console.error("[v0] Error checking admin status:", error)
    AnalyticsService.logError("admin_status_check_failed", error.message)
    return false
  }
}

export async function checkAdminRole(email: string): Promise<boolean> {
  try {
    // Super admin emails (hardcoded for security)
    const superAdminEmails = ["yangchanhee11@gmail.com"]

    // Admin domain patterns
    const adminDomains = ["@gyomutime.com", "@admin.gyomutime.com"]

    const normalizedEmail = email.toLowerCase().trim()

    // Check super admin emails
    if (superAdminEmails.includes(normalizedEmail)) {
      return true
    }

    // Check admin domains
    const isAdminDomain = adminDomains.some((domain) => normalizedEmail.endsWith(domain))

    if (isAdminDomain) {
      AnalyticsService.logUserAction("admin_domain_access", { email: normalizedEmail })
      return true
    }

    return false
  } catch (error) {
    console.error("[v0] Error checking admin role:", error)
    AnalyticsService.logError("admin_role_check_failed", error.message)
    return false
  }
}

export async function requireAdmin(user: User | null, requiredPermission?: string): Promise<boolean> {
  if (!user) return false

  try {
    const isAdmin = await checkAdminStatus(user)

    if (!isAdmin) return false

    // If specific permission is required, check it
    if (requiredPermission) {
      const userDoc = await getDoc(doc(db, "users", user.uid))
      const userData = userDoc.data()
      const permissions = userData?.permissions || []

      return permissions.includes(requiredPermission) || userData?.role === "super-admin"
    }

    return true
  } catch (error) {
    console.error("[v0] Error in requireAdmin:", error)
    return false
  }
}

export async function getAdminPermissions(user: User): Promise<string[]> {
  try {
    const userDoc = await getDoc(doc(db, "users", user.uid))
    const userData = userDoc.data()

    if (userData?.role === "super-admin") {
      return [
        "user_management",
        "admin_management",
        "system_settings",
        "database_access",
        "analytics_access",
        "file_management",
        "inquiry_management",
        "security_settings",
      ]
    }

    return userData?.permissions || []
  } catch (error) {
    console.error("[v0] Error getting admin permissions:", error)
    return []
  }
}

export async function logAdminAction(user: User, action: string, details?: Record<string, any>) {
  try {
    AnalyticsService.logUserAction("admin_action", {
      adminId: user.uid,
      adminEmail: user.email,
      action,
      timestamp: new Date().toISOString(),
      ...details,
    })
  } catch (error) {
    console.error("[v0] Error logging admin action:", error)
  }
}

export async function handleFailedAdminLogin(email: string): Promise<boolean> {
  try {
    // This would typically be stored in a separate security collection
    // For now, we'll use localStorage on the client side
    AnalyticsService.logUserAction("admin_login_failed", {
      email,
      timestamp: new Date().toISOString(),
    })

    return true
  } catch (error) {
    console.error("[v0] Error handling failed admin login:", error)
    return false
  }
}
