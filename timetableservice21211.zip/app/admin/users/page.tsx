"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Logo } from "@/components/ui/logo"
import { Users, ShieldCheck, Crown, Search, Filter, Edit, LogOut, ArrowLeft } from "lucide-react"
import { getAllUsers, updateUserRole, isSuperAdmin, type UserProfile } from "@/lib/supabase/auth"
import Link from "next/link"

export default function UserManagement() {
  const { user, userProfile, logout } = useAuth()
  const { toast } = useToast()
  const [users, setUsers] = useState<UserProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState<"all" | "admin" | "user">("all")
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null)
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false)
  const [newRole, setNewRole] = useState<"admin" | "user">("user")

  useEffect(() => {
    loadUsers()
  }, [])

  const loadUsers = async () => {
    try {
      setLoading(true)
      const allUsers = await getAllUsers()
      setUsers(allUsers)
    } catch (error) {
      toast({
        title: "오류",
        description: "사용자 목록을 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleRoleChange = async () => {
    if (!selectedUser) return

    try {
      await updateUserRole(selectedUser.id, newRole)

      // Update local state
      setUsers((prev) =>
        prev.map((u) => (u.id === selectedUser.id ? { ...u, role: newRole, updated_at: new Date().toISOString() } : u)),
      )

      toast({
        title: "권한 변경 완료",
        description: `${selectedUser.name}님의 권한이 ${newRole === "admin" ? "관리자" : "일반 사용자"}로 변경되었습니다.`,
      })

      setIsRoleDialogOpen(false)
      setSelectedUser(null)
    } catch (error) {
      toast({
        title: "오류",
        description: "권한 변경에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const openRoleDialog = (user: UserProfile) => {
    setSelectedUser(user)
    setNewRole(user.role)
    setIsRoleDialogOpen(true)
  }

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      (user.name?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
      (user.email?.toLowerCase() || "").includes(searchTerm.toLowerCase())
    const matchesRole = roleFilter === "all" || user.role === roleFilter
    return matchesSearch && matchesRole
  })

  const getRoleBadge = (role: string, email: string) => {
    if (isSuperAdmin(email)) {
      return (
        <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
          <Crown className="h-3 w-3 mr-1" />
          슈퍼 관리자
        </Badge>
      )
    }

    switch (role) {
      case "admin":
        return (
          <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            <ShieldCheck className="h-3 w-3 mr-1" />
            관리자
          </Badge>
        )
      case "user":
        return (
          <Badge variant="outline">
            <Users className="h-3 w-3 mr-1" />
            일반 사용자
          </Badge>
        )
      default:
        return <Badge variant="secondary">알 수 없음</Badge>
    }
  }

  const getStatusBadge = (lastLogin: string) => {
    const now = new Date()
    const loginDate = new Date(lastLogin)
    const diffInDays = Math.floor((now.getTime() - loginDate.getTime()) / (1000 * 60 * 60 * 24))

    if (diffInDays === 0) {
      return <Badge className="bg-green-500/10 text-green-600">오늘 활동</Badge>
    } else if (diffInDays <= 7) {
      return <Badge className="bg-yellow-500/10 text-yellow-600">최근 활동</Badge>
    } else {
      return <Badge variant="outline">비활성</Badge>
    }
  }

  const canModifyUser = (targetUser: UserProfile) => {
    // Super admin can modify anyone except themselves
    if (isSuperAdmin(userProfile?.email || "")) {
      return targetUser.id !== user?.id
    }
    return false
  }

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">사용자 목록을 불러오는 중...</p>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Link href="/admin">
                  <Button variant="ghost" size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    관리자 대시보드
                  </Button>
                </Link>
                <div className="h-6 w-px bg-border"></div>
                <Logo size="md" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground">사용자 관리</h1>
                  <p className="text-xs text-muted-foreground">User Management System</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">{user?.user_metadata?.name || user?.email}님</span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  로그아웃
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">전체 사용자</CardTitle>
                  <Users className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{users.length}</div>
                <p className="text-xs text-muted-foreground">등록된 사용자 수</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">관리자</CardTitle>
                  <ShieldCheck className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-500">{users.filter((u) => u.role === "admin").length}</div>
                <p className="text-xs text-muted-foreground">관리자 권한 사용자</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">일반 사용자</CardTitle>
                  <Users className="h-4 w-4 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">{users.filter((u) => u.role === "user").length}</div>
                <p className="text-xs text-muted-foreground">일반 사용자</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-sm font-medium">활성 사용자</CardTitle>
                    <CardDescription>최근 7일 활동한 사용자</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-500">
                  {
                    users.filter((u) => {
                      const diffInDays = Math.floor(
                        (new Date().getTime() - new Date(u.last_login).getTime()) / (1000 * 60 * 60 * 24),
                      )
                      return diffInDays <= 7
                    }).length
                  }
                </div>
                <p className="text-xs text-muted-foreground">최근 7일 활동</p>
              </CardContent>
            </Card>
          </div>

          {/* User Management Table */}
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">사용자 목록</CardTitle>
                  <CardDescription>시스템에 등록된 모든 사용자의 권한을 관리할 수 있습니다.</CardDescription>
                </div>
                <Button onClick={loadUsers} variant="outline" size="sm">
                  새로고침
                </Button>
              </div>

              {/* Search and Filter */}
              <div className="flex items-center space-x-4 mt-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="이름 또는 이메일로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={roleFilter} onValueChange={(value: "all" | "admin" | "user") => setRoleFilter(value)}>
                  <SelectTrigger className="w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">모든 권한</SelectItem>
                    <SelectItem value="admin">관리자</SelectItem>
                    <SelectItem value="user">일반 사용자</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>사용자</TableHead>
                      <TableHead>권한</TableHead>
                      <TableHead>가입일</TableHead>
                      <TableHead>최근 로그인</TableHead>
                      <TableHead>상태</TableHead>
                      <TableHead>작업</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id} className="border-border">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">
                                {(user.name || user.email || "?").charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <div className="font-medium">{user.name || "이름 없음"}</div>
                              <div className="text-sm text-muted-foreground">{user.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{getRoleBadge(user.role, user.email)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {new Date(user.created_at).toLocaleDateString("ko-KR")}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {new Date(user.last_login).toLocaleDateString("ko-KR")}
                        </TableCell>
                        <TableCell>{getStatusBadge(user.last_login)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {canModifyUser(user) && (
                              <Button size="sm" variant="outline" onClick={() => openRoleDialog(user)}>
                                <Edit className="h-3 w-3 mr-1" />
                                권한 변경
                              </Button>
                            )}
                            {!canModifyUser(user) && user.id === userProfile?.id && (
                              <Badge variant="secondary" className="text-xs">
                                본인 계정
                              </Badge>
                            )}
                            {isSuperAdmin(user.email) && user.id !== userProfile?.id && (
                              <Badge variant="secondary" className="text-xs">
                                슈퍼 관리자
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Role Change Dialog */}
        <Dialog open={isRoleDialogOpen} onOpenChange={setIsRoleDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>사용자 권한 변경</DialogTitle>
              <DialogDescription>{selectedUser?.name}님의 권한을 변경하시겠습니까?</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="bg-muted/20 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="font-medium text-primary">
                      {(selectedUser?.name || selectedUser?.email || "?").charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <div className="font-medium">{selectedUser?.name || "이름 없음"}</div>
                    <div className="text-sm text-muted-foreground">{selectedUser?.email}</div>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="role">새로운 권한</Label>
                <Select value={newRole} onValueChange={(value: "admin" | "user") => setNewRole(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">
                      <div className="flex items-center">
                        <ShieldCheck className="h-4 w-4 mr-2" />
                        관리자
                      </div>
                    </SelectItem>
                    <SelectItem value="user">
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-2" />
                        일반 사용자
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsRoleDialogOpen(false)}>
                  취소
                </Button>
                <Button onClick={handleRoleChange}>권한 변경</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </ProtectedRoute>
  )
}
