import { createClient } from "./client"

export interface UserProfile {
  id: string
  email: string
  name: string
  role: "admin" | "user"
  created_at: string
  last_login: string
  updated_at?: string
}

const SUPER_ADMIN_EMAIL = "yangchanhee11@gmail.com"

// Sign in with email and password
export const signInUser = async (email: string, password: string) => {
  const supabase = createClient()

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) throw error

  // Update last login
  if (data.user) {
    await supabase.from("profiles").update({ last_login: new Date().toISOString() }).eq("id", data.user.id)
  }

  return data.user
}

// Sign up with email and password
export const signUpUser = async (email: string, password: string, name: string) => {
  const supabase = createClient()

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/auth/login`,
      data: {
        name: name,
      },
    },
  })

  if (error) throw error
  return data.user
}

// Sign out
export const signOutUser = async () => {
  const supabase = createClient()
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

// Get user profile from database
export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  try {
    const supabase = createClient()
    const { data, error } = await supabase.from("profiles").select("*").eq("id", uid).single()

    if (error) {
      console.error("Error getting user profile:", error)
      return null
    }

    return data
  } catch (error) {
    console.error("Error getting user profile:", error)
    return null
  }
}

// Check if user is admin
export const isUserAdmin = async (uid: string): Promise<boolean> => {
  try {
    const profile = await getUserProfile(uid)
    return profile?.role === "admin" || false
  } catch (error) {
    console.error("Error checking admin status:", error)
    return false
  }
}

// Auth state observer
export const onAuthStateChange = (callback: (user: any) => void) => {
  const supabase = createClient()

  const {
    data: { subscription },
  } = supabase.auth.onAuthStateChange(async (event, session) => {
    callback(session?.user || null)
  })

  return () => subscription.unsubscribe()
}

// Admin management functions
export const updateUserRole = async (uid: string, role: "admin" | "user"): Promise<void> => {
  try {
    const supabase = createClient()
    const { error } = await supabase
      .from("profiles")
      .update({
        role,
        updated_at: new Date().toISOString(),
      })
      .eq("id", uid)

    if (error) throw error
  } catch (error) {
    console.error("Error updating user role:", error)
    throw error
  }
}

export const getAllUsers = async (): Promise<UserProfile[]> => {
  try {
    const supabase = createClient()
    const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error("Error getting all users:", error)
    throw error
  }
}

export const isSuperAdmin = (email: string): boolean => {
  return email === SUPER_ADMIN_EMAIL
}
