"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Logo } from "@/components/ui/logo"
import {
  Upload,
  Download,
  Trash2,
  FileText,
  FileSpreadsheet,
  FileImage,
  File,
  Search,
  Filter,
  Plus,
  LogOut,
  ArrowLeft,
  FolderOpen,
  Calendar,
  User,
} from "lucide-react"
import Link from "next/link"

interface FileItem {
  id: string
  name: string
  type: string
  size: number
  category: "template" | "document" | "result" | "other"
  uploadedBy: string
  uploadedAt: Date
  downloadCount: number
  description?: string
  url: string
}

// Mock data for demonstration
const mockFiles: FileItem[] = [
  {
    id: "1",
    name: "시간표_템플릿_고등학교.xlsx",
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 2048576,
    category: "template",
    uploadedBy: "관리자",
    uploadedAt: new Date("2024-01-15"),
    downloadCount: 45,
    description: "고등학교 시간표 생성을 위한 기본 템플릿",
    url: "/files/template_high_school.xlsx",
  },
  {
    id: "2",
    name: "분반배정_가이드.pdf",
    type: "application/pdf",
    size: 1024000,
    category: "document",
    uploadedBy: "관리자",
    uploadedAt: new Date("2024-01-14"),
    downloadCount: 23,
    description: "선택과목 분반 배정 시스템 사용 가이드",
    url: "/files/class_assignment_guide.pdf",
  },
  {
    id: "3",
    name: "중학교_시간표_결과_2024.xlsx",
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    size: 3145728,
    category: "result",
    uploadedBy: "시스템",
    uploadedAt: new Date("2024-01-13"),
    downloadCount: 12,
    description: "중학교 시간표 최적화 결과 파일",
    url: "/files/middle_school_result_2024.xlsx",
  },
  {
    id: "4",
    name: "교무타임_로고.png",
    type: "image/png",
    size: 512000,
    category: "other",
    uploadedBy: "관리자",
    uploadedAt: new Date("2024-01-12"),
    downloadCount: 8,
    description: "교무타임 공식 로고 파일",
    url: "/files/gyomutime_logo.png",
  },
]

export default function FileManagement() {
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const [files, setFiles] = useState<FileItem[]>(mockFiles)
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<"all" | "template" | "document" | "result" | "other">("all")
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)
  const [uploadData, setUploadData] = useState({
    files: [] as File[],
    category: "document" as FileItem["category"],
    description: "",
  })

  const getFileIcon = (type: string) => {
    if (type.includes("spreadsheet") || type.includes("excel")) {
      return <FileSpreadsheet className="h-5 w-5 text-green-600" />
    } else if (type.includes("pdf")) {
      return <FileText className="h-5 w-5 text-red-600" />
    } else if (type.includes("image")) {
      return <FileImage className="h-5 w-5 text-blue-600" />
    } else {
      return <File className="h-5 w-5 text-gray-600" />
    }
  }

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "template":
        return <Badge className="bg-blue-500/10 text-blue-600">템플릿</Badge>
      case "document":
        return <Badge className="bg-green-500/10 text-green-600">문서</Badge>
      case "result":
        return <Badge className="bg-purple-500/10 text-purple-600">결과</Badge>
      case "other":
        return <Badge variant="outline">기타</Badge>
      default:
        return <Badge variant="secondary">알 수 없음</Badge>
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || [])
    setUploadData((prev) => ({
      ...prev,
      files: [...prev.files, ...selectedFiles],
    }))
  }

  const handleUploadSubmit = async () => {
    if (uploadData.files.length === 0) {
      toast({
        title: "오류",
        description: "업로드할 파일을 선택해주세요.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    try {
      // In a real implementation, this would upload to Firebase Storage
      const newFiles: FileItem[] = uploadData.files.map((file, index) => ({
        id: `new_${Date.now()}_${index}`,
        name: file.name,
        type: file.type,
        size: file.size,
        category: uploadData.category,
        uploadedBy: user?.displayName || "관리자",
        uploadedAt: new Date(),
        downloadCount: 0,
        description: uploadData.description,
        url: `/files/${file.name}`,
      }))

      setFiles((prev) => [...newFiles, ...prev])

      toast({
        title: "업로드 완료",
        description: `${uploadData.files.length}개 파일이 성공적으로 업로드되었습니다.`,
      })

      setIsUploadDialogOpen(false)
      setUploadData({
        files: [],
        category: "document",
        description: "",
      })
    } catch (error) {
      toast({
        title: "업로드 실패",
        description: "파일 업로드 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = (file: FileItem) => {
    // In a real implementation, this would download from Firebase Storage
    console.log(`Downloading: ${file.name}`)

    // Update download count
    setFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, downloadCount: f.downloadCount + 1 } : f)))

    toast({
      title: "다운로드 시작",
      description: `${file.name} 파일을 다운로드합니다.`,
    })
  }

  const handleDelete = (fileId: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId))
    toast({
      title: "파일 삭제",
      description: "파일이 성공적으로 삭제되었습니다.",
    })
  }

  const removeUploadFile = (index: number) => {
    setUploadData((prev) => ({
      ...prev,
      files: prev.files.filter((_, i) => i !== index),
    }))
  }

  const filteredFiles = files.filter((file) => {
    const matchesSearch =
      file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      file.description?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || file.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const totalSize = files.reduce((sum, file) => sum + file.size, 0)
  const totalDownloads = files.reduce((sum, file) => sum + file.downloadCount, 0)

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Link href="/admin">
                  <Button variant="ghost" size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    관리자 대시보드
                  </Button>
                </Link>
                <div className="h-6 w-px bg-border"></div>
                <Logo size="md" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground">파일 관리</h1>
                  <p className="text-xs text-muted-foreground">File Management System</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  {user?.photoURL && (
                    <img
                      src={user.photoURL || "/placeholder.svg"}
                      alt={user.displayName || ""}
                      className="w-8 h-8 rounded-full"
                    />
                  )}
                  <span className="text-sm text-muted-foreground">{user?.displayName}님</span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  로그아웃
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">전체 파일</CardTitle>
                  <FolderOpen className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{files.length}</div>
                <p className="text-xs text-muted-foreground">업로드된 파일 수</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">총 용량</CardTitle>
                  <FileText className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-500">{formatFileSize(totalSize)}</div>
                <p className="text-xs text-muted-foreground">전체 파일 크기</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">다운로드</CardTitle>
                  <Download className="h-4 w-4 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">{totalDownloads}</div>
                <p className="text-xs text-muted-foreground">총 다운로드 횟수</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">템플릿</CardTitle>
                  <FileSpreadsheet className="h-4 w-4 text-yellow-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-500">
                  {files.filter((f) => f.category === "template").length}
                </div>
                <p className="text-xs text-muted-foreground">템플릿 파일</p>
              </CardContent>
            </Card>
          </div>

          {/* File Management */}
          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">파일 목록</CardTitle>
                  <CardDescription>시스템에서 사용되는 모든 파일을 관리할 수 있습니다.</CardDescription>
                </div>
                <Button onClick={() => setIsUploadDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  파일 업로드
                </Button>
              </div>

              {/* Search and Filter */}
              <div className="flex items-center space-x-4 mt-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="파일명 또는 설명으로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select
                  value={categoryFilter}
                  onValueChange={(value: typeof categoryFilter) => setCategoryFilter(value)}
                >
                  <SelectTrigger className="w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">모든 카테고리</SelectItem>
                    <SelectItem value="template">템플릿</SelectItem>
                    <SelectItem value="document">문서</SelectItem>
                    <SelectItem value="result">결과</SelectItem>
                    <SelectItem value="other">기타</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>파일</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>크기</TableHead>
                      <TableHead>업로드자</TableHead>
                      <TableHead>업로드일</TableHead>
                      <TableHead>다운로드</TableHead>
                      <TableHead>작업</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredFiles.map((file) => (
                      <TableRow key={file.id} className="border-border">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            {getFileIcon(file.type)}
                            <div>
                              <div className="font-medium">{file.name}</div>
                              {file.description && (
                                <div className="text-sm text-muted-foreground">{file.description}</div>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{getCategoryBadge(file.category)}</TableCell>
                        <TableCell className="text-muted-foreground">{formatFileSize(file.size)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4" />
                            <span>{file.uploadedBy}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          <div className="flex items-center space-x-2">
                            <Calendar className="h-4 w-4" />
                            <span>{file.uploadedAt.toLocaleDateString("ko-KR")}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Download className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{file.downloadCount}회</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" onClick={() => handleDownload(file)}>
                              <Download className="h-3 w-3 mr-1" />
                              다운로드
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(file.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              삭제
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upload Dialog */}
        <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>파일 업로드</DialogTitle>
              <DialogDescription>새로운 파일을 시스템에 업로드합니다.</DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div>
                <Label htmlFor="files">파일 선택</Label>
                <Input id="files" type="file" multiple onChange={handleFileUpload} className="cursor-pointer" />
                <p className="text-xs text-muted-foreground mt-1">여러 파일을 동시에 선택할 수 있습니다.</p>
              </div>

              {uploadData.files.length > 0 && (
                <div className="space-y-2">
                  <Label>선택된 파일</Label>
                  <div className="max-h-40 overflow-y-auto space-y-2">
                    {uploadData.files.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                        <div className="flex items-center space-x-3">
                          {getFileIcon(file.type)}
                          <div>
                            <div className="font-medium text-sm">{file.name}</div>
                            <div className="text-xs text-muted-foreground">{formatFileSize(file.size)}</div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => removeUploadFile(index)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="category">카테고리</Label>
                <Select
                  value={uploadData.category}
                  onValueChange={(value: FileItem["category"]) =>
                    setUploadData((prev) => ({ ...prev, category: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="template">템플릿</SelectItem>
                    <SelectItem value="document">문서</SelectItem>
                    <SelectItem value="result">결과</SelectItem>
                    <SelectItem value="other">기타</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">설명 (선택사항)</Label>
                <Textarea
                  id="description"
                  placeholder="파일에 대한 설명을 입력하세요..."
                  value={uploadData.description}
                  onChange={(e) => setUploadData((prev) => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                  취소
                </Button>
                <Button onClick={handleUploadSubmit} disabled={loading || uploadData.files.length === 0}>
                  {loading ? (
                    <>
                      <Upload className="h-4 w-4 mr-2 animate-spin" />
                      업로드 중...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      업로드
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </ProtectedRoute>
  )
}
