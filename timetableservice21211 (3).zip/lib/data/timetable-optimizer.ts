interface TimeSlot {
  id: string
  day: string
  startTime: string
  endTime: string
  duration: number
}

interface Course {
  id: string
  name: string
  instructor: string
  credits: number
  requiredSlots: number
  preferredTimes?: string[]
  conflicts?: string[]
}

interface Room {
  id: string
  name: string
  capacity: number
  type: "lecture" | "lab" | "seminar"
  equipment: string[]
}

interface OptimizationResult {
  schedule: ScheduleEntry[]
  conflicts: Conflict[]
  efficiency: number
  utilization: number
}

interface ScheduleEntry {
  courseId: string
  roomId: string
  timeSlot: TimeSlot
  instructor: string
  students: number
}

interface Conflict {
  type: "room" | "instructor" | "student"
  description: string
  severity: "low" | "medium" | "high"
  affectedItems: string[]
}

export class TimetableOptimizer {
  private courses: Course[] = []
  private rooms: Room[] = []
  private timeSlots: TimeSlot[] = []
  private constraints: Map<string, any> = new Map()

  constructor() {
    this.initializeTimeSlots()
  }

  private initializeTimeSlots() {
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    const times = [
      { start: "09:00", end: "10:30", duration: 90 },
      { start: "10:45", end: "12:15", duration: 90 },
      { start: "13:30", end: "15:00", duration: 90 },
      { start: "15:15", end: "16:45", duration: 90 },
      { start: "17:00", end: "18:30", duration: 90 },
    ]

    this.timeSlots = days.flatMap((day) =>
      times.map((time, index) => ({
        id: `${day.toLowerCase()}-${index + 1}`,
        day,
        startTime: time.start,
        endTime: time.end,
        duration: time.duration,
      })),
    )
  }

  async optimizeSchedule(courses: Course[], rooms: Room[]): Promise<OptimizationResult> {
    this.courses = courses
    this.rooms = rooms

    console.log("[v0] Starting timetable optimization for", courses.length, "courses")

    // Generate initial population
    const populationSize = 50
    const generations = 100
    let population = this.generateInitialPopulation(populationSize)

    // Evolve population
    for (let gen = 0; gen < generations; gen++) {
      population = this.evolvePopulation(population)

      if (gen % 20 === 0) {
        const best = population[0]
        console.log(`[v0] Generation ${gen}: Best fitness = ${this.calculateFitness(best)}`)
      }
    }

    const bestSchedule = population[0]
    const conflicts = this.detectConflicts(bestSchedule)
    const efficiency = this.calculateEfficiency(bestSchedule)
    const utilization = this.calculateUtilization(bestSchedule)

    console.log("[v0] Optimization complete. Efficiency:", efficiency, "Utilization:", utilization)

    return {
      schedule: bestSchedule,
      conflicts,
      efficiency,
      utilization,
    }
  }

  private generateInitialPopulation(size: number): ScheduleEntry[][] {
    const population: ScheduleEntry[][] = []

    for (let i = 0; i < size; i++) {
      const schedule = this.generateRandomSchedule()
      population.push(schedule)
    }

    // Sort by fitness
    population.sort((a, b) => this.calculateFitness(b) - this.calculateFitness(a))
    return population
  }

  private generateRandomSchedule(): ScheduleEntry[] {
    const schedule: ScheduleEntry[] = []

    for (const course of this.courses) {
      for (let slot = 0; slot < course.requiredSlots; slot++) {
        const timeSlot = this.timeSlots[Math.floor(Math.random() * this.timeSlots.length)]
        const room = this.rooms[Math.floor(Math.random() * this.rooms.length)]

        schedule.push({
          courseId: course.id,
          roomId: room.id,
          timeSlot,
          instructor: course.instructor,
          students: Math.floor(Math.random() * room.capacity),
        })
      }
    }

    return schedule
  }

  private evolvePopulation(population: ScheduleEntry[][]): ScheduleEntry[][] {
    const newPopulation: ScheduleEntry[][] = []
    const eliteSize = Math.floor(population.length * 0.2)

    // Keep elite individuals
    for (let i = 0; i < eliteSize; i++) {
      newPopulation.push([...population[i]])
    }

    // Generate offspring through crossover and mutation
    while (newPopulation.length < population.length) {
      const parent1 = this.selectParent(population)
      const parent2 = this.selectParent(population)
      const offspring = this.crossover(parent1, parent2)
      const mutated = this.mutate(offspring)
      newPopulation.push(mutated)
    }

    // Sort by fitness
    newPopulation.sort((a, b) => this.calculateFitness(b) - this.calculateFitness(a))
    return newPopulation
  }

  private selectParent(population: ScheduleEntry[][]): ScheduleEntry[] {
    // Tournament selection
    const tournamentSize = 5
    const tournament = []

    for (let i = 0; i < tournamentSize; i++) {
      const randomIndex = Math.floor(Math.random() * population.length)
      tournament.push(population[randomIndex])
    }

    tournament.sort((a, b) => this.calculateFitness(b) - this.calculateFitness(a))
    return tournament[0]
  }

  private crossover(parent1: ScheduleEntry[], parent2: ScheduleEntry[]): ScheduleEntry[] {
    const crossoverPoint = Math.floor(Math.random() * parent1.length)
    return [...parent1.slice(0, crossoverPoint), ...parent2.slice(crossoverPoint)]
  }

  private mutate(schedule: ScheduleEntry[]): ScheduleEntry[] {
    const mutationRate = 0.1
    const mutated = [...schedule]

    for (let i = 0; i < mutated.length; i++) {
      if (Math.random() < mutationRate) {
        // Randomly change time slot or room
        if (Math.random() < 0.5) {
          mutated[i].timeSlot = this.timeSlots[Math.floor(Math.random() * this.timeSlots.length)]
        } else {
          mutated[i].roomId = this.rooms[Math.floor(Math.random() * this.rooms.length)].id
        }
      }
    }

    return mutated
  }

  private calculateFitness(schedule: ScheduleEntry[]): number {
    let fitness = 100
    const conflicts = this.detectConflicts(schedule)

    // Penalize conflicts
    conflicts.forEach((conflict) => {
      switch (conflict.severity) {
        case "high":
          fitness -= 10
          break
        case "medium":
          fitness -= 5
          break
        case "low":
          fitness -= 2
          break
      }
    })

    // Reward good utilization
    const utilization = this.calculateUtilization(schedule)
    fitness += utilization * 20

    // Reward preferred time slots
    schedule.forEach((entry) => {
      const course = this.courses.find((c) => c.id === entry.courseId)
      if (course?.preferredTimes?.includes(entry.timeSlot.startTime)) {
        fitness += 5
      }
    })

    return Math.max(0, fitness)
  }

  private detectConflicts(schedule: ScheduleEntry[]): Conflict[] {
    const conflicts: Conflict[] = []
    const roomTimeMap = new Map<string, ScheduleEntry[]>()
    const instructorTimeMap = new Map<string, ScheduleEntry[]>()

    // Group by room-time and instructor-time
    schedule.forEach((entry) => {
      const roomTimeKey = `${entry.roomId}-${entry.timeSlot.id}`
      const instructorTimeKey = `${entry.instructor}-${entry.timeSlot.id}`

      if (!roomTimeMap.has(roomTimeKey)) {
        roomTimeMap.set(roomTimeKey, [])
      }
      if (!instructorTimeMap.has(instructorTimeKey)) {
        instructorTimeMap.set(instructorTimeKey, [])
      }

      roomTimeMap.get(roomTimeKey)!.push(entry)
      instructorTimeMap.get(instructorTimeKey)!.push(entry)
    })

    // Check room conflicts
    roomTimeMap.forEach((entries, key) => {
      if (entries.length > 1) {
        conflicts.push({
          type: "room",
          description: `Room conflict at ${key}`,
          severity: "high",
          affectedItems: entries.map((e) => e.courseId),
        })
      }
    })

    // Check instructor conflicts
    instructorTimeMap.forEach((entries, key) => {
      if (entries.length > 1) {
        conflicts.push({
          type: "instructor",
          description: `Instructor conflict at ${key}`,
          severity: "high",
          affectedItems: entries.map((e) => e.courseId),
        })
      }
    })

    return conflicts
  }

  private calculateEfficiency(schedule: ScheduleEntry[]): number {
    const totalSlots = this.timeSlots.length * this.rooms.length
    const usedSlots = schedule.length
    return (usedSlots / totalSlots) * 100
  }

  private calculateUtilization(schedule: ScheduleEntry[]): number {
    let totalCapacity = 0
    let totalStudents = 0

    schedule.forEach((entry) => {
      const room = this.rooms.find((r) => r.id === entry.roomId)
      if (room) {
        totalCapacity += room.capacity
        totalStudents += entry.students
      }
    })

    return totalCapacity > 0 ? (totalStudents / totalCapacity) * 100 : 0
  }

  addConstraint(type: string, constraint: any) {
    this.constraints.set(type, constraint)
  }

  removeConstraint(type: string) {
    this.constraints.delete(type)
  }

  validateSchedule(schedule: ScheduleEntry[]): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    // Check for required courses
    const scheduledCourses = new Set(schedule.map((s) => s.courseId))
    this.courses.forEach((course) => {
      if (!scheduledCourses.has(course.id)) {
        errors.push(`Course ${course.name} is not scheduled`)
      }
    })

    // Check room capacity
    schedule.forEach((entry) => {
      const room = this.rooms.find((r) => r.id === entry.roomId)
      if (room && entry.students > room.capacity) {
        errors.push(`Room ${room.name} overcapacity for course ${entry.courseId}`)
      }
    })

    return {
      isValid: errors.length === 0,
      errors,
    }
  }
}
