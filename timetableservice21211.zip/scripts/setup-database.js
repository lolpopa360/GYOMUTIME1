const { createClient } = require("@supabase/supabase-js")
const fs = require("fs")
const path = require("path")

async function setupDatabase() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseKey) {
    console.error("Missing Supabase environment variables")
    process.exit(1)
  }

  const supabase = createClient(supabaseUrl, supabaseKey)

  const sqlFiles = ["001_create_users_table.sql", "002_create_app_tables.sql", "003_create_admin_tables.sql"]

  console.log("Setting up database...")

  for (const file of sqlFiles) {
    const filePath = path.join(__dirname, file)
    if (fs.existsSync(filePath)) {
      const sql = fs.readFileSync(filePath, "utf8")
      console.log(`Executing ${file}...`)

      const { error } = await supabase.rpc("exec_sql", { sql })
      if (error) {
        console.error(`Error executing ${file}:`, error)
      } else {
        console.log(`✓ ${file} executed successfully`)
      }
    }
  }

  console.log("Database setup complete!")
}

setupDatabase().catch(console.error)
