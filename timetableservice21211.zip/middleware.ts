import { NextResponse, type NextRequest } from "next/server"

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const response = NextResponse.next()

  // Add basic security headers
  response.headers.set("X-Frame-Options", "DENY")
  response.headers.set("X-Content-Type-Options", "nosniff")
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin")

  // Enhanced admin route protection
  if (pathname.startsWith("/admin") && pathname !== "/admin/auth") {
    // Check for Firebase auth token in Authorization header or custom header
    const authHeader = request.headers.get("authorization")
    const firebaseToken = request.cookies.get("firebase-auth-token")

    if (!authHeader && !firebaseToken) {
      const redirectUrl = new URL("/admin/auth", request.url)
      redirectUrl.searchParams.set("redirect", pathname)
      return NextResponse.redirect(redirectUrl)
    }
  }

  // Enhanced dashboard route protection
  if (pathname.startsWith("/dashboard")) {
    // Check for Firebase auth token
    const authHeader = request.headers.get("authorization")
    const firebaseToken = request.cookies.get("firebase-auth-token")

    if (!authHeader && !firebaseToken) {
      const redirectUrl = new URL("/auth/signin", request.url)
      redirectUrl.searchParams.set("redirect", pathname)
      return NextResponse.redirect(redirectUrl)
    }
  }

  // Redirect authenticated users away from auth pages
  if (pathname.startsWith("/auth") && !pathname.includes("/admin") && !pathname.includes("/reset")) {
    const authHeader = request.headers.get("authorization")
    const firebaseToken = request.cookies.get("firebase-auth-token")

    if (authHeader || firebaseToken) {
      const redirectTo = request.nextUrl.searchParams.get("redirect") || "/dashboard"
      return NextResponse.redirect(new URL(redirectTo, request.url))
    }
  }

  // Block access to sensitive files and directories
  const blockedPaths = ["/.env", "/.git", "/config", "/logs", "/backup"]

  if (blockedPaths.some((blocked) => pathname.startsWith(blocked))) {
    return new NextResponse("Not Found", { status: 404 })
  }

  // Add security logging for suspicious activities
  const suspiciousPatterns = [
    /\.\./, // Directory traversal
    /<script/i, // XSS attempts
    /union.*select/i, // SQL injection
    /javascript:/i, // JavaScript protocol
  ]

  if (suspiciousPatterns.some((pattern) => pattern.test(pathname))) {
    console.warn(`[Security] Suspicious request detected: ${pathname}`)
    return new NextResponse("Bad Request", { status: 400 })
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - images - .svg, .png, .jpg, .jpeg, .gif, .webp
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
}
