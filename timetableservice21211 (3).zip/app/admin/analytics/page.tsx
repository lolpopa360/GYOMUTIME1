"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AdminHeader } from "@/components/admin/admin-header"
import { Badge } from "@/components/ui/badge"
import { BarChart3, TrendingUp, Users, Clock, CheckCircle, AlertCircle, Activity } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"

// Mock data for charts
const usageData = [
  { name: "1월", users: 45, optimizations: 23 },
  { name: "2월", users: 52, optimizations: 31 },
  { name: "3월", users: 48, optimizations: 28 },
  { name: "4월", users: 61, optimizations: 42 },
  { name: "5월", users: 55, optimizations: 38 },
  { name: "6월", users: 67, optimizations: 45 },
]

const performanceData = [
  { name: "월", success: 98, failed: 2 },
  { name: "화", success: 95, failed: 5 },
  { name: "수", success: 99, failed: 1 },
  { name: "목", success: 97, failed: 3 },
  { name: "금", success: 96, failed: 4 },
  { name: "토", success: 100, failed: 0 },
  { name: "일", success: 94, failed: 6 },
]

export default function AnalyticsPage() {
  return (
    <div className="flex-1 space-y-6 p-6">
      <AdminHeader title="시스템 분석" description="교무타임 시스템의 사용량과 성능을 분석합니다" />

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">총 사용자</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,234</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+12%</span> 지난 달 대비
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">월간 최적화</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">456</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+8%</span> 지난 달 대비
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">평균 처리 시간</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24.5초</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">-3%</span> 지난 달 대비
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">성공률</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">97.8%</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+0.5%</span> 지난 달 대비
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>사용량 추이</CardTitle>
            <CardDescription>월별 사용자 수와 최적화 실행 횟수</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="users" stroke="hsl(var(--primary))" strokeWidth={2} name="사용자" />
                <Line
                  type="monotone"
                  dataKey="optimizations"
                  stroke="hsl(var(--secondary))"
                  strokeWidth={2}
                  name="최적화"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>성능 분석</CardTitle>
            <CardDescription>일별 성공/실패 비율</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="success" fill="hsl(var(--primary))" name="성공" />
                <Bar dataKey="failed" fill="hsl(var(--destructive))" name="실패" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* System Status */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>시스템 상태</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">API 서버</span>
              <Badge className="bg-green-500/10 text-green-600">정상</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">데이터베이스</span>
              <Badge className="bg-green-500/10 text-green-600">정상</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">최적화 엔진</span>
              <Badge className="bg-green-500/10 text-green-600">정상</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">파일 저장소</span>
              <Badge className="bg-yellow-500/10 text-yellow-600">주의</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>인기 기능</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">시간표 최적화</span>
              <span className="text-sm font-medium">78%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">분반 배정</span>
              <span className="text-sm font-medium">65%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">템플릿 다운로드</span>
              <span className="text-sm font-medium">45%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">결과 내보내기</span>
              <span className="text-sm font-medium">32%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5" />
              <span>최근 이슈</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm">저장소 용량 부족</span>
                <Badge variant="destructive">높음</Badge>
              </div>
              <p className="text-xs text-muted-foreground">2시간 전</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm">API 응답 지연</span>
                <Badge className="bg-yellow-500/10 text-yellow-600">중간</Badge>
              </div>
              <p className="text-xs text-muted-foreground">5시간 전</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm">로그인 오류 증가</span>
                <Badge variant="outline">낮음</Badge>
              </div>
              <p className="text-xs text-muted-foreground">1일 전</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
