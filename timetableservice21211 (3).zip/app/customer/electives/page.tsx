"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Logo } from "@/components/ui/logo"
import { Cpu, ArrowLeft, Upload, Users, CheckCircle, Info, Table, Settings, AlertTriangle } from "lucide-react"

function ElectivesSubmissionContent() {
  const [formData, setFormData] = useState({
    contactName: "",
    file: null as File | null,
    maxStudentsPerClass: 25,
    minClassesPerSubject: 1,
    maxClassesPerSubject: 3,
    hasSpecialConstraints: false,
    specialConstraints: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.name.endsWith(".xlsx")) {
      setFormData((prev) => ({ ...prev, file }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.contactName || !formData.file) return

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitted(true)
      setIsLoading(false)
    }, 2000)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center space-x-3">
              <Logo size="md" />
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <div className="mx-auto mb-6 p-4 bg-secondary/10 rounded-full w-fit">
              <CheckCircle className="h-12 w-12 text-secondary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-4">알고리즘 실행 대기</h1>
            <p className="text-lg text-muted-foreground mb-8">
              선택과목 분반 최적화 요청이 성공적으로 접수되었습니다. 지능형 분반 알고리즘이 곧 실행됩니다.
            </p>
            <div className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  담당자: {formData.contactName} | 파일: {formData.file?.name} | 분반당 최대:{" "}
                  {formData.maxStudentsPerClass}명
                </AlertDescription>
              </Alert>
              <Link href="/">
                <Button variant="outline">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  홈으로 돌아가기
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <Logo size="md" />
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                홈으로
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-secondary/10 text-secondary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Users className="h-4 w-4" />
              <span>선택과목 분반 최적화 알고리즘</span>
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-4">선택과목 분반 배정</h1>
            <p className="text-lg text-muted-foreground">
              고급 제약 조건을 설정하여 학생들의 선택과목 희망을 바탕으로 최적의 분반을 자동 배정합니다.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Submission Form */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-2xl text-card-foreground flex items-center space-x-2">
                  <Settings className="h-6 w-6 text-primary" />
                  <span>알고리즘 제약 조건 설정</span>
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  분반 배정 최적화를 위한 상세 제약 조건을 설정해주세요.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="contactName" className="text-card-foreground">
                      담당자 이름 *
                    </Label>
                    <Input
                      id="contactName"
                      type="text"
                      placeholder="담당자 성함을 입력해주세요"
                      value={formData.contactName}
                      onChange={(e) => setFormData((prev) => ({ ...prev, contactName: e.target.value }))}
                      required
                      className="bg-input border-border text-foreground"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="file" className="text-card-foreground">
                      선택과목 데이터 파일 (.xlsx) *
                    </Label>
                    <div className="relative">
                      <Input
                        id="file"
                        type="file"
                        accept=".xlsx"
                        onChange={handleFileChange}
                        required
                        className="bg-input border-border text-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-secondary file:text-secondary-foreground hover:file:bg-secondary/90"
                      />
                      <Upload className="absolute right-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
                    </div>
                    {formData.file && <p className="text-sm text-secondary">선택된 파일: {formData.file.name}</p>}
                  </div>

                  {/* Detailed constraint input fields */}
                  <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                    <h4 className="font-semibold text-card-foreground flex items-center space-x-2">
                      <Settings className="h-4 w-4 text-primary" />
                      <span>분반 제약 조건</span>
                    </h4>

                    <div className="space-y-2">
                      <Label htmlFor="maxStudents" className="text-card-foreground">
                        분반당 최대 학생 수 *
                      </Label>
                      <Input
                        id="maxStudents"
                        type="number"
                        min="10"
                        max="50"
                        value={formData.maxStudentsPerClass}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            maxStudentsPerClass: Number.parseInt(e.target.value) || 25,
                          }))
                        }
                        className="bg-input border-border text-foreground"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="minClasses" className="text-card-foreground">
                          선택 슬롯 최소 과목 수
                        </Label>
                        <Input
                          id="minClasses"
                          type="number"
                          min="1"
                          max="5"
                          value={formData.minClassesPerSubject}
                          onChange={(e) =>
                            setFormData((prev) => ({
                              ...prev,
                              minClassesPerSubject: Number.parseInt(e.target.value) || 1,
                            }))
                          }
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="maxClasses" className="text-card-foreground">
                          선택 슬롯 최대 과목 수
                        </Label>
                        <Input
                          id="maxClasses"
                          type="number"
                          min="1"
                          max="10"
                          value={formData.maxClassesPerSubject}
                          onChange={(e) =>
                            setFormData((prev) => ({
                              ...prev,
                              maxClassesPerSubject: Number.parseInt(e.target.value) || 3,
                            }))
                          }
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 p-4 bg-muted/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="specialConstraints"
                        checked={formData.hasSpecialConstraints}
                        onCheckedChange={(checked) =>
                          setFormData((prev) => ({ ...prev, hasSpecialConstraints: checked as boolean }))
                        }
                      />
                      <Label htmlFor="specialConstraints" className="text-card-foreground font-medium">
                        특정 과목 예외 제약 조건 적용
                      </Label>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      일부 과목에 대해 다른 제약 조건을 적용하시겠습니까? (예: 일반적으로 분반당 25명이지만 체육은 30명
                      허용)
                    </p>

                    {formData.hasSpecialConstraints && (
                      <div className="space-y-2">
                        <Label htmlFor="specialConstraintsDetail" className="text-card-foreground">
                          예외 제약 조건 상세 설명
                        </Label>
                        <Textarea
                          id="specialConstraintsDetail"
                          placeholder="예: 체육 - 최대 30명, 음악 - 최대 15명, 미술 - 최소 2분반 보장"
                          value={formData.specialConstraints}
                          onChange={(e) => setFormData((prev) => ({ ...prev, specialConstraints: e.target.value }))}
                          rows={3}
                          className="bg-input border-border text-foreground"
                        />
                      </div>
                    )}
                  </div>

                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>최적화 성능 안내:</strong> 제약 조건이 많을수록 최적해를 찾기 어려워집니다. 필수적인 제약
                      조건만 설정하시는 것을 권장합니다.
                    </AlertDescription>
                  </Alert>

                  <Button
                    type="submit"
                    variant="secondary"
                    className="w-full"
                    disabled={!formData.contactName || !formData.file || isLoading}
                  >
                    {isLoading ? "알고리즘 실행 중..." : "분반 최적화 알고리즘 실행"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Guidelines */}
            <div className="space-y-6">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-card-foreground">
                    <Table className="h-5 w-5 text-secondary" />
                    <span>데이터 입력 형식</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-card-foreground">엑셀 파일 구조</h4>
                    <div className="bg-muted/20 p-4 rounded-lg">
                      <div className="grid grid-cols-4 gap-2 text-xs font-mono">
                        <div className="bg-secondary/20 p-2 rounded text-center font-semibold">학생ID</div>
                        <div className="bg-primary/20 p-2 rounded text-center font-semibold">수학심화</div>
                        <div className="bg-primary/20 p-2 rounded text-center font-semibold">물리학</div>
                        <div className="bg-primary/20 p-2 rounded text-center font-semibold">화학</div>
                        <div className="p-2 text-center">2024001</div>
                        <div className="p-2 text-center">1</div>
                        <div className="p-2 text-center">0</div>
                        <div className="p-2 text-center">1</div>
                        <div className="p-2 text-center">2024002</div>
                        <div className="p-2 text-center">0</div>
                        <div className="p-2 text-center">1</div>
                        <div className="p-2 text-center">0</div>
                      </div>
                    </div>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                        <span>
                          <strong>첫 번째 열:</strong> 학생 고유 ID (학번, 학생번호)
                        </span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                        <span>
                          <strong>이후 열들:</strong> 각 선택과목명을 헤더로 사용
                        </span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                        <span>
                          <strong>데이터 값:</strong> 1 = 희망함, 0 = 희망하지 않음
                        </span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-card-foreground">
                    <Cpu className="h-5 w-5 text-primary" />
                    <span>최적화 알고리즘 프로세스</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-secondary">1</span>
                      </div>
                      <span className="text-sm text-muted-foreground">학생 선호도 매트릭스 생성</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-secondary">2</span>
                      </div>
                      <span className="text-sm text-muted-foreground">제약 조건 파라미터 설정</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-secondary">3</span>
                      </div>
                      <span className="text-sm text-muted-foreground">OR-Tools 솔버 실행</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">4</span>
                      </div>
                      <span className="text-sm text-muted-foreground">최적 분반 배정 결과 생성</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">알고리즘 최적화 목표</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                      <span>학생 희망 과목 만족도 최대화</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                      <span>분반별 인원수 균형 최적화</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                      <span>교실 및 교사 리소스 효율성</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-secondary mt-0.5 flex-shrink-0" />
                      <span>시간표 충돌 최소화</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>처리 시간:</strong> 학생 수와 제약 조건 복잡도에 따라 1-12시간 소요. 복잡한 제약 조건일수록
                  처리 시간이 증가할 수 있습니다.
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ElectivesSubmissionPage() {
  return (
    <ProtectedRoute>
      <ElectivesSubmissionContent />
    </ProtectedRoute>
  )
}
