"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Mail, Lock, User, ArrowRight, CheckCircle, AlertCircle, Chrome, Shield } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Logo } from "@/components/ui/logo"

export default function AuthPage() {
  const { login, signUp, loginWithGoogle, isLoading, error, clearError } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [success, setSuccess] = useState("")
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})
  const router = useRouter()

  const [signInData, setSignInData] = useState({
    email: "",
    password: "",
  })

  const [signUpData, setSignUpData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const validatePassword = (password: string) => {
    return {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /\d/.test(password),
    }
  }

  const handleInputChange = (field: string, value: string, form: "signin" | "signup") => {
    if (form === "signin") {
      setSignInData({ ...signInData, [field]: value })
    } else {
      setSignUpData({ ...signUpData, [field]: value })
    }

    // Clear validation errors on input change
    if (validationErrors[field]) {
      setValidationErrors({ ...validationErrors, [field]: "" })
    }
    clearError()
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    clearError()
    setValidationErrors({})

    // Validation
    const errors: Record<string, string> = {}
    if (!validateEmail(signInData.email)) {
      errors.email = "올바른 이메일 형식이 아닙니다."
    }
    if (signInData.password.length < 6) {
      errors.password = "비밀번호는 최소 6자 이상이어야 합니다."
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors)
      return
    }

    try {
      await login(signInData.email, signInData.password)
      setSuccess("로그인 성공! 대시보드로 이동합니다.")
      setTimeout(() => router.push("/dashboard"), 1500)
    } catch (error) {
      // Error handled by auth context
    }
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    clearError()
    setValidationErrors({})

    // Enhanced validation
    const errors: Record<string, string> = {}

    if (signUpData.name.trim().length < 2) {
      errors.name = "이름은 최소 2자 이상이어야 합니다."
    }

    if (!validateEmail(signUpData.email)) {
      errors.email = "올바른 이메일 형식이 아닙니다."
    }

    const passwordValidation = validatePassword(signUpData.password)
    if (!passwordValidation.length) {
      errors.password = "비밀번호는 최소 8자 이상이어야 합니다."
    } else if (!passwordValidation.uppercase || !passwordValidation.lowercase || !passwordValidation.number) {
      errors.password = "비밀번호는 대문자, 소문자, 숫자를 포함해야 합니다."
    }

    if (signUpData.password !== signUpData.confirmPassword) {
      errors.confirmPassword = "비밀번호가 일치하지 않습니다."
    }

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors)
      return
    }

    try {
      await signUp(signUpData.email, signUpData.password, signUpData.name)
      setSuccess("회원가입이 완료되었습니다! 대시보드로 이동합니다.")
      setTimeout(() => router.push("/dashboard"), 1500)
    } catch (error) {
      // Error handled by auth context
    }
  }

  const handleGoogleLogin = async () => {
    try {
      await loginWithGoogle()
      setSuccess("Google 로그인 성공! 대시보드로 이동합니다.")
      setTimeout(() => router.push("/dashboard"), 1500)
    } catch (error) {
      // Error handled by auth context
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-card/30 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <Link href="/" className="inline-block">
            <Logo size="md" />
          </Link>
          <p className="text-muted-foreground text-balance">AI 기반 시간표 최적화로 더 나은 학습 환경을 만들어보세요</p>
        </div>

        {/* Auth Card */}
        <Card className="auth-card bounce-in">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-xl text-center text-card-foreground font-heading">계정 관리</CardTitle>
            <CardDescription className="text-center">로그인하거나 새 계정을 만드세요</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin" className="space-y-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin" className="text-sm font-medium">
                  로그인
                </TabsTrigger>
                <TabsTrigger value="signup" className="text-sm font-medium">
                  회원가입
                </TabsTrigger>
              </TabsList>

              {/* Sign In Tab */}
              <TabsContent value="signin" className="space-y-4">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-email" className="text-sm font-medium">
                      이메일
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signin-email"
                        type="email"
                        placeholder="your@email.com"
                        className={`auth-input pl-10 ${validationErrors.email ? "border-destructive focus:border-destructive" : ""}`}
                        value={signInData.email}
                        onChange={(e) => handleInputChange("email", e.target.value, "signin")}
                        required
                      />
                    </div>
                    {validationErrors.email && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.email}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signin-password" className="text-sm font-medium">
                      비밀번호
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signin-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="비밀번호를 입력하세요"
                        className={`auth-input pl-10 pr-10 ${validationErrors.password ? "border-destructive focus:border-destructive" : ""}`}
                        value={signInData.password}
                        onChange={(e) => handleInputChange("password", e.target.value, "signin")}
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {validationErrors.password && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.password}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end">
                    <Link href="/auth/reset-password" className="text-sm auth-link">
                      비밀번호를 잊으셨나요?
                    </Link>
                  </div>

                  <Button type="submit" className="auth-button-primary w-full" disabled={isLoading}>
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                        로그인 중...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        로그인
                        <ArrowRight className="h-4 w-4" />
                      </div>
                    )}
                  </Button>
                </form>

                <div className="auth-divider">
                  <span>또는</span>
                </div>

                <Button
                  type="button"
                  variant="outline"
                  className="auth-button-outline w-full bg-transparent"
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                >
                  <Chrome className="h-4 w-4 mr-2" />
                  Google로 로그인
                </Button>
              </TabsContent>

              {/* Sign Up Tab */}
              <TabsContent value="signup" className="space-y-4">
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-name" className="text-sm font-medium">
                      이름
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signup-name"
                        type="text"
                        placeholder="홍길동"
                        className={`auth-input pl-10 ${validationErrors.name ? "border-destructive focus:border-destructive" : ""}`}
                        value={signUpData.name}
                        onChange={(e) => handleInputChange("name", e.target.value, "signup")}
                        required
                      />
                    </div>
                    {validationErrors.name && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.name}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-email" className="text-sm font-medium">
                      이메일
                    </Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="your@email.com"
                        className={`auth-input pl-10 ${validationErrors.email ? "border-destructive focus:border-destructive" : ""}`}
                        value={signUpData.email}
                        onChange={(e) => handleInputChange("email", e.target.value, "signup")}
                        required
                      />
                    </div>
                    {validationErrors.email && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.email}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="text-sm font-medium">
                      비밀번호
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signup-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="최소 8자, 대소문자, 숫자 포함"
                        className={`auth-input pl-10 pr-10 ${validationErrors.password ? "border-destructive focus:border-destructive" : ""}`}
                        value={signUpData.password}
                        onChange={(e) => handleInputChange("password", e.target.value, "signup")}
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {validationErrors.password && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.password}
                      </div>
                    )}
                    {signUpData.password && (
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">비밀번호 강도:</div>
                        <div className="flex gap-1">
                          {Object.entries(validatePassword(signUpData.password)).map(([key, valid]) => (
                            <div key={key} className={`h-1 flex-1 rounded ${valid ? "bg-primary" : "bg-muted"}`} />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-confirm-password" className="text-sm font-medium">
                      비밀번호 확인
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="signup-confirm-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="비밀번호를 다시 입력하세요"
                        className={`auth-input pl-10 ${validationErrors.confirmPassword ? "border-destructive focus:border-destructive" : ""}`}
                        value={signUpData.confirmPassword}
                        onChange={(e) => handleInputChange("confirmPassword", e.target.value, "signup")}
                        required
                      />
                    </div>
                    {validationErrors.confirmPassword && (
                      <div className="validation-error">
                        <AlertCircle className="h-4 w-4" />
                        {validationErrors.confirmPassword}
                      </div>
                    )}
                    {signUpData.confirmPassword && signUpData.password === signUpData.confirmPassword && (
                      <div className="validation-success">
                        <CheckCircle className="h-4 w-4" />
                        비밀번호가 일치합니다
                      </div>
                    )}
                  </div>

                  <Button type="submit" className="auth-button-secondary w-full" disabled={isLoading}>
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-secondary-foreground/30 border-t-secondary-foreground rounded-full animate-spin" />
                        계정 생성 중...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        계정 만들기
                        <CheckCircle className="h-4 w-4" />
                      </div>
                    )}
                  </Button>
                </form>

                <div className="auth-divider">
                  <span>또는</span>
                </div>

                <Button
                  type="button"
                  variant="outline"
                  className="auth-button-outline w-full bg-transparent"
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                >
                  <Chrome className="h-4 w-4 mr-2" />
                  Google로 회원가입
                </Button>
              </TabsContent>
            </Tabs>

            {/* Error/Success Messages */}
            {error && (
              <Alert className="mt-4 notification-error">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="mt-4 notification-success">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">
            관리자이신가요?{" "}
            <Link href="/admin/auth" className="auth-link">
              <Shield className="inline h-3 w-3 mr-1" />
              관리자 로그인
            </Link>
          </p>
          <p className="text-xs text-muted-foreground text-balance">
            계정을 생성하면{" "}
            <Link href="/terms" className="auth-link">
              이용약관
            </Link>
            과{" "}
            <Link href="/privacy" className="auth-link">
              개인정보처리방침
            </Link>
            에 동의하는 것으로 간주됩니다.
          </p>
        </div>
      </div>
    </div>
  )
}
