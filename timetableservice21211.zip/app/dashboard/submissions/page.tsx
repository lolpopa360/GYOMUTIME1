"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  Download,
  Eye,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  FileText,
  Calendar,
  TrendingUp,
  BarChart3,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"
import { getUserSubmissions, updateSubmissionStatus } from "@/lib/supabase/database"
import type { Submission } from "@/lib/supabase/database"
import { useToast } from "@/hooks/use-toast"

export default function SubmissionsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [filteredSubmissions, setFilteredSubmissions] = useState<Submission[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  useEffect(() => {
    loadSubmissions()
  }, [user])

  useEffect(() => {
    filterSubmissions()
  }, [submissions, searchTerm, statusFilter, typeFilter])

  const loadSubmissions = async () => {
    if (!user) return

    try {
      const userSubmissions = await getUserSubmissions(user.id)
      setSubmissions(userSubmissions)
    } catch (error) {
      console.error("Error loading submissions:", error)
      toast({
        title: "오류",
        description: "제출물을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterSubmissions = () => {
    let filtered = submissions

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (submission) =>
          submission.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          submission.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((submission) => submission.status === statusFilter)
    }

    // Type filter
    if (typeFilter !== "all") {
      filtered = filtered.filter((submission) => submission.type === typeFilter)
    }

    setFilteredSubmissions(filtered)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            <Clock className="h-3 w-3 mr-1" />
            대기중
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
            <Play className="h-3 w-3 mr-1" />
            처리중
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="default" className="bg-green-500/10 text-green-600 border-green-500/20">
            <CheckCircle className="h-3 w-3 mr-1" />
            완료
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="destructive" className="bg-red-500/10 text-red-600 border-red-500/20">
            <AlertCircle className="h-3 w-3 mr-1" />
            실패
          </Badge>
        )
      default:
        return <Badge variant="outline">알 수 없음</Badge>
    }
  }

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "timetable":
        return <Badge variant="secondary">시간표 최적화</Badge>
      case "electives":
        return <Badge variant="outline">선택과목 분반</Badge>
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const getProgressValue = (status: string) => {
    switch (status) {
      case "pending":
        return 25
      case "processing":
        return 75
      case "completed":
        return 100
      case "failed":
        return 0
      default:
        return 0
    }
  }

  const handleViewDetails = (submission: Submission) => {
    setSelectedSubmission(submission)
    setIsDetailDialogOpen(true)
  }

  const handleRetry = async (submissionId: string) => {
    try {
      await updateSubmissionStatus(submissionId, "pending")
      toast({
        title: "성공",
        description: "제출물이 다시 처리 대기열에 추가되었습니다.",
      })
      loadSubmissions()
    } catch (error) {
      console.error("Error retrying submission:", error)
      toast({
        title: "오류",
        description: "재처리 요청 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const pendingCount = submissions.filter((s) => s.status === "pending").length
  const processingCount = submissions.filter((s) => s.status === "processing").length
  const completedCount = submissions.filter((s) => s.status === "completed").length
  const failedCount = submissions.filter((s) => s.status === "failed").length
  const totalCount = submissions.length
  const completionRate = totalCount > 0 ? (completedCount / totalCount) * 100 : 0

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">제출물을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground">제출물 현황</h1>
          <p className="text-muted-foreground">시간표 최적화 및 분반 배정 작업의 진행 상황을 확인하세요</p>
        </div>

        <Button onClick={loadSubmissions} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          새로고침
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">총 제출물</p>
                <p className="text-2xl font-bold text-primary">{totalCount}</p>
              </div>
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">대기중</p>
                <p className="text-2xl font-bold text-blue-600">{pendingCount}</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">처리중</p>
                <p className="text-2xl font-bold text-yellow-600">{processingCount}</p>
              </div>
              <Play className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">완료</p>
                <p className="text-2xl font-bold text-green-600">{completedCount}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">실패</p>
                <p className="text-2xl font-bold text-red-600">{failedCount}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Completion Rate */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            전체 완료율
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">진행률</span>
            <span className="text-sm font-medium">{completionRate.toFixed(1)}%</span>
          </div>
          <Progress value={completionRate} className="h-2" />
          <p className="text-xs text-muted-foreground mt-2">
            {totalCount}개 중 {completedCount}개 완료
          </p>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="제출물 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="상태" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 상태</SelectItem>
                <SelectItem value="pending">대기중</SelectItem>
                <SelectItem value="processing">처리중</SelectItem>
                <SelectItem value="completed">완료</SelectItem>
                <SelectItem value="failed">실패</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="유형" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 유형</SelectItem>
                <SelectItem value="timetable">시간표 최적화</SelectItem>
                <SelectItem value="electives">선택과목 분반</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Submissions Table */}
      {filteredSubmissions.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>제출물 목록</CardTitle>
            <CardDescription>{filteredSubmissions.length}개의 제출물이 있습니다</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>제목</TableHead>
                    <TableHead>유형</TableHead>
                    <TableHead>상태</TableHead>
                    <TableHead>진행률</TableHead>
                    <TableHead>제출일</TableHead>
                    <TableHead>작업</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubmissions.map((submission) => (
                    <TableRow key={submission.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{submission.title}</p>
                          <p className="text-sm text-muted-foreground line-clamp-1">{submission.description}</p>
                        </div>
                      </TableCell>
                      <TableCell>{getTypeBadge(submission.type)}</TableCell>
                      <TableCell>{getStatusBadge(submission.status)}</TableCell>
                      <TableCell>
                        <div className="w-20">
                          <Progress value={getProgressValue(submission.status)} className="h-2" />
                          <p className="text-xs text-muted-foreground mt-1">{getProgressValue(submission.status)}%</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(submission.created_at).toLocaleDateString("ko-KR")}
                        <br />
                        {new Date(submission.created_at).toLocaleTimeString("ko-KR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => handleViewDetails(submission)}>
                            <Eye className="h-4 w-4" />
                          </Button>

                          {submission.status === "completed" && (
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          )}

                          {submission.status === "failed" && (
                            <Button variant="ghost" size="sm" onClick={() => handleRetry(submission.id!)}>
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">제출물이 없습니다</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                ? "검색 조건에 맞는 제출물이 없습니다"
                : "아직 제출한 작업이 없습니다"}
            </p>
            <div className="flex justify-center space-x-4">
              <Link href="/customer/timetable">
                <Button>
                  <Calendar className="h-4 w-4 mr-2" />
                  시간표 최적화
                </Button>
              </Link>
              <Link href="/customer/electives">
                <Button variant="outline">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  선택과목 분반
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>제출물 상세 정보</DialogTitle>
            <DialogDescription>제출물의 상세 정보와 진행 상황을 확인하세요</DialogDescription>
          </DialogHeader>

          {selectedSubmission && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2">기본 정보</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">제목:</span>
                      <span>{selectedSubmission.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">유형:</span>
                      {getTypeBadge(selectedSubmission.type)}
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">상태:</span>
                      {getStatusBadge(selectedSubmission.status)}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">일정 정보</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">제출일:</span>
                      <span>{new Date(selectedSubmission.created_at).toLocaleDateString("ko-KR")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">수정일:</span>
                      <span>{new Date(selectedSubmission.updated_at).toLocaleDateString("ko-KR")}</span>
                    </div>
                    {selectedSubmission.completed_at && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">완료일:</span>
                        <span>{new Date(selectedSubmission.completed_at).toLocaleDateString("ko-KR")}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">설명</h4>
                <p className="text-sm text-muted-foreground bg-muted/20 p-3 rounded-lg">
                  {selectedSubmission.description || "설명이 없습니다."}
                </p>
              </div>

              <div>
                <h4 className="font-medium mb-2">진행 상황</h4>
                <Progress value={getProgressValue(selectedSubmission.status)} className="h-3" />
                <p className="text-sm text-muted-foreground mt-2">
                  {getProgressValue(selectedSubmission.status)}% 완료
                </p>
              </div>

              {selectedSubmission.data && (
                <div>
                  <h4 className="font-medium mb-2">추가 데이터</h4>
                  <pre className="text-xs bg-muted/20 p-3 rounded-lg overflow-auto max-h-32">
                    {JSON.stringify(selectedSubmission.data, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
