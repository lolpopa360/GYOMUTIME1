"use client"
import { Button } from "@/components/ui/button"
import type React from "react"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/lib/auth-context"
import { Logo } from "@/components/ui/logo"
import { Loader2, Shield, Lock } from "lucide-react"
import { useState } from "react"

interface LoginModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function LoginModal({ open, onOpenChange }: LoginModalProps) {
  const { login, isLoading } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    try {
      await login(email, password)
      onOpenChange(false)
      setEmail("")
      setPassword("")
    } catch (error: any) {
      setError(error.message || "로그인에 실패했습니다.")
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-xl w-fit">
            <div className="relative">
              <Logo size="sm" />
              <Shield className="h-4 w-4 text-secondary absolute -top-1 -right-1 bg-card rounded-full p-0.5" />
            </div>
          </div>
          <DialogTitle className="text-2xl font-bold text-card-foreground">관리자 인증</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            교무타임 알고리즘 관리 시스템에 접근하려면 보안 인증이 필요합니다.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-4">
          <div className="bg-muted/20 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Lock className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-card-foreground">보안 인증 시스템</span>
            </div>
            <p className="text-xs text-muted-foreground">이메일과 비밀번호로 안전하게 로그인하세요.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">이메일</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@gyomutime.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">비밀번호</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}

            <Button type="submit" disabled={isLoading} className="w-full h-12 text-base">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  인증 처리 중...
                </>
              ) : (
                <>
                  <Lock className="mr-2 h-4 w-4" />
                  보안 로그인
                </>
              )}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center">
            인증 시 교무타임의 보안 정책 및 데이터 처리 방침에 동의하는 것으로 간주됩니다.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
