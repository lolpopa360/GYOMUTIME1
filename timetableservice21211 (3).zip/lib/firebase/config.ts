import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getFirestore, type Firestore } from "firebase/firestore"
import { getStorage, type FirebaseStorage } from "firebase/storage"
import { getAnalytics, type Analytics } from "firebase/analytics"
import { getFunctions, type Functions } from "firebase/functions"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "AIzaSyDMIIfQ8P0iWVOfaVwLwF0Q3unKlAWj-04",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "gyomutime-61a6f.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "gyomutime-61a6f",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "gyomutime-61a6f.firebasestorage.app",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "863417171989",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:863417171989:web:a8d0226053509e206e8e1c",
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID || "G-DQHPYVXS97",
}

declare global {
  var __firebaseApp: FirebaseApp | undefined
  var __firebaseAuth: Auth | undefined
  var __firebaseDb: Firestore | undefined
  var __firebaseStorage: FirebaseStorage | undefined
  var __firebaseFunctions: Functions | undefined
  var __firebaseAnalytics: Analytics | undefined
  var __firebaseInitialized: boolean | undefined
}

let app: FirebaseApp | null = null
let auth: Auth | null = null
let db: Firestore | null = null
let storage: FirebaseStorage | null = null
let functions: Functions | null = null
let analytics: Analytics | null = null

function isFirebaseStudioEnvironment(): boolean {
  if (typeof window === "undefined") return false

  const hostname = window.location.hostname
  const isStudioDomain =
    hostname.includes("firebase") ||
    hostname.includes("web.app") ||
    hostname.includes("firebaseapp.com") ||
    hostname.includes("v0.app") ||
    hostname.includes("vercel.app")

  return isStudioDomain
}

function initializeFirebase(): boolean {
  if (typeof window !== "undefined" && globalThis.__firebaseInitialized) {
    app = globalThis.__firebaseApp || null
    auth = globalThis.__firebaseAuth || null
    db = globalThis.__firebaseDb || null
    storage = globalThis.__firebaseStorage || null
    functions = globalThis.__firebaseFunctions || null
    analytics = globalThis.__firebaseAnalytics || null
    return true
  }

  try {
    // Validate configuration before initialization
    const requiredFields = ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId"]
    const missingFields = requiredFields.filter((field) => !firebaseConfig[field as keyof typeof firebaseConfig])

    if (missingFields.length > 0) {
      console.error("Missing Firebase configuration fields:", missingFields)
      return false
    }

    // Initialize Firebase app only if not already initialized
    if (getApps().length === 0) {
      app = initializeApp(firebaseConfig)
    } else {
      app = getApp()
    }

    // Initialize all Firebase services with error handling
    if (app) {
      try {
        auth = getAuth(app)

        // Configure auth for Firebase Studio compatibility
        if (typeof window !== "undefined" && isFirebaseStudioEnvironment()) {
          // Set additional configuration for Studio environments
          auth.settings.appVerificationDisabledForTesting = false
        }
      } catch (authError) {
        console.error("Auth initialization failed:", authError)
        auth = null
      }

      try {
        db = getFirestore(app)
      } catch (dbError) {
        console.error("Firestore initialization failed:", dbError)
        db = null
      }

      try {
        storage = getStorage(app)
      } catch (storageError) {
        console.error("Storage initialization failed:", storageError)
        storage = null
      }

      try {
        functions = getFunctions(app)
      } catch (functionsError) {
        console.error("Functions initialization failed:", functionsError)
        functions = null
      }

      if (typeof window !== "undefined") {
        try {
          analytics = getAnalytics(app)
        } catch (analyticsError) {
          console.warn("Analytics initialization failed (this is normal in some environments):", analyticsError)
          analytics = null
        }

        // Store in global for persistence
        globalThis.__firebaseApp = app
        globalThis.__firebaseAuth = auth
        globalThis.__firebaseDb = db
        globalThis.__firebaseStorage = storage
        globalThis.__firebaseFunctions = functions
        globalThis.__firebaseAnalytics = analytics
        globalThis.__firebaseInitialized = true
      }
    }

    return true
  } catch (error) {
    console.error("Firebase initialization failed:", error)

    if (typeof window !== "undefined" && isFirebaseStudioEnvironment()) {
      console.error("Firebase Studio environment detected. Common issues:")
      console.error("1. Domain not authorized in Firebase Console")
      console.error("2. Third-party cookies disabled")
      console.error("3. Invalid configuration parameters")
      console.error("Current domain:", window.location.hostname)
    }

    return false
  }
}

// Initialize Firebase on module load
initializeFirebase()

export const getFirebaseAuth = (): Auth | null => {
  if (!auth) {
    initializeFirebase()
  }
  return auth
}

export const getFirebaseDb = (): Firestore | null => {
  if (!db) {
    initializeFirebase()
  }
  return db
}

export const getFirebaseAuthSync = (): Auth | null => {
  return auth
}

export const getFirebaseDbSync = (): Firestore | null => {
  return db
}

export const getFirebaseStorage = (): FirebaseStorage | null => {
  return storage
}

export const getFirebaseFunctions = (): Functions | null => {
  return functions
}

export const getFirebaseAnalytics = (): Analytics | null => {
  return analytics
}

export const isFirebaseReady = (): boolean => {
  return auth !== null && db !== null
}

export const isFirebaseStudio = isFirebaseStudioEnvironment

export { auth, db, storage, functions, analytics }
export default app
