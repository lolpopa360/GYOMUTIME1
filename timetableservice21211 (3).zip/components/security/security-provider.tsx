"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { generateCSRFToken } from "@/lib/security/csrf"

interface SecurityContextType {
  csrfToken: string | null
  refreshCSRFToken: () => void
  reportSecurityIncident: (incident: string, details?: Record<string, any>) => void
}

const SecurityContext = createContext<SecurityContextType | undefined>(undefined)

export function SecurityProvider({ children }: { children: React.ReactNode }) {
  const [csrfToken, setCSRFToken] = useState<string | null>(null)

  const refreshCSRFToken = () => {
    const sessionId =
      document.cookie
        .split("; ")
        .find((row) => row.startsWith("__session="))
        ?.split("=")[1] || crypto.randomUUID()

    const token = generateCSRFToken(sessionId)
    setCSRFToken(token)

    // Set as cookie for form submissions
    document.cookie = `csrf-token=${token}; path=/; secure; samesite=strict`
  }

  const reportSecurityIncident = (incident: string, details?: Record<string, any>) => {
    console.warn(`[Security Incident] ${incident}`, details)

    // In production, send to monitoring service
    if (process.env.NODE_ENV === "production") {
      fetch("/api/security/incident", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken || "",
        },
        body: JSON.stringify({
          incident,
          details,
          timestamp: new Date().toISOString(),
          userAgent: navigator.userAgent,
          url: window.location.href,
        }),
      }).catch(console.error)
    }
  }

  useEffect(() => {
    refreshCSRFToken()

    // Refresh token every 30 minutes
    const interval = setInterval(refreshCSRFToken, 30 * 60 * 1000)

    return () => clearInterval(interval)
  }, [])

  // Add global error handler for security incidents
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.error?.name === "SecurityError") {
        reportSecurityIncident("JavaScript Security Error", {
          message: event.error.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
        })
      }
    }

    window.addEventListener("error", handleError)
    return () => window.removeEventListener("error", handleError)
  }, [csrfToken])

  const value = {
    csrfToken,
    refreshCSRFToken,
    reportSecurityIncident,
  }

  return <SecurityContext.Provider value={value}>{children}</SecurityContext.Provider>
}

export function useSecurity() {
  const context = useContext(SecurityContext)
  if (context === undefined) {
    throw new Error("useSecurity must be used within a SecurityProvider")
  }
  return context
}
