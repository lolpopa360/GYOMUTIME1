"use client"

import React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, RefreshCw, Home, Bug, Shield } from "lucide-react"
import { AnalyticsService } from "@/lib/firebase/analytics"
import { ErrorHandler } from "@/lib/firebase/error-handler"

interface ErrorBoundaryState {
  hasError: boolean
  error?: Error
  errorInfo?: React.ErrorInfo
  errorId?: string
}

interface ErrorBoundaryProps {
  fallback?: React.ComponentType<{ error: Error; retry: () => void }>
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void
}

export class ErrorBoundary extends React.Component<React.PropsWithChildren<ErrorBoundaryProps>, ErrorBoundaryState> {
  private retryTimeoutId: number | null = null

  constructor(props: React.PropsWithChildren<ErrorBoundaryProps>) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    const errorId = `ERR_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    return {
      hasError: true,
      error,
      errorId,
    }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("[v0] Error caught by boundary:", error, errorInfo)

    this.setState({ errorInfo })

    // Log error to analytics
    AnalyticsService.logError("react_error_boundary", {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      errorId: this.state.errorId,
    })

    // Handle error with our error handler
    const appError = ErrorHandler.handleGenericError(error, "react_error_boundary")

    // Call custom error handler if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo)
    }

    // Report to external service in production
    if (process.env.NODE_ENV === "production") {
      this.reportErrorToService(error, errorInfo)
    }
  }

  private reportErrorToService = async (error: Error, errorInfo: React.ErrorInfo) => {
    try {
      // This would integrate with services like Sentry, LogRocket, etc.
      console.log("[v0] Reporting error to monitoring service:", {
        message: error.message,
        stack: error.stack,
        componentStack: errorInfo.componentStack,
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
      })
    } catch (reportingError) {
      console.error("[v0] Failed to report error:", reportingError)
    }
  }

  private handleRetry = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined })

    // Clear any existing timeout
    if (this.retryTimeoutId) {
      window.clearTimeout(this.retryTimeoutId)
    }

    // Log retry attempt
    AnalyticsService.logUserAction("error_boundary_retry", {
      errorId: this.state.errorId,
    })
  }

  private handleGoHome = () => {
    AnalyticsService.logUserAction("error_boundary_home", {
      errorId: this.state.errorId,
    })
    window.location.href = "/"
  }

  private handleReload = () => {
    AnalyticsService.logUserAction("error_boundary_reload", {
      errorId: this.state.errorId,
    })
    window.location.reload()
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        const FallbackComponent = this.props.fallback
        return <FallbackComponent error={this.state.error!} retry={this.handleRetry} />
      }

      return (
        <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-card/30 flex items-center justify-center p-4">
          <div className="w-full max-w-lg space-y-6">
            <div className="text-center space-y-2">
              <div className="mx-auto w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
              <h1 className="text-2xl font-bold text-foreground font-heading">문제가 발생했습니다</h1>
              <p className="text-muted-foreground text-balance">
                예상치 못한 오류가 발생했습니다. 아래 옵션을 시도해보세요.
              </p>
            </div>

            <Card className="auth-card">
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-lg flex items-center justify-center gap-2">
                  <Bug className="h-5 w-5" />
                  오류 정보
                </CardTitle>
                <CardDescription>
                  오류 ID: <code className="bg-muted px-2 py-1 rounded text-xs">{this.state.errorId}</code>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="notification-error">
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    시스템에서 예상치 못한 문제가 발생했습니다. 문제가 지속되면 관리자에게 문의해주세요.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-1 gap-3">
                  <Button onClick={this.handleRetry} className="auth-button-primary">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    다시 시도
                  </Button>
                  <Button onClick={this.handleReload} variant="outline" className="bg-transparent">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    페이지 새로고침
                  </Button>
                  <Button onClick={this.handleGoHome} variant="outline" className="bg-transparent">
                    <Home className="h-4 w-4 mr-2" />
                    홈으로 돌아가기
                  </Button>
                </div>

                {process.env.NODE_ENV === "development" && this.state.error && (
                  <details className="mt-4">
                    <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground transition-colors">
                      개발자 정보 (개발 모드에서만 표시)
                    </summary>
                    <div className="mt-2 space-y-2">
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs font-medium text-foreground mb-1">Error Message:</p>
                        <p className="text-xs text-muted-foreground">{this.state.error.message}</p>
                      </div>
                      {this.state.error.stack && (
                        <div className="bg-muted p-3 rounded-lg">
                          <p className="text-xs font-medium text-foreground mb-1">Stack Trace:</p>
                          <pre className="text-xs text-muted-foreground overflow-auto max-h-32">
                            {this.state.error.stack}
                          </pre>
                        </div>
                      )}
                      {this.state.errorInfo?.componentStack && (
                        <div className="bg-muted p-3 rounded-lg">
                          <p className="text-xs font-medium text-foreground mb-1">Component Stack:</p>
                          <pre className="text-xs text-muted-foreground overflow-auto max-h-32">
                            {this.state.errorInfo.componentStack}
                          </pre>
                        </div>
                      )}
                    </div>
                  </details>
                )}
              </CardContent>
            </Card>

            <div className="text-center">
              <p className="text-xs text-muted-foreground text-balance">
                문제가 계속 발생하면{" "}
                <a href="/contact" className="auth-link">
                  고객지원
                </a>
                에 문의해주세요.
              </p>
            </div>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}

export default ErrorBoundary
