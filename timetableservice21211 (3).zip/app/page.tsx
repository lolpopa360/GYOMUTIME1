import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, ArrowRight, Cpu, Database, Zap, BarChart3, Binary, Network } from "lucide-react"
import { AuthButton } from "@/components/auth/auth-button"
import { Logo } from "@/components/ui/logo"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <Logo size="md" />
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/guide" className="text-muted-foreground hover:text-foreground transition-colors">
                  이용 가이드
                </Link>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  문의하기
                </Link>
                <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                  FAQ
                </Link>
              </nav>
              <AuthButton />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Binary className="h-4 w-4" />
            <span>AI-Powered Optimization Engine</span>
          </div>
          <h1 className="text-5xl font-bold text-foreground mb-6">
            지능형 시간표 <span className="text-primary">최적화</span> 시스템
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            고급 알고리즘과 머신러닝을 활용한 차세대 스케줄링 솔루션. 복잡한 제약 조건을 자동으로 분석하고 최적의
            시간표를 생성합니다.
          </p>

          <div className="flex justify-center space-x-4 mb-12">
            <Link href="/auth">
              <Button size="lg" className="px-8">
                무료로 시작하기
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/guide">
              <Button variant="outline" size="lg" className="px-8 bg-transparent">
                서비스 둘러보기
              </Button>
            </Link>
          </div>

          <div className="flex justify-center space-x-8 mb-12 text-sm">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">99.7%</div>
              <div className="text-muted-foreground">최적화 성공률</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">&lt;30s</div>
              <div className="text-muted-foreground">평균 처리 시간</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">1000+</div>
              <div className="text-muted-foreground">제약 조건 처리</div>
            </div>
          </div>

          {/* Service Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mt-16">
            <Card className="group hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 border-border bg-card relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardHeader className="text-center pb-4 relative">
                <div className="mx-auto mb-4 p-4 bg-primary/10 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                  <Network className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-2xl font-bold text-card-foreground">시간표 최적화</CardTitle>
                <CardDescription className="text-muted-foreground">
                  다중 제약 조건 기반 스케줄링 알고리즘으로 완벽한 시간표를 생성
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center relative">
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <Cpu className="h-4 w-4 text-primary" />
                    <span>AI 기반 리소스 할당</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <BarChart3 className="h-4 w-4 text-primary" />
                    <span>실시간 충돌 분석 및 해결</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <Database className="h-4 w-4 text-primary" />
                    <span>대용량 데이터 처리</span>
                  </div>
                </div>
                <Link href="/dashboard">
                  <Button className="w-full group-hover:bg-primary/90 transition-colors">
                    시간표 최적화 시작
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg hover:shadow-secondary/10 transition-all duration-300 border-border bg-card relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardHeader className="text-center pb-4 relative">
                <div className="mx-auto mb-4 p-4 bg-secondary/10 rounded-xl w-fit group-hover:bg-secondary/20 transition-colors">
                  <Users className="h-8 w-8 text-secondary" />
                </div>
                <CardTitle className="text-2xl font-bold text-card-foreground">선택과목 분반 알고리즘</CardTitle>
                <CardDescription className="text-muted-foreground">
                  학생 선호도와 제약 조건을 동시에 고려한 지능형 분반 배정
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center relative">
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <Binary className="h-4 w-4 text-secondary" />
                    <span>머신러닝 기반 패턴 분석</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <Network className="h-4 w-4 text-secondary" />
                    <span>다차원 최적화 엔진</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <BarChart3 className="h-4 w-4 text-secondary" />
                    <span>실시간 균형도 분석</span>
                  </div>
                </div>
                <Link href="/dashboard">
                  <Button variant="secondary" className="w-full group-hover:bg-secondary/90 transition-colors">
                    분반 알고리즘 실행
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">시스템 아키텍처 & 성능</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              최첨단 컴퓨팅 기술과 검증된 알고리즘으로 구축된 고성능 스케줄링 엔진
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="mx-auto mb-4 p-4 bg-primary/10 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">고성능 컴퓨팅</h3>
              <p className="text-muted-foreground">병렬 처리와 분산 컴퓨팅으로 대규모 스케줄링 문제를 실시간 해결</p>
            </div>

            <div className="text-center group">
              <div className="mx-auto mb-4 p-4 bg-secondary/10 rounded-xl w-fit group-hover:bg-secondary/20 transition-colors">
                <Database className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">빅데이터 처리</h3>
              <p className="text-muted-foreground">수천 개의 변수와 제약 조건을 동시에 분석하는 고급 데이터 엔진</p>
            </div>

            <div className="text-center group">
              <div className="mx-auto mb-4 p-4 bg-primary/10 rounded-xl w-fit group-hover:bg-primary/20 transition-colors">
                <Cpu className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">OR-Tools 엔진</h3>
              <p className="text-muted-foreground">Google의 검증된 최적화 라이브러리 기반 차세대 솔버 시스템</p>
            </div>
          </div>

          <div className="mt-16 grid md:grid-cols-4 gap-6">
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-2xl font-bold text-primary mb-2">10,000+</div>
              <div className="text-sm text-muted-foreground">동시 처리 가능한 변수 수</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-2xl font-bold text-secondary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">복합 제약 조건 지원</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-2xl font-bold text-primary mb-2">99.9%</div>
              <div className="text-sm text-muted-foreground">시스템 가용성</div>
            </div>
            <div className="bg-card p-6 rounded-lg border border-border text-center">
              <div className="text-2xl font-bold text-secondary mb-2">24/7</div>
              <div className="text-sm text-muted-foreground">무중단 서비스</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <Logo size="sm" className="mb-4" />
              <p className="text-muted-foreground text-sm">
                AI 기반 스케줄링 최적화 플랫폼으로 교육 기관의 시간표 관리를 혁신합니다.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">서비스</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/dashboard" className="hover:text-foreground transition-colors">
                    시간표 최적화
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="hover:text-foreground transition-colors">
                    분반 알고리즘
                  </Link>
                </li>
                <li>
                  <Link href="/guide" className="hover:text-foreground transition-colors">
                    이용 가이드
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">지원</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/contact" className="hover:text-foreground transition-colors">
                    문의하기
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard/inquiries" className="hover:text-foreground transition-colors">
                    고객지원
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">정보</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/terms" className="hover:text-foreground transition-colors">
                    이용약관
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-foreground transition-colors">
                    개인정보처리방침
                  </Link>
                </li>
                <li>
                  <Link href="/admin/auth" className="hover:text-foreground transition-colors">
                    관리자
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="text-center pt-8 border-t border-border">
            <p className="text-muted-foreground text-sm">
              © 2024 교무타임. 모든 권리 보유. AI 기반 스케줄링 최적화 플랫폼
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
