"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Plus, Search, Edit, Trash2, Tag, Calendar, AlertCircle, FileText, X } from "lucide-react"
import { getUserNotes, createNote, updateNote, deleteNote } from "@/lib/firebase/firestore"
import type { Note } from "@/lib/firebase/firestore"
import { useToast } from "@/hooks/use-toast"

export default function NotesPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [notes, setNotes] = useState<Note[]>([])
  const [filteredNotes, setFilteredNotes] = useState<Note[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")
  const [tagFilter, setTagFilter] = useState<string>("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingNote, setEditingNote] = useState<Note | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  // Form states
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium")
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")

  useEffect(() => {
    loadNotes()
  }, [user])

  useEffect(() => {
    filterNotes()
  }, [notes, searchTerm, priorityFilter, tagFilter])

  const loadNotes = async () => {
    if (!user) return

    try {
      const userNotes = await getUserNotes(user.uid)
      setNotes(userNotes)
    } catch (error) {
      console.error("Error loading notes:", error)
      toast({
        title: "오류",
        description: "메모를 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterNotes = () => {
    let filtered = notes

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (note) =>
          note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          note.content.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Priority filter
    if (priorityFilter !== "all") {
      filtered = filtered.filter((note) => note.priority === priorityFilter)
    }

    // Tag filter
    if (tagFilter !== "all") {
      filtered = filtered.filter((note) => note.tags.includes(tagFilter))
    }

    setFilteredNotes(filtered)
  }

  const resetForm = () => {
    setTitle("")
    setContent("")
    setPriority("medium")
    setTags([])
    setNewTag("")
    setEditingNote(null)
  }

  const handleCreateNote = async () => {
    if (!user || !title.trim() || !content.trim()) return

    try {
      await createNote({
        userId: user.uid,
        title: title.trim(),
        content: content.trim(),
        priority,
        tags,
      })

      toast({
        title: "성공",
        description: "메모가 성공적으로 생성되었습니다.",
      })

      resetForm()
      setIsCreateDialogOpen(false)
      loadNotes()
    } catch (error) {
      console.error("Error creating note:", error)
      toast({
        title: "오류",
        description: "메모 생성 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleEditNote = async () => {
    if (!editingNote || !title.trim() || !content.trim()) return

    try {
      await updateNote(editingNote.id!, {
        title: title.trim(),
        content: content.trim(),
        priority,
        tags,
      })

      toast({
        title: "성공",
        description: "메모가 성공적으로 수정되었습니다.",
      })

      resetForm()
      setIsEditDialogOpen(false)
      loadNotes()
    } catch (error) {
      console.error("Error updating note:", error)
      toast({
        title: "오류",
        description: "메모 수정 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteNote = async (noteId: string) => {
    try {
      await deleteNote(noteId)
      toast({
        title: "성공",
        description: "메모가 성공적으로 삭제되었습니다.",
      })
      loadNotes()
    } catch (error) {
      console.error("Error deleting note:", error)
      toast({
        title: "오류",
        description: "메모 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (note: Note) => {
    setEditingNote(note)
    setTitle(note.title)
    setContent(note.content)
    setPriority(note.priority)
    setTags(note.tags)
    setIsEditDialogOpen(true)
  }

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()])
      setNewTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const allTags = Array.from(new Set(notes.flatMap((note) => note.tags)))

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      case "low":
        return "outline"
      default:
        return "outline"
    }
  }

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case "high":
        return "높음"
      case "medium":
        return "보통"
      case "low":
        return "낮음"
      default:
        return "보통"
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">메모를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground">메모 관리</h1>
          <p className="text-muted-foreground">중요한 정보와 아이디어를 체계적으로 관리하세요</p>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-enhanced btn-primary-enhanced">
              <Plus className="h-4 w-4 mr-2" />새 메모 작성
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>새 메모 작성</DialogTitle>
              <DialogDescription>새로운 메모를 작성하여 중요한 정보를 저장하세요</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="title">제목</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="메모 제목을 입력하세요"
                />
              </div>

              <div>
                <Label htmlFor="content">내용</Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="메모 내용을 입력하세요"
                  rows={6}
                />
              </div>

              <div>
                <Label htmlFor="priority">우선순위</Label>
                <Select value={priority} onValueChange={(value: "low" | "medium" | "high") => setPriority(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">낮음</SelectItem>
                    <SelectItem value="medium">보통</SelectItem>
                    <SelectItem value="high">높음</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>태그</Label>
                <div className="flex items-center space-x-2 mb-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="태그 추가"
                    onKeyPress={(e) => e.key === "Enter" && addTag()}
                  />
                  <Button type="button" onClick={addTag} size="sm" className="btn-enhanced btn-secondary-enhanced">
                    추가
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                      {tag}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeTag(tag)} />
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)} className="btn-enhanced">
                취소
              </Button>
              <Button
                onClick={handleCreateNote}
                disabled={!title.trim() || !content.trim()}
                className="btn-enhanced btn-primary-enhanced"
              >
                메모 생성
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="메모 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="우선순위" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 우선순위</SelectItem>
                <SelectItem value="high">높음</SelectItem>
                <SelectItem value="medium">보통</SelectItem>
                <SelectItem value="low">낮음</SelectItem>
              </SelectContent>
            </Select>

            <Select value={tagFilter} onValueChange={setTagFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="태그" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 태그</SelectItem>
                {allTags.map((tag) => (
                  <SelectItem key={tag} value={tag}>
                    {tag}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">총 메모</p>
                <p className="text-2xl font-bold text-primary">{notes.length}</p>
              </div>
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">높은 우선순위</p>
                <p className="text-2xl font-bold text-destructive">
                  {notes.filter((n) => n.priority === "high").length}
                </p>
              </div>
              <AlertCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">태그 수</p>
                <p className="text-2xl font-bold text-secondary">{allTags.length}</p>
              </div>
              <Tag className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">이번 주 생성</p>
                <p className="text-2xl font-bold text-primary">
                  {
                    notes.filter((n) => {
                      const weekAgo = new Date()
                      weekAgo.setDate(weekAgo.getDate() - 7)
                      return n.createdAt > weekAgo
                    }).length
                  }
                </p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notes Grid */}
      {filteredNotes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNotes.map((note) => (
            <Card key={note.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg line-clamp-2">{note.title}</CardTitle>
                  <Badge variant={getPriorityColor(note.priority)} className="ml-2 shrink-0">
                    {getPriorityText(note.priority)}
                  </Badge>
                </div>
                <CardDescription className="text-xs text-muted-foreground">
                  {note.updatedAt.toLocaleDateString("ko-KR")} •{" "}
                  {note.updatedAt.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" })}
                </CardDescription>
              </CardHeader>

              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground line-clamp-4 mb-4">{note.content}</p>

                {note.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-4">
                    {note.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                <div className="flex justify-end space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditDialog(note)}
                    className="btn-enhanced hover-lift"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive btn-enhanced hover-lift"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>메모 삭제</AlertDialogTitle>
                        <AlertDialogDescription>
                          이 메모를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>취소</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteNote(note.id!)}
                          className="bg-destructive hover:bg-destructive/90 btn-enhanced"
                        >
                          삭제
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">메모가 없습니다</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || priorityFilter !== "all" || tagFilter !== "all"
                ? "검색 조건에 맞는 메모가 없습니다"
                : "첫 번째 메모를 작성해보세요"}
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="btn-enhanced btn-primary-enhanced">
              <Plus className="h-4 w-4 mr-2" />새 메모 작성
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>메모 수정</DialogTitle>
            <DialogDescription>메모 내용을 수정하세요</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-title">제목</Label>
              <Input
                id="edit-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="메모 제목을 입력하세요"
              />
            </div>

            <div>
              <Label htmlFor="edit-content">내용</Label>
              <Textarea
                id="edit-content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="메모 내용을 입력하세요"
                rows={6}
              />
            </div>

            <div>
              <Label htmlFor="edit-priority">우선순위</Label>
              <Select value={priority} onValueChange={(value: "low" | "medium" | "high") => setPriority(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">낮음</SelectItem>
                  <SelectItem value="medium">보통</SelectItem>
                  <SelectItem value="high">높음</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>태그</Label>
              <div className="flex items-center space-x-2 mb-2">
                <Input
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="태그 추가"
                  onKeyPress={(e) => e.key === "Enter" && addTag()}
                />
                <Button type="button" onClick={addTag} size="sm" className="btn-enhanced btn-secondary-enhanced">
                  추가
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <X className="h-3 w-3 cursor-pointer" onClick={() => removeTag(tag)} />
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="btn-enhanced">
              취소
            </Button>
            <Button
              onClick={handleEditNote}
              disabled={!title.trim() || !content.trim()}
              className="btn-enhanced btn-primary-enhanced"
            >
              메모 수정
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
