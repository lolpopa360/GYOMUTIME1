"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  Download,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  FileText,
  Calendar,
  RefreshCw,
  Eye,
  MapPin,
  Timer,
  Users,
  Network,
} from "lucide-react"
import Link from "next/link"
import { getUserSubmissions } from "@/lib/supabase/database"
import type { Submission } from "@/lib/supabase/database"
import { useToast } from "@/hooks/use-toast"

interface RequestWithEstimate extends Submission {
  estimatedCompletion?: Date
  queuePosition?: number
  processingStage?: string
}

export default function RequestTrackingPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [requests, setRequests] = useState<RequestWithEstimate[]>([])
  const [filteredRequests, setFilteredRequests] = useState<RequestWithEstimate[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [activeView, setActiveView] = useState<"list" | "timeline">("list")

  useEffect(() => {
    loadRequests()
    // Set up real-time updates every 30 seconds
    const interval = setInterval(loadRequests, 30000)
    return () => clearInterval(interval)
  }, [user])

  useEffect(() => {
    filterRequests()
  }, [requests, searchTerm, statusFilter, typeFilter])

  const loadRequests = async () => {
    if (!user) return

    try {
      const userSubmissions = await getUserSubmissions(user.id)

      // Enhance submissions with estimated completion and queue position
      const enhancedRequests: RequestWithEstimate[] = userSubmissions.map((submission, index) => ({
        ...submission,
        estimatedCompletion: getEstimatedCompletion(submission),
        queuePosition: submission.status === "pending" ? index + 1 : undefined,
        processingStage: getProcessingStage(submission),
      }))

      setRequests(enhancedRequests)
    } catch (error) {
      console.error("Error loading requests:", error)
      toast({
        title: "오류",
        description: "요청 목록을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getEstimatedCompletion = (submission: Submission): Date => {
    const now = new Date()
    const baseMinutes = submission.type === "timetable" ? 15 : 10

    switch (submission.status) {
      case "pending":
        return new Date(now.getTime() + baseMinutes * 60000)
      case "processing":
        return new Date(now.getTime() + (baseMinutes / 2) * 60000)
      case "completed":
        return submission.completed_at ? new Date(submission.completed_at) : new Date(submission.updated_at)
      default:
        return now
    }
  }

  const getProcessingStage = (submission: Submission): string => {
    switch (submission.status) {
      case "pending":
        return "대기열에서 순서를 기다리는 중"
      case "processing":
        return submission.type === "timetable" ? "시간표 최적화 알고리즘 실행 중" : "분반 배정 알고리즘 분석 중"
      case "completed":
        return "처리 완료 - 결과 다운로드 가능"
      case "failed":
        return "처리 중 오류 발생 - 재시도 필요"
      default:
        return "상태 확인 중"
    }
  }

  const filterRequests = () => {
    let filtered = requests

    if (searchTerm) {
      filtered = filtered.filter(
        (request) =>
          request.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          request.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((request) => request.status === statusFilter)
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter((request) => request.type === typeFilter)
    }

    setFilteredRequests(filtered)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            <Clock className="h-3 w-3 mr-1" />
            대기중
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
            <Play className="h-3 w-3 mr-1 animate-pulse" />
            처리중
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="default" className="bg-green-500/10 text-green-600 border-green-500/20">
            <CheckCircle className="h-3 w-3 mr-1" />
            완료
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="destructive" className="bg-red-500/10 text-red-600 border-red-500/20">
            <AlertCircle className="h-3 w-3 mr-1" />
            실패
          </Badge>
        )
      default:
        return <Badge variant="outline">알 수 없음</Badge>
    }
  }

  const getProgressValue = (status: string) => {
    switch (status) {
      case "pending":
        return 25
      case "processing":
        return 75
      case "completed":
        return 100
      case "failed":
        return 0
      default:
        return 0
    }
  }

  const formatTimeRemaining = (estimatedCompletion: Date) => {
    const now = new Date()
    const diff = estimatedCompletion.getTime() - now.getTime()

    if (diff <= 0) return "곧 완료"

    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)

    if (hours > 0) {
      return `약 ${hours}시간 ${minutes % 60}분 후`
    }
    return `약 ${minutes}분 후`
  }

  const pendingCount = requests.filter((r) => r.status === "pending").length
  const processingCount = requests.filter((r) => r.status === "processing").length
  const completedCount = requests.filter((r) => r.status === "completed").length
  const failedCount = requests.filter((r) => r.status === "failed").length

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">요청 현황을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground">실시간 요청 추적</h1>
          <p className="text-muted-foreground">모든 요청의 실시간 진행 상황을 상세히 추적하고 관리하세요</p>
        </div>

        <div className="flex items-center space-x-2">
          <Button onClick={loadRequests} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            새로고침
          </Button>
          <Badge variant="secondary" className="bg-primary/10 text-primary">
            실시간 업데이트
          </Badge>
        </div>
      </div>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">대기열</p>
                <p className="text-2xl font-bold text-blue-600">{pendingCount}</p>
                <p className="text-xs text-muted-foreground">처리 대기 중</p>
              </div>
              <div className="p-2 bg-blue-500/10 rounded-lg">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">실행 중</p>
                <p className="text-2xl font-bold text-yellow-600">{processingCount}</p>
                <p className="text-xs text-muted-foreground">알고리즘 처리 중</p>
              </div>
              <div className="p-2 bg-yellow-500/10 rounded-lg">
                <Play className="h-6 w-6 text-yellow-600 animate-pulse" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">완료</p>
                <p className="text-2xl font-bold text-green-600">{completedCount}</p>
                <p className="text-xs text-muted-foreground">다운로드 가능</p>
              </div>
              <div className="p-2 bg-green-500/10 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">실패</p>
                <p className="text-2xl font-bold text-red-600">{failedCount}</p>
                <p className="text-xs text-muted-foreground">재시도 필요</p>
              </div>
              <div className="p-2 bg-red-500/10 rounded-lg">
                <AlertCircle className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="요청 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="상태" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 상태</SelectItem>
                <SelectItem value="pending">대기중</SelectItem>
                <SelectItem value="processing">처리중</SelectItem>
                <SelectItem value="completed">완료</SelectItem>
                <SelectItem value="failed">실패</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="유형" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 유형</SelectItem>
                <SelectItem value="timetable">시간표 최적화</SelectItem>
                <SelectItem value="electives">선택과목 분반</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Request List */}
      {filteredRequests.length > 0 ? (
        <div className="space-y-4">
          {filteredRequests.map((request) => (
            <Card key={request.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold">{request.title}</h3>
                      {getStatusBadge(request.status)}
                      <Badge variant="outline" className="text-xs">
                        {request.type === "timetable" ? (
                          <>
                            <Network className="h-3 w-3 mr-1" />
                            시간표 최적화
                          </>
                        ) : (
                          <>
                            <Users className="h-3 w-3 mr-1" />
                            선택과목 분반
                          </>
                        )}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{request.description}</p>

                    {/* Processing Stage */}
                    <div className="flex items-center space-x-2 mb-3">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{request.processingStage}</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="mb-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-muted-foreground">진행률</span>
                        <span className="text-sm font-medium">{getProgressValue(request.status)}%</span>
                      </div>
                      <Progress value={getProgressValue(request.status)} className="h-2" />
                    </div>

                    {/* Timing Information */}
                    <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>제출: {new Date(request.created_at).toLocaleDateString("ko-KR")}</span>
                      </div>

                      {request.status === "pending" && request.queuePosition && (
                        <div className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>대기열 {request.queuePosition}번째</span>
                        </div>
                      )}

                      {(request.status === "pending" || request.status === "processing") &&
                        request.estimatedCompletion && (
                          <div className="flex items-center space-x-1">
                            <Timer className="h-4 w-4" />
                            <span>{formatTimeRemaining(request.estimatedCompletion)}</span>
                          </div>
                        )}

                      {request.status === "completed" && request.completed_at && (
                        <div className="flex items-center space-x-1">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span>완료: {new Date(request.completed_at).toLocaleDateString("ko-KR")}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center space-x-2 ml-4">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>

                    {request.status === "completed" && (
                      <Button variant="default" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        다운로드
                      </Button>
                    )}

                    {request.status === "failed" && (
                      <Button variant="outline" size="sm">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        재시도
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">요청이 없습니다</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                ? "검색 조건에 맞는 요청이 없습니다"
                : "아직 제출한 요청이 없습니다"}
            </p>
            <div className="flex justify-center space-x-4">
              <Link href="/customer/timetable">
                <Button>
                  <Network className="h-4 w-4 mr-2" />
                  시간표 최적화
                </Button>
              </Link>
              <Link href="/customer/electives">
                <Button variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  선택과목 분반
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
