interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
  hits: number
}

interface CacheStats {
  totalEntries: number
  hitRate: number
  missRate: number
  memoryUsage: number
}

export class CacheManager {
  private cache = new Map<string, CacheEntry<any>>()
  private maxSize: number
  private defaultTTL: number
  private stats = {
    hits: 0,
    misses: 0,
    sets: 0,
    deletes: 0,
  }

  constructor(maxSize = 1000, defaultTTL = 300000) {
    // 5 minutes default
    this.maxSize = maxSize
    this.defaultTTL = defaultTTL

    // Clean up expired entries every minute
    setInterval(() => this.cleanup(), 60000)
  }

  set<T>(key: string, data: T, ttl?: number): void {
    const now = Date.now()
    const entry: CacheEntry<T> = {
      data,
      timestamp: now,
      ttl: ttl || this.defaultTTL,
      hits: 0,
    }

    // If cache is full, remove least recently used
    if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
      this.evictLRU()
    }

    this.cache.set(key, entry)
    this.stats.sets++

    console.log(`[v0] Cache set: ${key}`)
  }

  get<T>(key: string): T | null {
    const entry = this.cache.get(key)

    if (!entry) {
      this.stats.misses++
      console.log(`[v0] Cache miss: ${key}`)
      return null
    }

    const now = Date.now()
    if (now - entry.timestamp > entry.ttl) {
      this.cache.delete(key)
      this.stats.misses++
      console.log(`[v0] Cache expired: ${key}`)
      return null
    }

    entry.hits++
    this.stats.hits++
    console.log(`[v0] Cache hit: ${key}`)
    return entry.data
  }

  async warmCache(keys: string[], dataLoader: (key: string) => Promise<any>): Promise<void> {
    console.log(`[v0] Warming cache for ${keys.length} keys`)

    const promises = keys.map(async (key) => {
      try {
        const data = await dataLoader(key)
        this.set(key, data)
      } catch (error) {
        console.error(`[v0] Failed to warm cache for ${key}:`, error)
      }
    })

    await Promise.all(promises)
    console.log(`[v0] Cache warming complete`)
  }

  private evictLRU(): void {
    let oldestKey = ""
    let oldestTime = Date.now()

    for (const [key, entry] of this.cache.entries()) {
      const lastAccess = entry.timestamp + entry.hits * 1000 // Factor in hit frequency
      if (lastAccess < oldestTime) {
        oldestTime = lastAccess
        oldestKey = key
      }
    }

    if (oldestKey) {
      this.cache.delete(oldestKey)
      this.stats.deletes++
      console.log(`[v0] Evicted LRU entry: ${oldestKey}`)
    }
  }

  private cleanup(): void {
    const now = Date.now()
    let cleaned = 0

    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key)
        cleaned++
      }
    }

    if (cleaned > 0) {
      console.log(`[v0] Cleaned up ${cleaned} expired cache entries`)
    }
  }

  getStats(): CacheStats {
    const totalRequests = this.stats.hits + this.stats.misses
    return {
      totalEntries: this.cache.size,
      hitRate: totalRequests > 0 ? (this.stats.hits / totalRequests) * 100 : 0,
      missRate: totalRequests > 0 ? (this.stats.misses / totalRequests) * 100 : 0,
      memoryUsage: this.estimateMemoryUsage(),
    }
  }

  private estimateMemoryUsage(): number {
    let size = 0
    for (const [key, entry] of this.cache.entries()) {
      size += key.length * 2 // UTF-16 characters
      size += JSON.stringify(entry.data).length * 2
      size += 64 // Estimated overhead per entry
    }
    return size
  }

  clear(): void {
    this.cache.clear()
    this.stats = { hits: 0, misses: 0, sets: 0, deletes: 0 }
    console.log("[v0] Cache cleared")
  }

  delete(key: string): boolean {
    const deleted = this.cache.delete(key)
    if (deleted) {
      this.stats.deletes++
      console.log(`[v0] Cache deleted: ${key}`)
    }
    return deleted
  }

  invalidatePattern(pattern: RegExp): number {
    let invalidated = 0
    for (const key of this.cache.keys()) {
      if (pattern.test(key)) {
        this.cache.delete(key)
        invalidated++
      }
    }
    console.log(`[v0] Invalidated ${invalidated} cache entries matching pattern`)
    return invalidated
  }
}

// Global cache instance
export const globalCache = new CacheManager(2000, 600000) // 10 minutes default TTL
