"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { LoginModal } from "./login-modal"
import { LogOut, Settings, Shield } from "lucide-react"

export function AuthButton() {
  const { user, logout, isAuthenticated } = useAuth()
  const [showLoginModal, setShowLoginModal] = useState(false)

  if (isAuthenticated && user) {
    return (
      <div className="flex items-center space-x-2">
        <Link href="/admin">
          <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/10 bg-transparent">
            <Settings className="mr-2 h-4 w-4" />
            관리자 콘솔
          </Button>
        </Link>
        <Button variant="outline" size="sm" onClick={logout} className="hover:bg-destructive/10 bg-transparent">
          <LogOut className="mr-2 h-4 w-4" />
          로그아웃
        </Button>
      </div>
    )
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setShowLoginModal(true)}
        className="border-primary/20 hover:bg-primary/10"
      >
        <Shield className="mr-2 h-4 w-4" />
        관리자 인증
      </Button>
      <LoginModal open={showLoginModal} onOpenChange={setShowLoginModal} />
    </>
  )
}
