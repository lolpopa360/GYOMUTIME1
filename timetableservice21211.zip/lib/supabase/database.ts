import { createClient } from "./client"

export interface Submission {
  id?: string
  user_id: string
  title: string
  description: string
  status: "pending" | "processing" | "completed" | "failed"
  type: "timetable" | "electives"
  data: any
  created_at: string
  updated_at: string
  completed_at?: string
}

export interface Note {
  id?: string
  user_id: string
  title: string
  content: string
  priority: "low" | "medium" | "high"
  tags: string[]
  created_at: string
  updated_at: string
}

export interface Feedback {
  id?: string
  user_id: string
  rating: number
  comment: string
  category: "bug" | "feature" | "general"
  status: "open" | "in-progress" | "resolved"
  created_at: string
}

export interface Notification {
  id?: string
  user_id: string
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
  category: "submission" | "system" | "reminder" | "update"
  is_read: boolean
  action_url?: string
  action_text?: string
  metadata?: any
  created_at: string
  read_at?: string
}

// Submissions
export const createSubmission = async (submission: Omit<Submission, "id" | "created_at" | "updated_at">) => {
  const supabase = createClient()

  const { data, error } = await supabase.from("submissions").insert(submission).select().single()

  if (error) throw error
  return data.id
}

export const updateSubmissionStatus = async (id: string, status: Submission["status"], completed_at?: string) => {
  const supabase = createClient()

  const updateData: any = {
    status,
    updated_at: new Date().toISOString(),
  }

  if (completed_at) {
    updateData.completed_at = completed_at
  }

  const { error } = await supabase.from("submissions").update(updateData).eq("id", id)

  if (error) throw error
}

export const getUserSubmissions = async (userId: string): Promise<Submission[]> => {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("submissions")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data || []
}

// Notes
export const createNote = async (note: Omit<Note, "id" | "created_at" | "updated_at">) => {
  const supabase = createClient()

  const { data, error } = await supabase.from("notes").insert(note).select().single()

  if (error) throw error
  return data.id
}

export const updateNote = async (id: string, updates: Partial<Omit<Note, "id" | "user_id" | "created_at">>) => {
  const supabase = createClient()

  const { error } = await supabase
    .from("notes")
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq("id", id)

  if (error) throw error
}

export const deleteNote = async (id: string) => {
  const supabase = createClient()

  const { error } = await supabase.from("notes").delete().eq("id", id)

  if (error) throw error
}

export const getUserNotes = async (userId: string): Promise<Note[]> => {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("notes")
    .select("*")
    .eq("user_id", userId)
    .order("updated_at", { ascending: false })

  if (error) throw error
  return data || []
}

// Feedback
export const createFeedback = async (feedback: Omit<Feedback, "id" | "created_at">) => {
  const supabase = createClient()

  const { data, error } = await supabase.from("feedback").insert(feedback).select().single()

  if (error) throw error
  return data.id
}

export const getAllFeedback = async (): Promise<Feedback[]> => {
  const supabase = createClient()

  const { data, error } = await supabase.from("feedback").select("*").order("created_at", { ascending: false })

  if (error) throw error
  return data || []
}

// Notifications
export const createNotification = async (notification: Omit<Notification, "id" | "created_at">) => {
  const supabase = createClient()

  const { data, error } = await supabase.from("notifications").insert(notification).select().single()

  if (error) throw error
  return data.id
}

export const markNotificationAsRead = async (id: string) => {
  const supabase = createClient()

  const { error } = await supabase
    .from("notifications")
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq("id", id)

  if (error) throw error
}

export const markAllNotificationsAsRead = async (userId: string) => {
  const supabase = createClient()

  const { error } = await supabase
    .from("notifications")
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq("user_id", userId)
    .eq("is_read", false)

  if (error) throw error
}

export const deleteNotification = async (id: string) => {
  const supabase = createClient()

  const { error } = await supabase.from("notifications").delete().eq("id", id)

  if (error) throw error
}

export const getUserNotifications = async (userId: string): Promise<Notification[]> => {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data || []
}

export const getUnreadNotificationCount = async (userId: string): Promise<number> => {
  try {
    const supabase = createClient()

    const { count, error } = await supabase
      .from("notifications")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("is_read", false)

    if (error) throw error
    return count || 0
  } catch (error) {
    console.error("Error getting unread count:", error)
    return 0
  }
}
