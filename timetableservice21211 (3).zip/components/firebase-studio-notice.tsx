"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { X, ExternalLink, Info, AlertTriangle } from "lucide-react"

export function FirebaseStudioNotice() {
  const [isVisible, setIsVisible] = useState(false)
  const [currentDomain, setCurrentDomain] = useState("")
  const [hasWorkspaceError, setHasWorkspaceError] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const domain = window.location.hostname
      setCurrentDomain(domain)

      // Show notice for Firebase Studio environments
      const isStudioEnvironment =
        domain.includes("firebase") ||
        domain.includes("web.app") ||
        domain.includes("firebaseapp.com") ||
        domain.includes("v0.app") ||
        domain.includes("vercel.app")

      setIsVisible(isStudioEnvironment)

      // Check for workspace-related errors in console
      const originalError = console.error
      console.error = (...args) => {
        const message = args.join(" ")
        if (message.includes("workspace") || message.includes("invalid argument")) {
          setHasWorkspaceError(true)
        }
        originalError.apply(console, args)
      }
    }
  }, [])

  if (!isVisible) return null

  return (
    <Alert className={`mb-4 ${hasWorkspaceError ? "border-red-200 bg-red-50" : "border-blue-200 bg-blue-50"}`}>
      {hasWorkspaceError ? (
        <AlertTriangle className="h-4 w-4 text-red-600" />
      ) : (
        <Info className="h-4 w-4 text-blue-600" />
      )}
      <AlertDescription className="text-sm">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            {hasWorkspaceError ? (
              <>
                <p className="font-medium text-red-800 mb-2">Firebase Studio 워크스페이스 오류</p>
                <p className="text-red-700 mb-3">"Request contains an invalid argument" 오류가 발생했습니다.</p>
                <p className="text-red-700 mb-3">해결 방법:</p>
                <ol className="text-red-700 text-xs space-y-1 ml-4 list-decimal">
                  <li>Firebase 콘솔에서 현재 도메인 ({currentDomain})을 승인된 도메인에 추가</li>
                  <li>브라우저 설정에서 서드파티 쿠키 활성화</li>
                  <li>팝업 차단 해제</li>
                  <li>브라우저 캐시 및 쿠키 삭제 후 새로고침</li>
                  <li>시크릿/프라이빗 브라우징 모드에서 시도</li>
                </ol>
              </>
            ) : (
              <>
                <p className="font-medium text-blue-800 mb-2">Firebase Studio 환경 감지됨</p>
                <p className="text-blue-700 mb-3">
                  현재 도메인: <code className="bg-blue-100 px-1 rounded">{currentDomain}</code>
                </p>
                <p className="text-blue-700 mb-3">인증이 작동하지 않는 경우:</p>
                <ol className="text-blue-700 text-xs space-y-1 ml-4 list-decimal">
                  <li>브라우저에서 서드파티 쿠키를 활성화하세요</li>
                  <li>Firebase 콘솔에서 현재 도메인을 승인된 도메인에 추가하세요</li>
                  <li>팝업 차단을 해제하세요</li>
                  <li>안정적인 인터넷 연결을 확인하세요</li>
                </ol>
              </>
            )}
            <Button
              variant="outline"
              size="sm"
              className={`mt-2 ${hasWorkspaceError ? "text-red-700 border-red-300 hover:bg-red-100" : "text-blue-700 border-blue-300 hover:bg-blue-100"} bg-transparent`}
              onClick={() => window.open("https://console.firebase.google.com", "_blank")}
            >
              Firebase 콘솔 열기 <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsVisible(false)}
            className={`${hasWorkspaceError ? "text-red-600 hover:bg-red-100" : "text-blue-600 hover:bg-blue-100"} p-1`}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  )
}
