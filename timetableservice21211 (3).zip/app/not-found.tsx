import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home, ArrowLeft } from "lucide-react"

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-md w-full text-center px-6">
        <div className="mb-8">
          <h1 className="text-8xl font-bold text-white mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-white mb-2">페이지를 찾을 수 없습니다</h2>
          <p className="text-gray-300">요청하신 페이지가 존재하지 않거나 이동되었을 수 있습니다.</p>
        </div>

        <div className="space-y-4">
          <Button asChild className="w-full">
            <Link href="/">
              <Home className="w-4 h-4 mr-2" />
              홈으로 돌아가기
            </Link>
          </Button>

          <Button variant="outline" asChild className="w-full bg-transparent">
            <Link href="/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              대시보드로 이동
            </Link>
          </Button>
        </div>

        <div className="mt-8 text-sm text-gray-400">
          <p>
            문제가 지속되면{" "}
            <Link href="/contact" className="text-blue-400 hover:underline">
              고객지원
            </Link>
            에 문의해주세요.
          </p>
        </div>
      </div>
    </div>
  )
}
