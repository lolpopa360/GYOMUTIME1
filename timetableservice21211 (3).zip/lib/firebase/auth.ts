import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
} from "firebase/auth"
import { doc, setDoc, getDoc, collection, getDocs } from "firebase/firestore"
import { auth, db } from "./config"

export interface UserProfile {
  uid: string
  email: string
  name: string
  role: "admin" | "user"
  createdAt: Date
  lastLogin: Date
  updatedAt?: Date
}

export { auth }

const googleProvider = new GoogleAuthProvider()
const SUPER_ADMIN_EMAIL = "yangchanhee11@gmail.com"

// Sign in with email and password
export const signInUser = async (email: string, password: string) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)

    // Update last login
    await setDoc(
      doc(db, "users", userCredential.user.uid),
      {
        lastLogin: new Date(),
      },
      { merge: true },
    )

    return userCredential.user
  } catch (error) {
    throw error
  }
}

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider)
    const user = result.user

    // Check if user profile exists, if not create one
    const userProfile = await getUserProfile(user.uid)
    if (!userProfile) {
      const role = user.email === SUPER_ADMIN_EMAIL ? "admin" : "user"
      const newUserProfile: UserProfile = {
        uid: user.uid,
        email: user.email!,
        name: user.displayName || user.email!.split("@")[0],
        role,
        createdAt: new Date(),
        lastLogin: new Date(),
      }
      await setDoc(doc(db, "users", user.uid), newUserProfile)
    } else {
      // Update last login for existing user
      await setDoc(
        doc(db, "users", user.uid),
        {
          lastLogin: new Date(),
        },
        { merge: true },
      )
    }

    return user
  } catch (error) {
    throw error
  }
}

// Sign up with email and password
export const signUpUser = async (email: string, password: string, name: string) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)

    // Update user profile
    await updateProfile(userCredential.user, {
      displayName: name,
    })

    const role = userCredential.user.email === SUPER_ADMIN_EMAIL ? "admin" : "user"

    // Create user document in Firestore
    const userProfile: UserProfile = {
      uid: userCredential.user.uid,
      email: userCredential.user.email!,
      name,
      role,
      createdAt: new Date(),
      lastLogin: new Date(),
    }

    await setDoc(doc(db, "users", userCredential.user.uid), userProfile)

    return userCredential.user
  } catch (error) {
    throw error
  }
}

// Sign out
export const signOutUser = async () => {
  try {
    await signOut(auth)
  } catch (error) {
    throw error
  }
}

// Get user profile from Firestore
export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  try {
    const docRef = doc(db, "users", uid)
    const docSnap = await getDoc(docRef)

    if (docSnap.exists()) {
      return docSnap.data() as UserProfile
    }
    return null
  } catch (error) {
    console.error("Error getting user profile:", error)
    return null
  }
}

// Check if user is admin
export const isUserAdmin = async (uid: string): Promise<boolean> => {
  try {
    const profile = await getUserProfile(uid)
    return profile?.role === "admin" || false
  } catch (error) {
    console.error("Error checking admin status:", error)
    return false
  }
}

// Auth state observer
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback)
}

// Admin management functions
export const updateUserRole = async (uid: string, role: "admin" | "user"): Promise<void> => {
  try {
    await setDoc(
      doc(db, "users", uid),
      {
        role,
        updatedAt: new Date(),
      },
      { merge: true },
    )
  } catch (error) {
    console.error("Error updating user role:", error)
    throw error
  }
}

export const getAllUsers = async (): Promise<UserProfile[]> => {
  try {
    const usersCollection = collection(db, "users")
    const snapshot = await getDocs(usersCollection)

    return snapshot.docs.map((doc) => ({
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      lastLogin: doc.data().lastLogin?.toDate() || new Date(),
    })) as UserProfile[]
  } catch (error) {
    console.error("Error getting all users:", error)
    throw error
  }
}

export const isSuperAdmin = (email: string): boolean => {
  return email === SUPER_ADMIN_EMAIL
}
