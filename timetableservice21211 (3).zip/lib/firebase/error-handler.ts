import type { FirebaseError } from "firebase/app"
import type { AuthError } from "firebase/auth"

export interface AppError {
  code: string
  message: string
  userMessage: string
  severity: "low" | "medium" | "high" | "critical"
}

export class ErrorHandler {
  private static logError(error: Error, context?: string) {
    const timestamp = new Date().toISOString()
    const logData = {
      timestamp,
      error: error.message,
      stack: error.stack,
      context,
      userAgent: typeof window !== "undefined" ? window.navigator.userAgent : "server",
      isFirebaseStudio:
        typeof window !== "undefined"
          ? window.location.hostname.includes("firebase") ||
            window.location.hostname.includes("web.app") ||
            window.location.hostname.includes("firebaseapp.com") ||
            window.location.hostname.includes("v0.app") ||
            window.location.hostname.includes("vercel.app")
          : false,
      currentDomain: typeof window !== "undefined" ? window.location.hostname : "server",
    }

    console.error("[v0] Error logged:", logData)

    // In production, send to monitoring service
    if (process.env.NODE_ENV === "production") {
      // TODO: Integrate with monitoring service (Sentry, LogRocket, etc.)
    }
  }

  static handleFirebaseError(error: FirebaseError | AuthError, context?: string): AppError {
    this.logError(error, context)

    const errorMap: Record<string, AppError> = {
      // Authentication errors
      "auth/user-not-found": {
        code: "auth/user-not-found",
        message: "User not found",
        userMessage: "등록되지 않은 이메일입니다.",
        severity: "low",
      },
      "auth/wrong-password": {
        code: "auth/wrong-password",
        message: "Wrong password",
        userMessage: "비밀번호가 올바르지 않습니다.",
        severity: "low",
      },
      "auth/invalid-email": {
        code: "auth/invalid-email",
        message: "Invalid email",
        userMessage: "올바른 이메일 형식이 아닙니다.",
        severity: "low",
      },
      "auth/user-disabled": {
        code: "auth/user-disabled",
        message: "User disabled",
        userMessage: "비활성화된 계정입니다. 관리자에게 문의하세요.",
        severity: "medium",
      },
      "auth/email-already-in-use": {
        code: "auth/email-already-in-use",
        message: "Email already in use",
        userMessage: "이미 사용 중인 이메일입니다.",
        severity: "low",
      },
      "auth/weak-password": {
        code: "auth/weak-password",
        message: "Weak password",
        userMessage: "비밀번호는 최소 6자 이상이어야 합니다.",
        severity: "low",
      },
      "auth/too-many-requests": {
        code: "auth/too-many-requests",
        message: "Too many requests",
        userMessage: "너무 많은 시도가 있었습니다. 잠시 후 다시 시도해주세요.",
        severity: "medium",
      },
      "auth/network-request-failed": {
        code: "auth/network-request-failed",
        message: "Network request failed",
        userMessage: "네트워크 연결을 확인해주세요.",
        severity: "medium",
      },
      "auth/unauthorized-domain": {
        code: "auth/unauthorized-domain",
        message: "Unauthorized domain",
        userMessage:
          typeof window !== "undefined" &&
          (window.location.hostname.includes("firebase") ||
            window.location.hostname.includes("web.app") ||
            window.location.hostname.includes("firebaseapp.com") ||
            window.location.hostname.includes("v0.app") ||
            window.location.hostname.includes("vercel.app"))
            ? `Firebase Studio 환경에서 도메인 인증 오류가 발생했습니다.\n\n` +
              `현재 도메인: ${window.location.hostname}\n\n` +
              `해결 방법:\n` +
              `1. Firebase 콘솔에서 현재 도메인을 승인된 도메인에 추가\n` +
              `2. 브라우저에서 서드파티 쿠키 활성화\n` +
              `3. 팝업 차단 해제\n` +
              `4. 안정적인 인터넷 연결 확인\n\n` +
              `Firebase 콘솔: https://console.firebase.google.com`
            : "현재 도메인이 인증되지 않았습니다. 관리자에게 문의하세요.",
        severity: "high",
      },
      "auth/invalid-argument": {
        code: "auth/invalid-argument",
        message: "Invalid argument provided",
        userMessage: "잘못된 인증 정보가 제공되었습니다. Firebase Studio 환경에서는 도메인 승인이 필요합니다.",
        severity: "high",
      },
      "firestore/invalid-argument": {
        code: "firestore/invalid-argument",
        message: "Invalid argument provided to Firestore",
        userMessage: "데이터베이스 요청에 잘못된 인수가 포함되었습니다.",
        severity: "medium",
      },
      "firestore/permission-denied": {
        code: "firestore/permission-denied",
        message: "Permission denied",
        userMessage: "접근 권한이 없습니다.",
        severity: "high",
      },
      "firestore/unavailable": {
        code: "firestore/unavailable",
        message: "Service unavailable",
        userMessage: "서비스가 일시적으로 사용할 수 없습니다.",
        severity: "high",
      },
    }

    return (
      errorMap[error.code] || {
        code: error.code || "unknown",
        message: error.message,
        userMessage: "알 수 없는 오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
        severity: "medium",
      }
    )
  }

  static handleGenericError(error: Error, context?: string): AppError {
    this.logError(error, context)

    return {
      code: "generic-error",
      message: error.message,
      userMessage: "오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
      severity: "medium",
    }
  }
}
