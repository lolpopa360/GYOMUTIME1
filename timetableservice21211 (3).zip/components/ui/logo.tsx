import Image from "next/image"

interface LogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function Logo({ className = "", size = "md", showText = true }: LogoProps) {
  const sizeClasses = {
    sm: "h-8 w-auto",
    md: "h-12 w-auto",
    lg: "h-16 w-auto",
  }

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl",
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <Image
        src="/logo-gyomutime.png"
        alt="교무타임 로고"
        width={200}
        height={80}
        className={`${sizeClasses[size]} object-contain`}
        priority
        onError={(e) => {
          // Fallback to text logo if image fails to load
          const target = e.target as HTMLImageElement
          target.style.display = "none"
        }}
      />
      {showText && (
        <div className="flex flex-col">
          <span className={`font-bold text-primary ${textSizeClasses[size]}`}>교무타임</span>
          <span className="text-xs text-muted-foreground -mt-1">Gyomutime</span>
        </div>
      )}
    </div>
  )
}
