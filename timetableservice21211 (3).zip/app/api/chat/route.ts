import { type NextRequest, NextResponse } from "next/server"

// Mock GPT responses for demonstration
const mockResponses = {
  // File format questions
  파일: "엑셀 파일은 .xlsx 형식으로 제출해주세요. 시간표 생성의 경우 교사 정보, 교실 정보, 과목 정보, 제약조건 시트가 필요합니다. 선택과목 분반의 경우 첫 번째 열에 학생ID, 이후 열에는 각 과목명을 헤더로 하고 1(희망)/0(비희망)으로 데이터를 입력해주세요.",

  형식: "엑셀 파일 형식에 대해 안내드리겠습니다:\n\n**시간표 생성:**\n- 교사 정보: 교사명, 담당과목, 가능시간\n- 교실 정보: 교실명, 수용인원, 사용가능시간\n- 과목 정보: 과목명, 시수, 학급별 배정\n- 제약조건: 특별 요구사항, 금지시간\n\n**선택과목 분반:**\n- 첫 열: 학생ID\n- 이후 열: 과목명 (1=희망, 0=비희망)",

  // Processing questions
  시간: "처리 시간은 데이터의 복잡도에 따라 다릅니다:\n- 시간표 생성: 1-24시간\n- 선택과목 분반: 1-12시간\n\n복잡한 제약조건이 많을수록 처리 시간이 길어질 수 있습니다. 완료되면 결과 파일을 제공해드립니다.",

  처리: "처리 과정은 다음과 같습니다:\n1. 업로드된 파일 검증\n2. OR-Tools 최적화 알고리즘 실행\n3. 제약조건 만족하는 최적해 탐색\n4. 결과 엑셀 파일 생성\n5. 다운로드 링크 제공",

  // Pricing questions
  요금: "현재 베타 서비스 기간으로 무료로 제공하고 있습니다. 정식 서비스 시작 시 합리적인 요금제를 안내드릴 예정입니다.",

  가격: "베타 서비스 기간 중이므로 무료로 이용하실 수 있습니다. 향후 요금제는 처리 건수와 복잡도에 따라 책정될 예정입니다.",

  // Technical questions
  알고리즘:
    "Google의 OR-Tools를 사용한 제약 만족 문제(CSP) 해결 방식을 적용합니다. 이는 복잡한 스케줄링 문제를 효율적으로 해결하는 검증된 방법입니다.",

  최적화:
    "다음 요소들을 고려하여 최적화합니다:\n- 교사/교실 배정 효율성\n- 시간 충돌 방지\n- 학생 희망사항 최대 반영\n- 균형잡힌 분반 구성\n- 제약조건 만족",

  // Contact and support
  문의: "추가 문의사항이 있으시면 admin@gyomutime.kr로 연락주시거나, 관리자에게 직접 문의해주세요. 빠른 시일 내에 답변드리겠습니다.",

  지원: "기술 지원이 필요하시면 언제든 연락주세요. 파일 형식 문제, 처리 오류, 결과 해석 등 모든 부분에서 도움을 드리겠습니다.",

  // Default responses
  default:
    "교무타임 시간표 생성 서비스에 대해 궁금한 점을 구체적으로 말씀해주세요. 파일 형식, 처리 시간, 요금, 기술적 문의 등 무엇이든 도와드리겠습니다.",

  greeting:
    "안녕하세요! 교무타임 도우미입니다. 시간표 생성이나 선택과목 분반 배정에 대해 궁금한 점이 있으시면 언제든 물어보세요.",
}

function findBestResponse(message: string): string {
  const lowerMessage = message.toLowerCase()

  // Check for specific keywords
  for (const [keyword, response] of Object.entries(mockResponses)) {
    if (keyword !== "default" && keyword !== "greeting" && lowerMessage.includes(keyword)) {
      return response
    }
  }

  // Check for greetings
  if (lowerMessage.includes("안녕") || lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
    return mockResponses.greeting
  }

  // Default response
  return mockResponses.default
}

export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()

    if (!message) {
      return NextResponse.json({ error: "메시지가 필요합니다." }, { status: 400 })
    }

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000 + Math.random() * 2000))

    const response = findBestResponse(message)

    return NextResponse.json({
      response,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Chat API error:", error)
    return NextResponse.json({ error: "서버 오류가 발생했습니다." }, { status: 500 })
  }
}
