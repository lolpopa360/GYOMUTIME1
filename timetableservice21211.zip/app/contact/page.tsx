"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Mail, Phone, MapPin, Send, MessageCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function ContactPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    category: "",
    subject: "",
    message: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate form submission
    setTimeout(() => {
      setIsLoading(false)
      setSuccess(true)
      setFormData({ name: "", email: "", category: "", subject: "", message: "" })
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link
              href="/"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>홈으로 돌아가기</span>
            </Link>
            <div className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-primary" />
              <span className="font-semibold text-primary">고객지원</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-3xl font-bold text-foreground">고객지원</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              시간표 최적화 서비스에 대한 문의사항이나 도움이 필요하시면 언제든지 연락해주세요. 최대한 빠르게
              답변드리겠습니다.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Information */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    이메일 문의
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">일반 문의</p>
                    <p className="font-medium">support@timetable.com</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">기술 지원</p>
                    <p className="font-medium">tech@timetable.com</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">개인정보 관련</p>
                    <p className="font-medium">privacy@timetable.com</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-primary" />
                    전화 문의
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="font-medium">02-1234-5678</p>
                    <p className="text-sm text-muted-foreground">
                      평일 09:00 - 18:00
                      <br />
                      (점심시간 12:00 - 13:00 제외)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    오시는 길
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="font-medium">교무타임 본사</p>
                    <p className="text-sm text-muted-foreground">
                      서울특별시 강남구 테헤란로 123
                      <br />
                      ABC빌딩 10층
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>문의하기</CardTitle>
                  <p className="text-muted-foreground">아래 양식을 작성해주시면 빠른 시일 내에 답변드리겠습니다.</p>
                </CardHeader>
                <CardContent>
                  {success ? (
                    <Alert className="border-green-500/50 text-green-700 bg-green-50">
                      <MessageCircle className="h-4 w-4" />
                      <AlertDescription>
                        문의가 성공적으로 접수되었습니다. 빠른 시일 내에 답변드리겠습니다.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">이름 *</Label>
                          <Input
                            id="name"
                            type="text"
                            placeholder="홍길동"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">이메일 *</Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="your@email.com"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="category">문의 유형 *</Label>
                        <Select
                          value={formData.category}
                          onValueChange={(value) => setFormData({ ...formData, category: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="문의 유형을 선택해주세요" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="general">일반 문의</SelectItem>
                            <SelectItem value="technical">기술 지원</SelectItem>
                            <SelectItem value="account">계정 관련</SelectItem>
                            <SelectItem value="billing">결제 관련</SelectItem>
                            <SelectItem value="feature">기능 요청</SelectItem>
                            <SelectItem value="bug">버그 신고</SelectItem>
                            <SelectItem value="privacy">개인정보 관련</SelectItem>
                            <SelectItem value="other">기타</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="subject">제목 *</Label>
                        <Input
                          id="subject"
                          type="text"
                          placeholder="문의 제목을 입력해주세요"
                          value={formData.subject}
                          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message">문의 내용 *</Label>
                        <Textarea
                          id="message"
                          placeholder="문의 내용을 자세히 작성해주세요"
                          className="min-h-[120px]"
                          value={formData.message}
                          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                          required
                        />
                      </div>

                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {isLoading ? (
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                            전송 중...
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Send className="h-4 w-4" />
                            문의 전송
                          </div>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle>자주 묻는 질문</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground">Q. 시간표 최적화는 어떻게 작동하나요?</h4>
                  <p className="text-sm text-muted-foreground">
                    AI 알고리즘을 사용하여 학생들의 선호도, 교실 배정, 교사 일정 등을 종합적으로 고려하여 최적의
                    시간표를 자동으로 생성합니다.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground">Q. 데이터는 안전하게 보관되나요?</h4>
                  <p className="text-sm text-muted-foreground">
                    모든 데이터는 암호화되어 안전하게 저장되며, 개인정보보호법에 따라 엄격하게 관리됩니다.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground">Q. 계정을 삭제하고 싶어요.</h4>
                  <p className="text-sm text-muted-foreground">
                    계정 설정에서 직접 삭제하거나, 고객지원팀에 문의해주시면 도움드리겠습니다.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground">Q. 서비스 이용료는 얼마인가요?</h4>
                  <p className="text-sm text-muted-foreground">
                    기본 서비스는 무료로 제공되며, 고급 기능은 유료 플랜을 통해 이용하실 수 있습니다.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
