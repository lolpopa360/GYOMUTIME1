import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")

    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ authenticated: false }, { status: 401 })
    }

    const token = authHeader.split("Bearer ")[1]

    // In production, you would verify the token with Firebase Admin SDK
    if (!token) {
      return NextResponse.json({ authenticated: false }, { status: 401 })
    }

    return NextResponse.json({
      authenticated: true,
      message: "Token present but not verified (implement Firebase Admin SDK for production)",
    })
  } catch (error) {
    return NextResponse.json({ authenticated: false }, { status: 401 })
  }
}
