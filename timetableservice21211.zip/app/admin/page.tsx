"use client"

import type React from "react"
import Link from "next/link"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Logo } from "@/components/ui/logo"
import { updateSubmissionStatus, type Submission } from "@/lib/firebase/firestore"
import {
  Play,
  Download,
  Clock,
  CheckCircle,
  AlertCircle,
  Users,
  FileSpreadsheet,
  LogOut,
  Database,
  BarChart3,
  Network,
  Zap,
  Edit,
  Save,
  X,
  FileText,
  Settings,
  MessageSquare,
  FolderOpen,
  Loader2,
} from "lucide-react"

interface ResultInputData {
  submissionId: string
  status: "processing" | "completed" | "failed"
  resultFiles: File[]
  notes: string
  completionPercentage: number
  estimatedCompletion?: string
}

export default function AdminDashboard() {
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [loading, setLoading] = useState(true)
  const [processingItems, setProcessingItems] = useState<Set<string>>(new Set())
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null)
  const [isResultDialogOpen, setIsResultDialogOpen] = useState(false)
  const [resultData, setResultData] = useState<ResultInputData>({
    submissionId: "",
    status: "processing",
    resultFiles: [],
    notes: "",
    completionPercentage: 0,
  })

  useEffect(() => {
    loadAllSubmissions()
  }, [])

  const loadAllSubmissions = async () => {
    try {
      setLoading(true)
      // In a real admin dashboard, we'd load all users' submissions
      // For now, we'll simulate loading all submissions
      const allSubmissions: Submission[] = []

      // This would typically be an admin-only function to get all submissions
      // For demo purposes, we'll show the structure
      console.log("[v0] Loading all submissions for admin dashboard")

      setSubmissions(allSubmissions)
    } catch (error) {
      console.error("[v0] Error loading submissions:", error)
      toast({
        title: "오류",
        description: "제출 목록을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
            접수완료
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-400 border-yellow-500/20">
            처리중
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20">
            완료
          </Badge>
        )
      case "failed":
        return (
          <Badge variant="secondary" className="bg-red-500/10 text-red-400 border-red-500/20">
            오류
          </Badge>
        )
      default:
        return <Badge variant="secondary">알 수 없음</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4 text-blue-400" />
      case "processing":
        return <Play className="h-4 w-4 text-yellow-400" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case "failed":
        return <AlertCircle className="h-4 w-4 text-red-400" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const handleExecute = async (submissionId: string) => {
    setProcessingItems((prev) => new Set(prev).add(submissionId))

    try {
      await updateSubmissionStatus(submissionId, "processing")

      toast({
        title: "알고리즘 실행 시작",
        description: "최적화 알고리즘이 실행되었습니다.",
      })

      // Simulate processing time
      setTimeout(async () => {
        try {
          await updateSubmissionStatus(submissionId, "completed", new Date())
          await loadAllSubmissions() // Refresh data

          toast({
            title: "처리 완료",
            description: "알고리즘 실행이 완료되었습니다.",
          })
        } catch (error) {
          console.error("[v0] Error completing submission:", error)
          await updateSubmissionStatus(submissionId, "failed")
        }

        setProcessingItems((prev) => {
          const newSet = new Set(prev)
          newSet.delete(submissionId)
          return newSet
        })
      }, 5000)
    } catch (error) {
      console.error("[v0] Error executing submission:", error)
      toast({
        title: "실행 오류",
        description: "알고리즘 실행 중 오류가 발생했습니다.",
        variant: "destructive",
      })

      setProcessingItems((prev) => {
        const newSet = new Set(prev)
        newSet.delete(submissionId)
        return newSet
      })
    }
  }

  const handleDownload = (fileName: string) => {
    console.log(`Downloading: ${fileName}`)
    toast({
      title: "다운로드 시작",
      description: `${fileName} 파일을 다운로드합니다.`,
    })
  }

  const handleInputResult = (submission: Submission) => {
    setSelectedSubmission(submission)
    setResultData({
      submissionId: submission.id || "",
      status:
        submission.status === "pending" ? "processing" : (submission.status as "processing" | "completed" | "failed"),
      resultFiles: [],
      notes: "",
      completionPercentage: submission.status === "completed" ? 100 : submission.status === "processing" ? 50 : 0,
    })
    setIsResultDialogOpen(true)
  }

  const handleSubmitResult = async () => {
    try {
      await updateSubmissionStatus(
        resultData.submissionId,
        resultData.status,
        resultData.status === "completed" ? new Date() : undefined,
      )

      toast({
        title: "결과 입력 완료",
        description: `제출 요청에 대한 결과가 업데이트되었습니다.`,
      })

      setIsResultDialogOpen(false)
      setSelectedSubmission(null)
      await loadAllSubmissions() // Refresh data
    } catch (error) {
      console.error("[v0] Error updating submission result:", error)
      toast({
        title: "오류",
        description: "결과 입력 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setResultData((prev) => ({
      ...prev,
      resultFiles: [...prev.resultFiles, ...files],
    }))
  }

  const timetableSubmissions = submissions.filter((s) => s.type === "timetable")
  const electiveSubmissions = submissions.filter((s) => s.type === "electives")

  const SubmissionTable = ({ submissions, type }: { submissions: Submission[]; type: "timetable" | "electives" }) => (
    <Table>
      <TableHeader>
        <TableRow className="border-border">
          <TableHead className="text-foreground">제목</TableHead>
          <TableHead className="text-foreground">유형</TableHead>
          <TableHead className="text-foreground">생성일</TableHead>
          <TableHead className="text-foreground">설명</TableHead>
          <TableHead className="text-foreground">상태</TableHead>
          <TableHead className="text-foreground">작업</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {submissions.map((submission) => (
          <TableRow key={submission.id} className="border-border">
            <TableCell className="font-medium text-foreground">{submission.title}</TableCell>
            <TableCell>
              <Badge variant="outline" className="text-xs">
                {submission.type === "timetable" ? "시간표" : "선택과목"}
              </Badge>
            </TableCell>
            <TableCell className="text-muted-foreground">{submission.createdAt.toLocaleDateString("ko-KR")}</TableCell>
            <TableCell className="text-muted-foreground max-w-xs truncate">
              {submission.description || "설명 없음"}
            </TableCell>
            <TableCell>
              <div className="flex items-center space-x-2">
                {getStatusIcon(submission.status)}
                {getStatusBadge(submission.status)}
              </div>
            </TableCell>
            <TableCell>
              <div className="flex items-center space-x-2">
                {submission.status === "pending" && (
                  <Button
                    size="sm"
                    onClick={() => handleExecute(submission.id!)}
                    disabled={processingItems.has(submission.id!)}
                    className="h-8"
                  >
                    {processingItems.has(submission.id!) ? (
                      <>
                        <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                        실행중
                      </>
                    ) : (
                      <>
                        <Play className="mr-1 h-3 w-3" />
                        실행
                      </>
                    )}
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => handleInputResult(submission)} className="h-8">
                  <Edit className="mr-1 h-3 w-3" />
                  결과입력
                </Button>
                {submission.status === "completed" && (
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => handleDownload(submission.title)}
                    className="h-8"
                  >
                    <Download className="mr-1 h-3 w-3" />
                    다운로드
                  </Button>
                )}
                {submission.status === "failed" && (
                  <Button size="sm" variant="destructive" onClick={() => handleExecute(submission.id!)} className="h-8">
                    <Play className="mr-1 h-3 w-3" />
                    재실행
                  </Button>
                )}
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
            <p className="text-muted-foreground">관리자 대시보드를 불러오는 중...</p>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Logo size="md" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground">교무타임 관리자</h1>
                  <p className="text-xs text-muted-foreground">Algorithm Control Center</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    {user?.displayName || user?.email}님, 안녕하세요
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  로그아웃
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-card-foreground">총 처리 요청</CardTitle>
                  <Database className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{submissions.length}</div>
                <p className="text-xs text-muted-foreground">전체 알고리즘 실행 요청</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-card-foreground">대기열</CardTitle>
                  <Clock className="h-4 w-4 text-secondary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-secondary">
                  {submissions.filter((s) => s.status === "pending").length}
                </div>
                <p className="text-xs text-muted-foreground">알고리즘 실행 대기</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-card-foreground">실행 중</CardTitle>
                  <Zap className="h-4 w-4 text-yellow-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-500">
                  {submissions.filter((s) => s.status === "processing").length}
                </div>
                <p className="text-xs text-muted-foreground">최적화 엔진 가동 중</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-card-foreground">완료</CardTitle>
                  <BarChart3 className="h-4 w-4 text-green-600" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {submissions.filter((s) => s.status === "completed").length}
                </div>
                <p className="text-xs text-muted-foreground">최적화 결과 생성 완료</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Network className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">알고리즘 실행 관리</CardTitle>
                    <CardDescription>시간표 최적화 및 분반 배정 관리</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  시간표 최적화 및 분반 배정 알고리즘의 실행 상태를 모니터링하고 관리합니다.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">총 {submissions.length}개 작업 대기중</div>
                  <Button size="sm" asChild>
                    <a href="#algorithm-management">관리하기</a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Users className="h-6 w-6 text-blue-500" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">사용자 관리</CardTitle>
                    <CardDescription>시스템 사용자 및 권한 관리</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  등록된 사용자의 권한을 관리하고 관리자를 추가하거나 제거할 수 있습니다.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">관리자 권한 필요</div>
                  <Button size="sm" asChild>
                    <Link href="/admin/users">
                      <Users className="h-4 w-4 mr-2" />
                      사용자 관리
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <MessageSquare className="h-6 w-6 text-green-500" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">문의 관리</CardTitle>
                    <CardDescription>사용자 문의 및 지원 관리</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  사용자들의 문의사항을 확인하고 답변을 제공할 수 있습니다.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">답변 대기 문의 관리</div>
                  <Button size="sm" asChild>
                    <Link href="/admin/inquiries">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      문의 관리
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-1 gap-6 mb-8">
            <Card className="border-border bg-card hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <FolderOpen className="h-6 w-6 text-purple-500" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">파일 관리</CardTitle>
                    <CardDescription>시스템 파일 및 문서 관리</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  템플릿, 문서, 결과 파일 등을 업로드하고 관리할 수 있습니다.
                </p>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">파일 업로드 및 다운로드 관리</div>
                  <Button size="sm" asChild>
                    <Link href="/admin/files">
                      <FolderOpen className="h-4 w-4 mr-2" />
                      파일 관리
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border bg-card" id="algorithm-management">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Network className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-card-foreground">알고리즘 실행 관리</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    시간표 최적화 및 분반 배정 알고리즘의 실행 상태를 모니터링하고 관리합니다.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="timetable" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="timetable" className="flex items-center space-x-2">
                    <Network className="h-4 w-4" />
                    <span>시간표 최적화</span>
                    <Badge variant="secondary" className="ml-2 bg-primary/10 text-primary">
                      {timetableSubmissions.length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="electives" className="flex items-center space-x-2">
                    <Users className="h-4 w-4" />
                    <span>분반 알고리즘</span>
                    <Badge variant="secondary" className="ml-2 bg-secondary/10 text-secondary">
                      {electiveSubmissions.length}
                    </Badge>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="timetable" className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Network className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">시간표 최적화 엔진</h3>
                        <p className="text-sm text-muted-foreground">OR-Tools 기반 스케줄링 알고리즘</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <FileSpreadsheet className="h-4 w-4" />
                      <span>{timetableSubmissions.length}개 작업</span>
                    </div>
                  </div>
                  <div className="border border-border rounded-lg overflow-hidden">
                    <SubmissionTable submissions={timetableSubmissions} type="timetable" />
                  </div>
                </TabsContent>

                <TabsContent value="electives" className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-secondary/10 rounded-lg">
                        <Users className="h-5 w-5 text-secondary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">분반 배정 알고리즘</h3>
                        <p className="text-sm text-muted-foreground">머신러닝 기반 최적화 시스템</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span>{electiveSubmissions.length}개 작업</span>
                    </div>
                  </div>
                  <div className="border border-border rounded-lg overflow-hidden">
                    <SubmissionTable submissions={electiveSubmissions} type="electives" />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <Dialog open={isResultDialogOpen} onOpenChange={setIsResultDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>결과 입력 및 상태 관리</span>
              </DialogTitle>
              <DialogDescription>{selectedSubmission?.title} 요청에 대한 결과를 입력하세요</DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="bg-muted/20 p-4 rounded-lg">
                <h4 className="font-medium mb-2">요청 정보</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">제목:</span>
                    <span className="ml-2 font-medium">{selectedSubmission?.title}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">유형:</span>
                    <span className="ml-2 font-medium">
                      {selectedSubmission?.type === "timetable" ? "시간표" : "선택과목"}
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">설명:</span>
                    <span className="ml-2">{selectedSubmission?.description || "없음"}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">생성일:</span>
                    <span className="ml-2">{selectedSubmission?.createdAt.toLocaleDateString("ko-KR")}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="status">처리 상태</Label>
                  <Select
                    value={resultData.status}
                    onValueChange={(value: "processing" | "completed" | "failed") =>
                      setResultData((prev) => ({ ...prev, status: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="processing">처리중</SelectItem>
                      <SelectItem value="completed">완료</SelectItem>
                      <SelectItem value="failed">오류</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="completion">완료율 (%)</Label>
                  <Input
                    id="completion"
                    type="number"
                    min="0"
                    max="100"
                    value={resultData.completionPercentage}
                    onChange={(e) =>
                      setResultData((prev) => ({ ...prev, completionPercentage: Number(e.target.value) }))
                    }
                  />
                </div>

                {resultData.status === "processing" && (
                  <div>
                    <Label htmlFor="estimated">예상 완료 시간</Label>
                    <Input
                      id="estimated"
                      type="datetime-local"
                      value={resultData.estimatedCompletion || ""}
                      onChange={(e) => setResultData((prev) => ({ ...prev, estimatedCompletion: e.target.value }))}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="files">결과 파일 업로드</Label>
                  <Input
                    id="files"
                    type="file"
                    multiple
                    accept=".xlsx,.xls,.pdf,.csv"
                    onChange={handleFileUpload}
                    className="cursor-pointer"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Excel, PDF, CSV 파일을 업로드할 수 있습니다</p>
                </div>

                {resultData.resultFiles.length > 0 && (
                  <div className="space-y-2">
                    <Label>업로드된 파일</Label>
                    {resultData.resultFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-muted/20 rounded">
                        <div className="flex items-center space-x-2">
                          <FileText className="h-4 w-4" />
                          <span className="text-sm">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            ({(file.size / 1024 / 1024).toFixed(2)} MB)
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            setResultData((prev) => ({
                              ...prev,
                              resultFiles: prev.resultFiles.filter((_, i) => i !== index),
                            }))
                          }
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="notes">관리자 메모</Label>
                <Textarea
                  id="notes"
                  placeholder="처리 과정에서의 특이사항이나 고객에게 전달할 메시지를 입력하세요..."
                  value={resultData.notes}
                  onChange={(e) => setResultData((prev) => ({ ...prev, notes: e.target.value }))}
                  rows={4}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsResultDialogOpen(false)}>
                  취소
                </Button>
                <Button onClick={handleSubmitResult} className="bg-primary hover:bg-primary/90">
                  <Save className="h-4 w-4 mr-2" />
                  결과 저장
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </ProtectedRoute>
  )
}
