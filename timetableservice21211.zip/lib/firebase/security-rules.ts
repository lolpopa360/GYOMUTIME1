export class SecurityValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  static validatePassword(password: string): { isValid: boolean; message?: string } {
    if (password.length < 8) {
      return { isValid: false, message: "비밀번호는 최소 8자 이상이어야 합니다." }
    }

    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
      return {
        isValid: false,
        message: "비밀번호는 대문자, 소문자, 숫자를 포함해야 합니다.",
      }
    }

    return { isValid: true }
  }

  static validateName(name: string): boolean {
    return name.trim().length >= 2 && name.trim().length <= 50
  }

  static sanitizeInput(input: string): string {
    return input.trim().replace(/[<>]/g, "")
  }

  static isAdminEmail(email: string): boolean {
    const adminEmails = [
      "yangchanhee11@gmail.com",
      // Add more admin emails as needed
    ]
    return adminEmails.includes(email.toLowerCase())
  }

  static validateAdminAccess(userRole: string, requiredRole = "admin"): boolean {
    const roleHierarchy = ["user", "admin", "super-admin"]
    const userRoleIndex = roleHierarchy.indexOf(userRole)
    const requiredRoleIndex = roleHierarchy.indexOf(requiredRole)

    return userRoleIndex >= requiredRoleIndex
  }
}
