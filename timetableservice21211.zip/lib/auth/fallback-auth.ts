interface MockUser {
  uid: string
  email: string
  displayName: string
  role: "user" | "admin"
  createdAt: Date
}

class FallbackAuthService {
  private currentUser: MockUser | null = null
  private listeners: ((user: MockUser | null) => void)[] = []

  constructor() {
    // Load user from localStorage if available
    if (typeof window !== "undefined") {
      const savedUser = localStorage.getItem("fallback_auth_user")
      if (savedUser) {
        try {
          this.currentUser = JSON.parse(savedUser)
          console.log("[v0] Loaded user from localStorage:", this.currentUser?.email)
        } catch (error) {
          console.warn("[v0] Failed to load saved user:", error)
        }
      }
    }
  }

  async signInWithEmailAndPassword(email: string, password: string): Promise<{ user: MockUser }> {
    // Mock authentication - in production, this would validate against a real backend
    const user: MockUser = {
      uid: `mock_${Date.now()}`,
      email,
      displayName: email.split("@")[0],
      role: email.includes("admin") ? "admin" : "user",
      createdAt: new Date(),
    }

    this.currentUser = user
    this.saveUser(user)
    this.notifyListeners()

    console.log("[v0] Mock sign in successful:", email)
    return { user }
  }

  async createUserWithEmailAndPassword(email: string, password: string): Promise<{ user: MockUser }> {
    const user: MockUser = {
      uid: `mock_${Date.now()}`,
      email,
      displayName: email.split("@")[0],
      role: "user",
      createdAt: new Date(),
    }

    this.currentUser = user
    this.saveUser(user)
    this.notifyListeners()

    console.log("[v0] Mock account created:", email)
    return { user }
  }

  async signOut(): Promise<void> {
    this.currentUser = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("fallback_auth_user")
    }
    this.notifyListeners()
    console.log("[v0] Mock sign out successful")
  }

  getCurrentUser(): MockUser | null {
    return this.currentUser
  }

  onAuthStateChanged(callback: (user: MockUser | null) => void): () => void {
    this.listeners.push(callback)
    // Call immediately with current state
    callback(this.currentUser)

    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(callback)
      if (index > -1) {
        this.listeners.splice(index, 1)
      }
    }
  }

  private saveUser(user: MockUser): void {
    if (typeof window !== "undefined") {
      localStorage.setItem("fallback_auth_user", JSON.stringify(user))
    }
  }

  private notifyListeners(): void {
    this.listeners.forEach((callback) => callback(this.currentUser))
  }
}

export const fallbackAuth = new FallbackAuthService()
