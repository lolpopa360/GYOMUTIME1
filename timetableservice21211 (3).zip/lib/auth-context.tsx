"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  updateProfile,
  type User,
} from "firebase/auth"
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore"
import { getFirebaseAuth, getFirebaseDb } from "@/lib/firebase/config"

export interface UserProfile {
  id: string
  email: string
  name: string
  role: "admin" | "user" | "super-admin"
  createdAt: Date
  lastLoginAt?: Date
  isEmailVerified: boolean
  preferences?: {
    theme: "light" | "dark" | "system"
    language: "ko" | "en"
    notifications: boolean
  }
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  logout: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>
  clearError: () => void
  isAuthenticated: boolean
  isAdmin: boolean
  isSuperAdmin: boolean
  verifyAdminAccess: (password: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({
  prompt: "select_account",
  hd: undefined, // Allow any domain
})

const ADMIN_SECONDARY_PASSWORD = "20081113"
const SUPER_ADMIN_EMAIL = "yangchanhee11@gmail.com"

function getCurrentDomain(): string {
  if (typeof window === "undefined") return "localhost"
  return window.location.hostname
}

function isFirebaseStudioDomain(): boolean {
  const domain = getCurrentDomain()
  return (
    domain.includes("firebase") ||
    domain.includes("web.app") ||
    domain.includes("firebaseapp.com") ||
    domain.includes("v0.app") ||
    domain.includes("vercel.app")
  )
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      console.error("Firebase Auth or Firestore not available")
      setError("Firebase 서비스를 초기화할 수 없습니다.")
      setIsLoading(false)
      return
    }

    try {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        setUser(user)

        if (user && db) {
          try {
            const userDoc = await getDoc(doc(db, "users", user.uid))
            if (userDoc.exists()) {
              const data = userDoc.data()
              const profile: UserProfile = {
                id: user.uid,
                email: user.email || "",
                name: data.name || user.displayName || "",
                role: data.role || (user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"),
                createdAt: data.createdAt?.toDate() || new Date(),
                lastLoginAt: data.lastLoginAt?.toDate(),
                isEmailVerified: user.emailVerified,
                preferences: data.preferences || {
                  theme: "system",
                  language: "ko",
                  notifications: true,
                },
              }
              setUserProfile(profile)

              await updateDoc(doc(db, "users", user.uid), {
                lastLoginAt: new Date(),
              })
            } else {
              const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"
              const newProfile: UserProfile = {
                id: user.uid,
                email: user.email || "",
                name: user.displayName || user.email?.split("@")[0] || "",
                role,
                createdAt: new Date(),
                lastLoginAt: new Date(),
                isEmailVerified: user.emailVerified,
                preferences: {
                  theme: "system",
                  language: "ko",
                  notifications: true,
                },
              }

              await setDoc(doc(db, "users", user.uid), {
                name: newProfile.name,
                email: newProfile.email,
                role: newProfile.role,
                createdAt: newProfile.createdAt,
                lastLoginAt: newProfile.lastLoginAt,
                preferences: newProfile.preferences,
              })

              setUserProfile(newProfile)
            }
          } catch (error: any) {
            console.error("Error fetching user profile:", error)
            setError("사용자 프로필을 불러오는데 실패했습니다.")
          }
        } else {
          setUserProfile(null)
        }

        setIsLoading(false)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error("Error setting up auth listener:", error)
      setError("인증 시스템 초기화에 실패했습니다.")
      setIsLoading(false)
    }
  }, [])

  const clearError = () => setError(null)

  const verifyAdminAccess = (password: string): boolean => {
    return password === ADMIN_SECONDARY_PASSWORD
  }

  const login = async (email: string, password: string) => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      await signInWithEmailAndPassword(auth, email, password)
    } catch (error: any) {
      console.error("Login error:", error)

      if (error.code === "auth/invalid-credential") {
        setError("이메일 또는 비밀번호가 올바르지 않습니다. 다시 확인해주세요.")
      } else if (error.code === "auth/user-not-found") {
        setError("등록되지 않은 이메일입니다. 회원가입을 먼저 진행해주세요.")
      } else if (error.code === "auth/wrong-password") {
        setError("비밀번호가 올바르지 않습니다.")
      } else if (error.code === "auth/too-many-requests") {
        setError("로그인 시도가 너무 많습니다. 잠시 후 다시 시도해주세요.")
      } else if (error.code === "auth/network-request-failed") {
        setError("네트워크 연결을 확인해주세요.")
      } else {
        setError(`로그인에 실패했습니다: ${error.message}`)
      }
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithGoogle = async () => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      const result = await signInWithPopup(auth, googleProvider)
      const user = result.user

      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (!userDoc.exists()) {
        const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"
        await setDoc(doc(db, "users", user.uid), {
          name: user.displayName || user.email!.split("@")[0],
          email: user.email,
          role,
          createdAt: new Date(),
          lastLoginAt: new Date(),
          preferences: {
            theme: "system",
            language: "ko",
            notifications: true,
          },
        })
      }
    } catch (error: any) {
      console.error("Google login error:", error)

      if (error.code === "auth/unauthorized-domain") {
        const currentDomain = getCurrentDomain()
        const isStudio = isFirebaseStudioDomain()

        setError(
          `도메인 인증 오류가 발생했습니다.\n\n` +
            `현재 도메인: ${currentDomain}\n` +
            `Firebase Studio 환경: ${isStudio ? "예" : "아니오"}\n\n` +
            `해결 방법:\n` +
            `1. Firebase 콘솔 (console.firebase.google.com)에 접속\n` +
            `2. 프로젝트 선택 → Authentication → Settings → Authorized domains\n` +
            `3. 다음 도메인들을 추가:\n` +
            `   - ${currentDomain}\n` +
            `   - localhost (개발용)\n` +
            `   - *.vercel.app (배포용)\n` +
            `   - *.v0.app (v0 프리뷰용)\n` +
            `4. 변경사항 저장 후 다시 시도\n\n` +
            `Firebase Studio 사용 시 브라우저에서 서드파티 쿠키를 허용해야 합니다.`,
        )
      } else if (error.code === "auth/popup-blocked") {
        setError("팝업이 차단되었습니다. 브라우저 설정에서 팝업을 허용하고 서드파티 쿠키를 활성화해주세요.")
      } else if (error.code === "auth/popup-closed-by-user") {
        setError("Google 로그인이 취소되었습니다.")
      } else if (error.code === "auth/network-request-failed") {
        setError("네트워크 연결을 확인해주세요. Firebase Studio 사용 시 안정적인 인터넷 연결이 필요합니다.")
      } else {
        setError(
          `Google 로그인에 실패했습니다: ${error.message}\n\nFirebase Studio 환경에서는 서드파티 쿠키가 활성화되어야 합니다.`,
        )
      }
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const signUp = async (email: string, password: string, name: string) => {
    const auth = getFirebaseAuth()
    const db = getFirebaseDb()

    if (!auth || !db) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setIsLoading(true)
    setError(null)

    try {
      const { user } = await createUserWithEmailAndPassword(auth, email, password)
      const role = user.email === SUPER_ADMIN_EMAIL ? "super-admin" : "user"

      await updateProfile(user, { displayName: name })

      await setDoc(doc(db, "users", user.uid), {
        name,
        email,
        role,
        createdAt: new Date(),
        lastLoginAt: new Date(),
        preferences: {
          theme: "system",
          language: "ko",
          notifications: true,
        },
      })
    } catch (error: any) {
      console.error("Signup error:", error)
      setError("회원가입에 실패했습니다. 다시 시도해주세요.")
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const resetPassword = async (email: string) => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    setError(null)

    try {
      await sendPasswordResetEmail(auth, email)
    } catch (error: any) {
      console.error("Password reset error:", error)
      setError("비밀번호 재설정 이메일 전송에 실패했습니다.")
      throw error
    }
  }

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user || !userProfile) return

    const db = getFirebaseDb()
    if (!db) return

    try {
      await updateDoc(doc(db, "users", user.uid), updates)
      setUserProfile({ ...userProfile, ...updates })
    } catch (error: any) {
      console.error("Profile update error:", error)
      setError("프로필 업데이트에 실패했습니다.")
      throw error
    }
  }

  const logout = async () => {
    const auth = getFirebaseAuth()
    if (!auth) {
      throw new Error("Firebase 인증 서비스를 사용할 수 없습니다.")
    }

    try {
      await signOut(auth)
    } catch (error: any) {
      console.error("Logout error:", error)
      setError("로그아웃에 실패했습니다.")
      throw error
    }
  }

  const value = {
    user,
    userProfile,
    isLoading,
    error,
    login,
    signUp,
    loginWithGoogle,
    logout,
    resetPassword,
    updateUserProfile,
    clearError,
    isAuthenticated: !!user,
    isAdmin: userProfile?.role === "admin" || userProfile?.role === "super-admin" || false,
    isSuperAdmin: userProfile?.role === "super-admin" || false,
    verifyAdminAccess,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
