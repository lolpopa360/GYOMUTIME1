interface PerformanceMetric {
  name: string
  value: number
  timestamp: number
  tags?: Record<string, string>
}

interface PerformanceReport {
  period: string
  metrics: PerformanceMetric[]
  summary: {
    avgResponseTime: number
    totalRequests: number
    errorRate: number
    cacheHitRate: number
  }
}

export class PerformanceMonitor {
  private metrics: PerformanceMetric[] = []
  private maxMetrics = 10000
  private timers = new Map<string, number>()

  startTimer(name: string): void {
    this.timers.set(name, performance.now())
  }

  endTimer(name: string, tags?: Record<string, string>): number {
    const startTime = this.timers.get(name)
    if (!startTime) {
      console.warn(`[v0] Timer ${name} was not started`)
      return 0
    }

    const duration = performance.now() - startTime
    this.timers.delete(name)

    this.recordMetric({
      name,
      value: duration,
      timestamp: Date.now(),
      tags,
    })

    console.log(`[v0] ${name} completed in ${duration.toFixed(2)}ms`)
    return duration
  }

  recordMetric(metric: PerformanceMetric): void {
    this.metrics.push(metric)

    // Keep only recent metrics
    if (this.metrics.length > this.maxMetrics) {
      this.metrics = this.metrics.slice(-this.maxMetrics)
    }
  }

  async monitorQuery<T>(queryName: string, queryFn: () => Promise<T>, tags?: Record<string, string>): Promise<T> {
    const startTime = performance.now()

    try {
      const result = await queryFn()
      const duration = performance.now() - startTime

      this.recordMetric({
        name: `db_query_${queryName}`,
        value: duration,
        timestamp: Date.now(),
        tags: { ...tags, status: "success" },
      })

      if (duration > 1000) {
        console.warn(`[v0] Slow query detected: ${queryName} took ${duration.toFixed(2)}ms`)
      }

      return result
    } catch (error) {
      const duration = performance.now() - startTime

      this.recordMetric({
        name: `db_query_${queryName}`,
        value: duration,
        timestamp: Date.now(),
        tags: { ...tags, status: "error" },
      })

      console.error(`[v0] Query failed: ${queryName}`, error)
      throw error
    }
  }

  async monitorAPI<T>(endpoint: string, apiFn: () => Promise<T>, tags?: Record<string, string>): Promise<T> {
    const startTime = performance.now()

    try {
      const result = await apiFn()
      const duration = performance.now() - startTime

      this.recordMetric({
        name: "api_response_time",
        value: duration,
        timestamp: Date.now(),
        tags: { ...tags, endpoint, status: "success" },
      })

      return result
    } catch (error) {
      const duration = performance.now() - startTime

      this.recordMetric({
        name: "api_response_time",
        value: duration,
        timestamp: Date.now(),
        tags: { ...tags, endpoint, status: "error" },
      })

      throw error
    }
  }

  recordMemoryUsage(): void {
    if (typeof window !== "undefined" && "memory" in performance) {
      const memory = (performance as any).memory

      this.recordMetric({
        name: "memory_used",
        value: memory.usedJSHeapSize,
        timestamp: Date.now(),
      })

      this.recordMetric({
        name: "memory_total",
        value: memory.totalJSHeapSize,
        timestamp: Date.now(),
      })

      this.recordMetric({
        name: "memory_limit",
        value: memory.jsHeapSizeLimit,
        timestamp: Date.now(),
      })
    }
  }

  generateReport(periodHours = 24): PerformanceReport {
    const now = Date.now()
    const periodStart = now - periodHours * 60 * 60 * 1000

    const periodMetrics = this.metrics.filter((m) => m.timestamp >= periodStart)

    const apiMetrics = periodMetrics.filter((m) => m.name === "api_response_time")
    const dbMetrics = periodMetrics.filter((m) => m.name.startsWith("db_query_"))

    const avgResponseTime =
      apiMetrics.length > 0 ? apiMetrics.reduce((sum, m) => sum + m.value, 0) / apiMetrics.length : 0

    const totalRequests = apiMetrics.length
    const errorRequests = apiMetrics.filter((m) => m.tags?.status === "error").length
    const errorRate = totalRequests > 0 ? (errorRequests / totalRequests) * 100 : 0

    // Mock cache hit rate - would integrate with actual cache
    const cacheHitRate = 85 // Placeholder

    return {
      period: `${periodHours} hours`,
      metrics: periodMetrics,
      summary: {
        avgResponseTime,
        totalRequests,
        errorRate,
        cacheHitRate,
      },
    }
  }

  checkPerformanceAlerts(): string[] {
    const alerts: string[] = []
    const recentMetrics = this.metrics.filter(
      (m) => Date.now() - m.timestamp < 300000, // Last 5 minutes
    )

    // Check for slow API responses
    const slowAPIs = recentMetrics.filter((m) => m.name === "api_response_time" && m.value > 2000)
    if (slowAPIs.length > 0) {
      alerts.push(`${slowAPIs.length} slow API responses detected (>2s)`)
    }

    // Check for slow database queries
    const slowQueries = recentMetrics.filter((m) => m.name.startsWith("db_query_") && m.value > 1000)
    if (slowQueries.length > 0) {
      alerts.push(`${slowQueries.length} slow database queries detected (>1s)`)
    }

    // Check error rate
    const apiCalls = recentMetrics.filter((m) => m.name === "api_response_time")
    const errors = apiCalls.filter((m) => m.tags?.status === "error")
    const errorRate = apiCalls.length > 0 ? (errors.length / apiCalls.length) * 100 : 0

    if (errorRate > 10) {
      alerts.push(`High error rate detected: ${errorRate.toFixed(1)}%`)
    }

    return alerts
  }

  getMetrics(name?: string, limit = 100): PerformanceMetric[] {
    const filtered = name ? this.metrics.filter((m) => m.name === name) : this.metrics

    return filtered.slice(-limit)
  }

  clearMetrics(): void {
    this.metrics = []
    this.timers.clear()
    console.log("[v0] Performance metrics cleared")
  }
}

// Global performance monitor instance
export const performanceMonitor = new PerformanceMonitor()

// Auto-record memory usage every 30 seconds
if (typeof window !== "undefined") {
  setInterval(() => {
    performanceMonitor.recordMemoryUsage()
  }, 30000)
}
