"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { LoginModal } from "./login-modal"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth()
  const [showLoginModal, setShowLoginModal] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setShowLoginModal(true)
    }
  }, [isLoading, isAuthenticated])

  const handleLoginModalClose = (open: boolean) => {
    setShowLoginModal(open)
    if (!open && !isAuthenticated) {
      router.push("/")
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">인증 확인 중...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <>
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-2">접근 권한이 필요합니다</h1>
            <p className="text-muted-foreground">관리자 페이지에 접근하려면 로그인해주세요.</p>
          </div>
        </div>
        <LoginModal open={showLoginModal} onOpenChange={handleLoginModalClose} />
      </>
    )
  }

  return <>{children}</>
}

export { ProtectedRoute }
