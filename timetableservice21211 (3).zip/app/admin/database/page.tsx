"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AdminHeader } from "@/components/admin/admin-header"
import { Database, RefreshCw, Download, Upload, AlertTriangle, CheckCircle, Clock, HardDrive } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Mock database status data
const databaseStats = {
  totalSize: "2.4 GB",
  totalTables: 12,
  totalRecords: 15420,
  lastBackup: "2024-01-15 14:30:00",
  status: "healthy",
}

const tableStats = [
  { name: "users", records: 1234, size: "45.2 MB", status: "healthy" },
  { name: "timetables", records: 856, size: "128.5 MB", status: "healthy" },
  { name: "classes", records: 2341, size: "67.8 MB", status: "healthy" },
  { name: "teachers", records: 234, size: "12.3 MB", status: "healthy" },
  { name: "subjects", records: 145, size: "8.9 MB", status: "healthy" },
  { name: "schedules", records: 4567, size: "234.7 MB", status: "warning" },
  { name: "assignments", records: 3421, size: "156.2 MB", status: "healthy" },
  { name: "inquiries", records: 567, size: "23.4 MB", status: "healthy" },
  { name: "files", records: 234, size: "1.2 GB", status: "healthy" },
  { name: "admin_logs", records: 2341, size: "89.3 MB", status: "healthy" },
]

export default function DatabasePage() {
  const [isBackingUp, setIsBackingUp] = useState(false)
  const [isOptimizing, setIsOptimizing] = useState(false)

  const handleBackup = async () => {
    setIsBackingUp(true)
    // Simulate backup process
    setTimeout(() => {
      setIsBackingUp(false)
    }, 3000)
  }

  const handleOptimize = async () => {
    setIsOptimizing(true)
    // Simulate optimization process
    setTimeout(() => {
      setIsOptimizing(false)
    }, 5000)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "healthy":
        return <Badge className="bg-green-500/10 text-green-600">정상</Badge>
      case "warning":
        return <Badge className="bg-yellow-500/10 text-yellow-600">주의</Badge>
      case "error":
        return <Badge variant="destructive">오류</Badge>
      default:
        return <Badge variant="outline">알 수 없음</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "healthy":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      <AdminHeader title="데이터베이스 관리" description="시스템 데이터베이스의 상태를 모니터링하고 관리합니다" />

      {/* Database Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">총 용량</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{databaseStats.totalSize}</div>
            <p className="text-xs text-muted-foreground">전체 데이터베이스 크기</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">테이블 수</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{databaseStats.totalTables}</div>
            <p className="text-xs text-muted-foreground">활성 테이블</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">총 레코드</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{databaseStats.totalRecords.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">전체 데이터 레코드</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">상태</CardTitle>
            {getStatusIcon(databaseStats.status)}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">정상</div>
            <p className="text-xs text-muted-foreground">시스템 상태</p>
          </CardContent>
        </Card>
      </div>

      {/* Database Actions */}
      <Card>
        <CardHeader>
          <CardTitle>데이터베이스 관리</CardTitle>
          <CardDescription>백업, 최적화 및 유지보수 작업을 수행합니다</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button onClick={handleBackup} disabled={isBackingUp}>
              {isBackingUp ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-2 h-4 w-4" />
              )}
              {isBackingUp ? "백업 중..." : "데이터베이스 백업"}
            </Button>

            <Button variant="outline" onClick={handleOptimize} disabled={isOptimizing}>
              {isOptimizing ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Database className="mr-2 h-4 w-4" />
              )}
              {isOptimizing ? "최적화 중..." : "성능 최적화"}
            </Button>

            <Button variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              백업 복원
            </Button>

            <Button variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" />
              인덱스 재구성
            </Button>
          </div>

          <Alert className="mt-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>마지막 백업: {databaseStats.lastBackup} | 다음 자동 백업: 오늘 23:00</AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Table Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>테이블 상태</CardTitle>
          <CardDescription>각 테이블의 레코드 수, 크기 및 상태를 확인합니다</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {tableStats.map((table) => (
              <div key={table.name} className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center space-x-4">
                  <Database className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">{table.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {table.records.toLocaleString()} 레코드 • {table.size}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getStatusBadge(table.status)}
                  <Button variant="ghost" size="sm">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <CardTitle>최근 활동</CardTitle>
          <CardDescription>데이터베이스 관련 최근 작업 내역</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>자동 백업 완료</span>
              <span className="text-muted-foreground">2시간 전</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <Database className="h-4 w-4 text-blue-600" />
              <span>인덱스 최적화 실행</span>
              <span className="text-muted-foreground">6시간 전</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <span>schedules 테이블 용량 경고</span>
              <span className="text-muted-foreground">1일 전</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>데이터 정리 작업 완료</span>
              <span className="text-muted-foreground">2일 전</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
