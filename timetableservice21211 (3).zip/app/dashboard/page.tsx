"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Bell,
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  Plus,
  TrendingUp,
  Users,
  Calendar,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"
import { getUserSubmissions, getUserNotes } from "@/lib/supabase/database"
import type { Submission, Note } from "@/lib/supabase/database"

export default function DashboardPage() {
  const { user, userProfile, isLoading } = useAuth()
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [notes, setNotes] = useState<Note[]>([])
  const [loadingData, setLoadingData] = useState(true)

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!user) return

      try {
        const [userSubmissions, userNotes] = await Promise.all([getUserSubmissions(user.id), getUserNotes(user.id)])

        setSubmissions(userSubmissions)
        setNotes(userNotes)
      } catch (error) {
        console.error("Error loading dashboard data:", error)
      } finally {
        setLoadingData(false)
      }
    }

    loadDashboardData()
  }, [user])

  if (isLoading || loadingData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">대시보드를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>로그인이 필요합니다</CardTitle>
            <CardDescription>대시보드에 접근하려면 먼저 로그인해주세요.</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/auth/login">
              <Button className="w-full btn-enhanced btn-primary-enhanced">로그인하기</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const pendingSubmissions = submissions.filter((s) => s.status === "pending").length
  const completedSubmissions = submissions.filter((s) => s.status === "completed").length
  const processingSubmissions = submissions.filter((s) => s.status === "processing").length
  const totalSubmissions = submissions.length
  const completionRate = totalSubmissions > 0 ? (completedSubmissions / totalSubmissions) * 100 : 0

  const highPriorityNotes = notes.filter((n) => n.priority === "high").length
  const recentNotes = notes.slice(0, 3)
  const recentSubmissions = submissions.slice(0, 3)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-foreground">대시보드</h1>
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                {userProfile?.role === "admin" ? "관리자" : "사용자"}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="btn-enhanced bg-transparent">
                <Bell className="h-4 w-4 mr-2" />
                알림
                {pendingSubmissions + highPriorityNotes > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 text-xs">
                    {pendingSubmissions + highPriorityNotes}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            안녕하세요, {userProfile?.name || user?.user_metadata?.name || "사용자"}님!
          </h2>
          <p className="text-muted-foreground">교무타임 시스템에서 시간표 최적화와 업무를 효율적으로 관리하세요.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">총 제출물</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{totalSubmissions}</div>
              <p className="text-xs text-muted-foreground">
                {processingSubmissions > 0 && `${processingSubmissions}개 처리 중`}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">완료율</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{completionRate.toFixed(0)}%</div>
              <Progress value={completionRate} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">대기 중</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-secondary">{pendingSubmissions}</div>
              <p className="text-xs text-muted-foreground">처리 대기 중인 작업</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">중요 메모</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">{highPriorityNotes}</div>
              <p className="text-xs text-muted-foreground">높은 우선순위</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              빠른 작업
            </CardTitle>
            <CardDescription>자주 사용하는 기능에 빠르게 접근하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Link href="/dashboard/notes">
                <Button
                  variant="outline"
                  className="w-full h-20 flex flex-col items-center justify-center space-y-2 hover:bg-primary/5 bg-transparent btn-enhanced card-enhanced"
                >
                  <FileText className="h-6 w-6" />
                  <span>메모 관리</span>
                </Button>
              </Link>

              <Link href="/dashboard/submissions">
                <Button
                  variant="outline"
                  className="w-full h-20 flex flex-col items-center justify-center space-y-2 hover:bg-primary/5 bg-transparent btn-enhanced card-enhanced"
                >
                  <Calendar className="h-6 w-6" />
                  <span>제출물 현황</span>
                </Button>
              </Link>

              <Link href="/customer/timetable">
                <Button
                  variant="outline"
                  className="w-full h-20 flex flex-col items-center justify-center space-y-2 hover:bg-primary/5 bg-transparent btn-enhanced card-enhanced"
                >
                  <Users className="h-6 w-6" />
                  <span>시간표 최적화</span>
                </Button>
              </Link>

              <Link href="/dashboard/feedback">
                <Button
                  variant="outline"
                  className="w-full h-20 flex flex-col items-center justify-center space-y-2 hover:bg-primary/5 bg-transparent btn-enhanced card-enhanced"
                >
                  <MessageSquare className="h-6 w-6" />
                  <span>피드백 제출</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Submissions */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>최근 제출물</CardTitle>
                <CardDescription>최근 제출한 작업들을 확인하세요</CardDescription>
              </div>
              <Link href="/dashboard/submissions">
                <Button variant="ghost" size="sm" className="btn-enhanced hover-lift">
                  전체 보기
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {recentSubmissions.length > 0 ? (
                <div className="space-y-4">
                  {recentSubmissions.map((submission) => (
                    <div
                      key={submission.id}
                      className="flex items-center justify-between p-3 border border-border rounded-lg"
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{submission.title}</h4>
                        <p className="text-xs text-muted-foreground">{submission.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(submission.created_at).toLocaleDateString("ko-KR")}
                        </p>
                      </div>
                      <Badge
                        variant={
                          submission.status === "completed"
                            ? "default"
                            : submission.status === "processing"
                              ? "secondary"
                              : submission.status === "failed"
                                ? "destructive"
                                : "outline"
                        }
                      >
                        {submission.status === "completed"
                          ? "완료"
                          : submission.status === "processing"
                            ? "처리중"
                            : submission.status === "failed"
                              ? "실패"
                              : "대기"}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">아직 제출물이 없습니다</p>
                  <Link href="/customer/timetable">
                    <Button className="mt-4 btn-enhanced btn-primary-enhanced">
                      <Plus className="h-4 w-4 mr-2" />첫 작업 시작하기
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Notes */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>최근 메모</CardTitle>
                <CardDescription>중요한 메모들을 빠르게 확인하세요</CardDescription>
              </div>
              <Link href="/dashboard/notes">
                <Button variant="ghost" size="sm" className="btn-enhanced hover-lift">
                  전체 보기
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {recentNotes.length > 0 ? (
                <div className="space-y-4">
                  {recentNotes.map((note) => (
                    <div key={note.id} className="p-3 border border-border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">{note.title}</h4>
                        <Badge
                          variant={
                            note.priority === "high"
                              ? "destructive"
                              : note.priority === "medium"
                                ? "secondary"
                                : "outline"
                          }
                          className="text-xs"
                        >
                          {note.priority === "high" ? "높음" : note.priority === "medium" ? "보통" : "낮음"}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">{note.content}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(note.updated_at).toLocaleDateString("ko-KR")}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">아직 메모가 없습니다</p>
                  <Link href="/dashboard/notes">
                    <Button className="mt-4 btn-enhanced btn-primary-enhanced">
                      <Plus className="h-4 w-4 mr-2" />첫 메모 작성하기
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
