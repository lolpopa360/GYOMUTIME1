"use client"

import type React from "react"

import { useAuth } from "@/lib/auth-context"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/ui/logo"
import {
  Home,
  FileText,
  Calendar,
  MessageSquare,
  Settings,
  LogOut,
  User,
  Bell,
  Download,
  Activity,
  HelpCircle,
} from "lucide-react"
import { NotificationBadge } from "@/components/notification-badge"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const sidebarItems = [
  {
    title: "대시보드",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "메모 관리",
    href: "/dashboard/notes",
    icon: FileText,
  },
  {
    title: "제출물 현황",
    href: "/dashboard/submissions",
    icon: Calendar,
  },
  {
    title: "실시간 추적",
    href: "/dashboard/requests",
    icon: Activity,
  },
  {
    title: "문서 다운로드",
    href: "/dashboard/downloads",
    icon: Download,
  },
  {
    title: "문의하기",
    href: "/dashboard/inquiries",
    icon: HelpCircle,
  },
  {
    title: "피드백",
    href: "/dashboard/feedback",
    icon: MessageSquare,
  },
  {
    title: "알림",
    href: "/dashboard/notifications",
    icon: Bell,
  },
]

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, userProfile, logout } = useAuth()
  const pathname = usePathname()

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar className="border-r border-border">
          <SidebarHeader className="border-b border-border p-4">
            <div className="flex items-center space-x-2">
              <Logo size="sm" />
              <div className="flex-1">
                <h2 className="font-semibold text-sm">교무타임</h2>
                <p className="text-xs text-muted-foreground">대시보드</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-4">
            <nav className="space-y-2">
              {sidebarItems.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href

                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start",
                        isActive && "bg-primary/10 text-primary hover:bg-primary/20",
                      )}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {item.title}
                      {item.href === "/dashboard/notifications" && <NotificationBadge />}
                    </Button>
                  </Link>
                )
              })}
            </nav>

            <div className="mt-8 pt-4 border-t border-border">
              <h3 className="text-xs font-medium text-muted-foreground mb-2">빠른 작업</h3>
              <div className="space-y-1">
                <Link href="/customer/timetable">
                  <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                    시간표 최적화
                  </Button>
                </Link>
                <Link href="/customer/electives">
                  <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                    선택과목 분반
                  </Button>
                </Link>
              </div>
            </div>
          </SidebarContent>

          <SidebarFooter className="border-t border-border p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{userProfile?.name || user?.displayName || "사용자"}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
              </div>
            </div>

            <div className="space-y-1">
              <Button variant="ghost" size="sm" className="w-full justify-start">
                <Settings className="h-4 w-4 mr-2" />
                설정
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
                onClick={logout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                로그아웃
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <div className="flex-1 flex flex-col">
          <div className="flex items-center p-4 border-b border-border lg:hidden">
            <SidebarTrigger />
            <h1 className="ml-4 font-semibold">대시보드</h1>
          </div>

          <main className="flex-1">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  )
}
