import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Logo } from "@/components/ui/logo"
import { CheckCircle, Mail } from "lucide-react"
import Link from "next/link"

export default function SignUpSuccessPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col gap-6">
          <div className="text-center">
            <Logo size="md" className="mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground">회원가입 완료</h1>
          </div>

          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 p-3 bg-green-100 rounded-full w-fit">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle className="text-xl text-green-700">이메일 확인 필요</CardTitle>
              <CardDescription>회원가입이 완료되었습니다. 이메일을 확인해주세요.</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="bg-muted/20 p-4 rounded-lg">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <Mail className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">이메일 인증</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  가입하신 이메일 주소로 인증 링크를 보내드렸습니다. 이메일의 링크를 클릭하여 계정을 활성화해주세요.
                </p>
              </div>

              <p className="text-sm text-muted-foreground">이메일을 받지 못하셨나요? 스팸 폴더를 확인해보세요.</p>

              <Link href="/auth/login" className="inline-block text-sm text-primary hover:underline">
                로그인 페이지로 돌아가기
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
