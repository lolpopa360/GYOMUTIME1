import { initializeApp } from "firebase/app"
import { getFirestore, collection, doc, setDoc, addDoc, Timestamp } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyDMIIfQ8P0iWVOfaVwLwF0Q3unKlAWj-04",
  authDomain: "gyomutime-61a6f.firebaseapp.com",
  projectId: "gyomutime-61a6f",
  storageBucket: "gyomutime-61a6f.firebasestorage.app",
  messagingSenderId: "863417171989",
  appId: "1:863417171989:web:a8d0226053509e206e8e1c",
  measurementId: "G-DQHPYVXS97",
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

async function initializeFirebaseCollections() {
  console.log("[v0] Initializing Firebase collections...")

  try {
    const coursesData = [
      {
        id: "MATH101",
        name: "미적분학 I",
        instructor: "김교수",
        credits: 3,
        requiredSlots: 3,
        preferredTimes: ["09:00", "10:45"],
        department: "수학과",
        capacity: 40,
        type: "lecture",
      },
      {
        id: "PHYS101",
        name: "일반물리학 I",
        instructor: "이교수",
        credits: 3,
        requiredSlots: 3,
        preferredTimes: ["13:30", "15:15"],
        department: "물리학과",
        capacity: 35,
        type: "lecture",
      },
      {
        id: "CHEM101",
        name: "일반화학 I",
        instructor: "박교수",
        credits: 3,
        requiredSlots: 2,
        preferredTimes: ["10:45", "15:15"],
        department: "화학과",
        capacity: 30,
        type: "lecture",
      },
      {
        id: "ENG101",
        name: "대학영어",
        instructor: "최교수",
        credits: 2,
        requiredSlots: 2,
        preferredTimes: ["09:00", "13:30"],
        department: "영어영문학과",
        capacity: 25,
        type: "lecture",
      },
      {
        id: "CS101",
        name: "컴퓨터과학개론",
        instructor: "정교수",
        credits: 3,
        requiredSlots: 3,
        preferredTimes: ["10:45", "17:00"],
        department: "컴퓨터공학과",
        capacity: 45,
        type: "lecture",
      },
    ]

    for (const course of coursesData) {
      await setDoc(doc(db, "courses", course.id), {
        ...course,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    }

    const roomsData = [
      {
        id: "A101",
        name: "강의실 A101",
        capacity: 50,
        type: "lecture",
        equipment: ["프로젝터", "화이트보드", "마이크"],
        building: "A동",
        floor: 1,
      },
      {
        id: "A102",
        name: "강의실 A102",
        capacity: 40,
        type: "lecture",
        equipment: ["프로젝터", "화이트보드"],
        building: "A동",
        floor: 1,
      },
      {
        id: "B201",
        name: "실험실 B201",
        capacity: 30,
        type: "lab",
        equipment: ["실험대", "후드", "안전장비"],
        building: "B동",
        floor: 2,
      },
      {
        id: "C301",
        name: "세미나실 C301",
        capacity: 20,
        type: "seminar",
        equipment: ["원형테이블", "화이트보드", "빔프로젝터"],
        building: "C동",
        floor: 3,
      },
      {
        id: "D401",
        name: "컴퓨터실 D401",
        capacity: 45,
        type: "lab",
        equipment: ["컴퓨터", "프로젝터", "네트워크"],
        building: "D동",
        floor: 4,
      },
    ]

    for (const room of roomsData) {
      await setDoc(doc(db, "rooms", room.id), {
        ...room,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    }

    const systemNotifications = [
      {
        userId: "system",
        title: "시스템 업데이트 완료",
        message: "교무타임 시스템이 v5로 업데이트되었습니다. 새로운 기능을 확인해보세요.",
        type: "success",
        category: "system",
        isRead: false,
        actionUrl: "/dashboard",
        actionText: "대시보드 보기",
      },
      {
        userId: "system",
        title: "시간표 최적화 알고리즘 개선",
        message: "더욱 정확하고 빠른 시간표 생성을 위해 알고리즘이 개선되었습니다.",
        type: "info",
        category: "update",
        isRead: false,
        actionUrl: "/customer/timetable",
        actionText: "시간표 생성하기",
      },
    ]

    for (const notification of systemNotifications) {
      await addDoc(collection(db, "notifications"), {
        ...notification,
        createdAt: Timestamp.now(),
      })
    }

    const dataFiles = [
      {
        filename: "timetable-template.xlsx",
        originalName: "시간표 템플릿.xlsx",
        filePath: "templates/timetable-template.xlsx",
        fileSize: 15360,
        fileType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        category: "template",
        description: "시간표 생성을 위한 기본 템플릿 파일",
        uploadedBy: "admin",
        downloadCount: 0,
        isPublic: true,
      },
      {
        filename: "course-example.csv",
        originalName: "과목 예시 데이터.csv",
        filePath: "examples/course-example.csv",
        fileSize: 8192,
        fileType: "text/csv",
        category: "example",
        description: "과목 데이터 입력 예시 파일",
        uploadedBy: "admin",
        downloadCount: 0,
        isPublic: true,
      },
      {
        filename: "user-manual.pdf",
        originalName: "사용자 매뉴얼.pdf",
        filePath: "documents/user-manual.pdf",
        fileSize: 2048000,
        fileType: "application/pdf",
        category: "document",
        description: "교무타임 사용자 매뉴얼",
        uploadedBy: "admin",
        downloadCount: 0,
        isPublic: true,
      },
    ]

    for (const file of dataFiles) {
      await addDoc(collection(db, "data_files"), {
        ...file,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      })
    }

    console.log("[v0] Firebase collections initialized successfully!")
    console.log("[v0] Created:", coursesData.length, "courses")
    console.log("[v0] Created:", roomsData.length, "rooms")
    console.log("[v0] Created:", systemNotifications.length, "system notifications")
    console.log("[v0] Created:", dataFiles.length, "data files")
  } catch (error) {
    console.error("[v0] Error initializing Firebase collections:", error)
    throw error
  }
}

// Run initialization
initializeFirebaseCollections()
  .then(() => {
    console.log("[v0] Database initialization complete!")
    process.exit(0)
  })
  .catch((error) => {
    console.error("[v0] Database initialization failed:", error)
    process.exit(1)
  })
