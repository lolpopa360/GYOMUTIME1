import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  where,
  orderBy,
  Timestamp,
} from "firebase/firestore"
import { db } from "./config"

export interface Submission {
  id?: string
  userId: string
  title: string
  description: string
  status: "pending" | "processing" | "completed" | "failed"
  type: "timetable" | "electives"
  data: any
  createdAt: Date
  updatedAt: Date
  completedAt?: Date
}

export interface Note {
  id?: string
  userId: string
  title: string
  content: string
  priority: "low" | "medium" | "high"
  tags: string[]
  createdAt: Date
  updatedAt: Date
}

export interface Feedback {
  id?: string
  userId: string
  rating: number
  comment: string
  category: "bug" | "feature" | "general"
  status: "open" | "in-progress" | "resolved"
  createdAt: Date
}

export interface Notification {
  id?: string
  userId: string
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
  category: "submission" | "system" | "reminder" | "update"
  isRead: boolean
  actionUrl?: string
  actionText?: string
  metadata?: any
  createdAt: Date
  readAt?: Date
}

// Submissions
export const createSubmission = async (submission: Omit<Submission, "id" | "createdAt" | "updatedAt">) => {
  try {
    const docRef = await addDoc(collection(db, "submissions"), {
      ...submission,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    })
    return docRef.id
  } catch (error) {
    throw error
  }
}

export const updateSubmissionStatus = async (id: string, status: Submission["status"], completedAt?: Date) => {
  try {
    const updateData: any = {
      status,
      updatedAt: Timestamp.now(),
    }

    if (completedAt) {
      updateData.completedAt = Timestamp.fromDate(completedAt)
    }

    await updateDoc(doc(db, "submissions", id), updateData)
  } catch (error) {
    throw error
  }
}

export const getUserSubmissions = async (userId: string) => {
  try {
    const q = query(collection(db, "submissions"), where("userId", "==", userId), orderBy("createdAt", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate(),
      completedAt: doc.data().completedAt?.toDate(),
    })) as Submission[]
  } catch (error) {
    throw error
  }
}

// Notes
export const createNote = async (note: Omit<Note, "id" | "createdAt" | "updatedAt">) => {
  try {
    const docRef = await addDoc(collection(db, "notes"), {
      ...note,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    })
    return docRef.id
  } catch (error) {
    throw error
  }
}

export const updateNote = async (id: string, updates: Partial<Omit<Note, "id" | "userId" | "createdAt">>) => {
  try {
    await updateDoc(doc(db, "notes", id), {
      ...updates,
      updatedAt: Timestamp.now(),
    })
  } catch (error) {
    throw error
  }
}

export const deleteNote = async (id: string) => {
  try {
    await deleteDoc(doc(db, "notes", id))
  } catch (error) {
    throw error
  }
}

export const getUserNotes = async (userId: string) => {
  try {
    const q = query(collection(db, "notes"), where("userId", "==", userId), orderBy("updatedAt", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate(),
    })) as Note[]
  } catch (error) {
    throw error
  }
}

// Feedback
export const createFeedback = async (feedback: Omit<Feedback, "id" | "createdAt">) => {
  try {
    const docRef = await addDoc(collection(db, "feedback"), {
      ...feedback,
      createdAt: Timestamp.now(),
    })
    return docRef.id
  } catch (error) {
    throw error
  }
}

export const getAllFeedback = async () => {
  try {
    const q = query(collection(db, "feedback"), orderBy("createdAt", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
    })) as Feedback[]
  } catch (error) {
    throw error
  }
}

// Notifications
export const createNotification = async (notification: Omit<Notification, "id" | "createdAt">) => {
  try {
    const docRef = await addDoc(collection(db, "notifications"), {
      ...notification,
      createdAt: Timestamp.now(),
    })
    return docRef.id
  } catch (error) {
    throw error
  }
}

export const markNotificationAsRead = async (id: string) => {
  try {
    await updateDoc(doc(db, "notifications", id), {
      isRead: true,
      readAt: Timestamp.now(),
    })
  } catch (error) {
    throw error
  }
}

export const markAllNotificationsAsRead = async (userId: string) => {
  try {
    const q = query(collection(db, "notifications"), where("userId", "==", userId), where("isRead", "==", false))
    const querySnapshot = await getDocs(q)

    const batch = querySnapshot.docs.map((doc) =>
      updateDoc(doc.ref, {
        isRead: true,
        readAt: Timestamp.now(),
      }),
    )

    await Promise.all(batch)
  } catch (error) {
    throw error
  }
}

export const deleteNotification = async (id: string) => {
  try {
    await deleteDoc(doc(db, "notifications", id))
  } catch (error) {
    throw error
  }
}

export const getUserNotifications = async (userId: string) => {
  try {
    const q = query(collection(db, "notifications"), where("userId", "==", userId), orderBy("createdAt", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      readAt: doc.data().readAt?.toDate(),
    })) as Notification[]
  } catch (error) {
    throw error
  }
}

export const getUnreadNotificationCount = async (userId: string): Promise<number> => {
  try {
    const q = query(collection(db, "notifications"), where("userId", "==", userId), where("isRead", "==", false))
    const querySnapshot = await getDocs(q)
    return querySnapshot.size
  } catch (error) {
    console.error("Error getting unread count:", error)
    return 0
  }
}

// User Profiles
export const createUserProfile = async (profile: {
  userId: string
  name: string
  email: string
  role: "user" | "admin"
}) => {
  try {
    await addDoc(collection(db, "users"), {
      ...profile,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    })
  } catch (error) {
    throw error
  }
}
