"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MessageSquare, Bug, Lightbulb, Send, CheckCircle } from "lucide-react"
import { createFeedback, getAllFeedback } from "@/lib/supabase/database"
import type { Feedback } from "@/lib/supabase/database"
import { useToast } from "@/hooks/use-toast"

export default function FeedbackPage() {
  const { user, userProfile, isLoading } = useAuth()
  const { toast } = useToast()
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([])
  const [loadingFeedbacks, setLoadingFeedbacks] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [comment, setComment] = useState("")
  const [category, setCategory] = useState<"bug" | "feature" | "general">("general")

  useEffect(() => {
    const loadFeedbacks = async () => {
      try {
        const allFeedbacks = await getAllFeedback()
        const userFeedbacks = allFeedbacks.filter((f) => f.user_id === user?.id)
        setFeedbacks(userFeedbacks)
      } catch (error) {
        console.error("Error loading feedbacks:", error)
      } finally {
        setLoadingFeedbacks(false)
      }
    }

    if (user) {
      loadFeedbacks()
    }
  }, [user])

  const handleSubmitFeedback = async () => {
    if (!user || !comment.trim() || rating === 0) {
      toast({
        title: "입력 오류",
        description: "평점과 의견을 모두 입력해주세요.",
        variant: "destructive",
      })
      return
    }

    setSubmitting(true)
    try {
      await createFeedback({
        user_id: user.id,
        rating,
        comment: comment.trim(),
        category,
        status: "open",
      })

      // Reset form
      setRating(0)
      setComment("")
      setCategory("general")

      // Reload feedbacks
      const allFeedbacks = await getAllFeedback()
      const userFeedbacks = allFeedbacks.filter((f) => f.user_id === user.id)
      setFeedbacks(userFeedbacks)

      toast({
        title: "피드백 제출 완료",
        description: "소중한 의견을 보내주셔서 감사합니다. 검토 후 반영하겠습니다.",
      })
    } catch (error) {
      console.error("Error submitting feedback:", error)
      toast({
        title: "제출 실패",
        description: "피드백 제출 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case "bug":
        return <Bug className="h-4 w-4" />
      case "feature":
        return <Lightbulb className="h-4 w-4" />
      default:
        return <MessageSquare className="h-4 w-4" />
    }
  }

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case "bug":
        return "버그 신고"
      case "feature":
        return "기능 제안"
      default:
        return "일반 의견"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "resolved":
        return "해결됨"
      case "in-progress":
        return "처리중"
      default:
        return "접수됨"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">피드백 페이지를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">피드백</h1>
              <p className="text-muted-foreground">서비스 개선을 위한 소중한 의견을 들려주세요</p>
            </div>
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              {feedbacks.length}개 제출
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Feedback Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Send className="h-5 w-5 mr-2" />새 피드백 작성
              </CardTitle>
              <CardDescription>
                교무타임 서비스에 대한 의견, 버그 신고, 기능 제안 등을 자유롭게 작성해주세요.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Rating */}
              <div>
                <Label className="text-sm font-medium">서비스 만족도</Label>
                <div className="flex items-center space-x-1 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      className="p-1 hover:scale-[1.1] transition-transform"
                      onMouseEnter={() => setHoveredRating(star)}
                      onMouseLeave={() => setHoveredRating(0)}
                      onClick={() => setRating(star)}
                    >
                      <Star
                        className={`h-6 w-6 ${
                          star <= (hoveredRating || rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-muted-foreground"
                        }`}
                      />
                    </button>
                  ))}
                  <span className="ml-2 text-sm text-muted-foreground">{rating > 0 && `${rating}점`}</span>
                </div>
              </div>

              {/* Category */}
              <div>
                <Label htmlFor="category" className="text-sm font-medium">
                  피드백 유형
                </Label>
                <Select value={category} onValueChange={(value: "bug" | "feature" | "general") => setCategory(value)}>
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">
                      <div className="flex items-center">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        일반 의견
                      </div>
                    </SelectItem>
                    <SelectItem value="bug">
                      <div className="flex items-center">
                        <Bug className="h-4 w-4 mr-2" />
                        버그 신고
                      </div>
                    </SelectItem>
                    <SelectItem value="feature">
                      <div className="flex items-center">
                        <Lightbulb className="h-4 w-4 mr-2" />
                        기능 제안
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Comment */}
              <div>
                <Label htmlFor="comment" className="text-sm font-medium">
                  상세 의견
                </Label>
                <Textarea
                  id="comment"
                  placeholder="구체적인 의견이나 제안사항을 작성해주세요..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="mt-2 min-h-[120px]"
                />
                <p className="text-xs text-muted-foreground mt-1">{comment.length}/500자</p>
              </div>

              <Button
                onClick={handleSubmitFeedback}
                disabled={submitting || !comment.trim() || rating === 0}
                className="w-full"
              >
                {submitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    제출 중...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    피드백 제출
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Previous Feedbacks */}
          <Card>
            <CardHeader>
              <CardTitle>제출한 피드백</CardTitle>
              <CardDescription>이전에 제출한 피드백들과 처리 상태를 확인하세요</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingFeedbacks ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">피드백을 불러오는 중...</p>
                </div>
              ) : feedbacks.length > 0 ? (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {feedbacks.map((feedback) => (
                    <div key={feedback.id} className="p-4 border border-border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getCategoryIcon(feedback.category)}
                          <span className="text-sm font-medium">{getCategoryLabel(feedback.category)}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-3 w-3 ${
                                  star <= feedback.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"
                                }`}
                              />
                            ))}
                          </div>
                          <Badge
                            variant={
                              feedback.status === "resolved"
                                ? "default"
                                : feedback.status === "in-progress"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {feedback.status === "resolved" && <CheckCircle className="h-3 w-3 mr-1" />}
                            {getStatusLabel(feedback.status)}
                          </Badge>
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground">{feedback.comment}</p>

                      <p className="text-xs text-muted-foreground">
                        {new Date(feedback.created_at).toLocaleDateString("ko-KR", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">아직 제출한 피드백이 없습니다</p>
                  <p className="text-sm text-muted-foreground mt-1">왼쪽 양식을 통해 첫 피드백을 작성해보세요</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
