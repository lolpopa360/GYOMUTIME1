"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Logo } from "@/components/ui/logo"
import { getAllInquiries, respondToInquiry, updateInquiry } from "@/lib/supabase/admin"
import {
  MessageSquare,
  Clock,
  CheckCircle,
  AlertCircle,
  Search,
  Filter,
  Reply,
  MessageCircle,
  User,
  Calendar,
  LogOut,
  ArrowLeft,
  Send,
  Loader2,
} from "lucide-react"
import Link from "next/link"

interface Inquiry {
  id: string
  title: string
  category: "technical" | "billing" | "feature" | "general"
  priority: "low" | "medium" | "high" | "urgent"
  status: "new" | "in_progress" | "resolved" | "closed"
  description: string
  submittedAt: Date
  updatedAt: Date
  submittedBy: string
  submittedByEmail: string
  response?: string
  respondedBy?: string
  respondedAt?: Date
}

export default function AdminInquiries() {
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const [inquiries, setInquiries] = useState<Inquiry[]>([])
  const [loading, setLoading] = useState(true)
  const [responding, setResponding] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | Inquiry["status"]>("all")
  const [priorityFilter, setPriorityFilter] = useState<"all" | Inquiry["priority"]>("all")
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null)
  const [isResponseDialogOpen, setIsResponseDialogOpen] = useState(false)
  const [responseData, setResponseData] = useState({
    status: "in_progress" as Inquiry["status"],
    response: "",
  })

  useEffect(() => {
    loadInquiries()
  }, [])

  const loadInquiries = async () => {
    try {
      setLoading(true)
      const data = await getAllInquiries()

      const transformedInquiries: Inquiry[] = data.map((inquiry) => ({
        id: inquiry.id,
        title: inquiry.title,
        category: inquiry.category,
        priority: inquiry.priority,
        status: inquiry.status === "in_progress" ? "in_progress" : inquiry.status,
        description: inquiry.content,
        submittedAt: new Date(inquiry.created_at),
        updatedAt: new Date(inquiry.updated_at),
        submittedBy: inquiry.profiles?.name || "Unknown User",
        submittedByEmail: inquiry.profiles?.email || "unknown@example.com",
        response: inquiry.admin_response,
        respondedBy: inquiry.responded_by,
        respondedAt: inquiry.responded_at ? new Date(inquiry.responded_at) : undefined,
      }))

      setInquiries(transformedInquiries)
    } catch (error) {
      console.error("Error loading inquiries:", error)
      toast({
        title: "오류",
        description: "문의 목록을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })

      const mockInquiries: Inquiry[] = [
        {
          id: "1",
          title: "시간표 생성 오류 문의",
          category: "technical",
          priority: "high",
          status: "resolved",
          description: "시간표 생성 시 특정 과목이 배정되지 않는 문제가 발생합니다.",
          submittedAt: new Date("2024-01-15"),
          updatedAt: new Date("2024-01-16"),
          submittedBy: "김영희",
          submittedByEmail: "kim@example.com",
          response: "해당 문제는 과목 코드 설정 오류로 인한 것이었습니다. 수정 완료되었습니다.",
          respondedBy: "관리자",
          respondedAt: new Date("2024-01-16"),
        },
        {
          id: "2",
          title: "분반 배정 기준 문의",
          category: "general",
          priority: "medium",
          status: "in_progress",
          description: "선택과목 분반 배정 시 어떤 기준으로 학생들이 배정되는지 궁금합니다.",
          submittedAt: new Date("2024-01-14"),
          updatedAt: new Date("2024-01-14"),
          submittedBy: "박민수",
          submittedByEmail: "park@example.com",
        },
      ]
      setInquiries(mockInquiries)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "new":
        return (
          <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            <MessageCircle className="h-3 w-3 mr-1" />새 문의
          </Badge>
        )
      case "in_progress":
        return (
          <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
            <Clock className="h-3 w-3 mr-1" />
            처리중
          </Badge>
        )
      case "resolved":
        return (
          <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
            <CheckCircle className="h-3 w-3 mr-1" />
            해결완료
          </Badge>
        )
      case "closed":
        return (
          <Badge variant="outline">
            <AlertCircle className="h-3 w-3 mr-1" />
            종료
          </Badge>
        )
      default:
        return <Badge variant="secondary">알 수 없음</Badge>
    }
  }

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "technical":
        return <Badge className="bg-red-500/10 text-red-600">기술 문의</Badge>
      case "billing":
        return <Badge className="bg-purple-500/10 text-purple-600">결제 문의</Badge>
      case "feature":
        return <Badge className="bg-blue-500/10 text-blue-600">기능 요청</Badge>
      case "general":
        return <Badge className="bg-gray-500/10 text-gray-600">일반 문의</Badge>
      default:
        return <Badge variant="secondary">기타</Badge>
    }
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "urgent":
        return (
          <Badge variant="destructive" className="text-xs">
            긴급
          </Badge>
        )
      case "high":
        return <Badge className="bg-orange-500/10 text-orange-600 text-xs">높음</Badge>
      case "medium":
        return <Badge className="bg-yellow-500/10 text-yellow-600 text-xs">보통</Badge>
      case "low":
        return (
          <Badge variant="outline" className="text-xs">
            낮음
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="text-xs">
            보통
          </Badge>
        )
    }
  }

  const handleRespond = (inquiry: Inquiry) => {
    setSelectedInquiry(inquiry)
    setResponseData({
      status: inquiry.status === "new" ? "in_progress" : inquiry.status,
      response: inquiry.response || "",
    })
    setIsResponseDialogOpen(true)
  }

  const handleSubmitResponse = async () => {
    if (!selectedInquiry || !user) return

    setResponding(true)
    try {
      if (responseData.response.trim()) {
        await respondToInquiry(selectedInquiry.id, responseData.response, user.uid)
      } else {
        await updateInquiry(selectedInquiry.id, { status: responseData.status })
      }

      toast({
        title: "답변 완료",
        description: `${selectedInquiry.submittedBy}님의 문의에 답변이 등록되었습니다.`,
      })

      setIsResponseDialogOpen(false)
      setSelectedInquiry(null)

      await loadInquiries()
    } catch (error) {
      console.error("Error submitting response:", error)
      toast({
        title: "답변 실패",
        description: "답변 등록 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setResponding(false)
    }
  }

  const filteredInquiries = inquiries.filter((inquiry) => {
    const matchesSearch =
      inquiry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inquiry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inquiry.submittedBy.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || inquiry.status === statusFilter
    const matchesPriority = priorityFilter === "all" || inquiry.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  const sortedInquiries = filteredInquiries.sort((a, b) => {
    const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 }
    const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority]
    if (priorityDiff !== 0) return priorityDiff
    return b.submittedAt.getTime() - a.submittedAt.getTime()
  })

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="min-h-screen bg-background">
          <header className="border-b border-border bg-card/50">
            <div className="container mx-auto px-4 py-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Link href="/admin">
                    <Button variant="ghost" size="sm">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      관리자 대시보드
                    </Button>
                  </Link>
                  <div className="h-6 w-px bg-border"></div>
                  <Logo size="md" />
                  <div>
                    <h1 className="text-2xl font-bold text-foreground">문의 관리</h1>
                    <p className="text-xs text-muted-foreground">User Inquiry Management</p>
                  </div>
                </div>
              </div>
            </div>
          </header>

          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
                <p className="text-muted-foreground">문의 목록을 불러오는 중...</p>
              </div>
            </div>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Link href="/admin">
                  <Button variant="ghost" size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    관리자 대시보드
                  </Button>
                </Link>
                <div className="h-6 w-px bg-border"></div>
                <Logo size="md" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground">문의 관리</h1>
                  <p className="text-xs text-muted-foreground">User Inquiry Management</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  {user?.photoURL && (
                    <img
                      src={user.photoURL || "/placeholder.svg"}
                      alt={user.displayName || ""}
                      className="w-8 h-8 rounded-full"
                    />
                  )}
                  <span className="text-sm text-muted-foreground">{user?.displayName}님</span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  로그아웃
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">전체 문의</CardTitle>
                  <MessageSquare className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{inquiries.length}</div>
                <p className="text-xs text-muted-foreground">총 문의 수</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">새 문의</CardTitle>
                  <MessageCircle className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-500">
                  {inquiries.filter((i) => i.status === "new").length}
                </div>
                <p className="text-xs text-muted-foreground">답변 대기중</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">긴급 문의</CardTitle>
                  <AlertCircle className="h-4 w-4 text-red-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-500">
                  {inquiries.filter((i) => i.priority === "urgent").length}
                </div>
                <p className="text-xs text-muted-foreground">긴급 처리 필요</p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">해결완료</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">
                  {inquiries.filter((i) => i.status === "resolved").length}
                </div>
                <p className="text-xs text-muted-foreground">답변 완료</p>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">사용자 문의 목록</CardTitle>
                  <CardDescription>사용자들의 문의를 확인하고 답변할 수 있습니다.</CardDescription>
                </div>
              </div>

              <div className="flex items-center space-x-4 mt-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="제목, 내용, 사용자명으로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={(value: typeof statusFilter) => setStatusFilter(value)}>
                  <SelectTrigger className="w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">모든 상태</SelectItem>
                    <SelectItem value="new">새 문의</SelectItem>
                    <SelectItem value="in_progress">처리중</SelectItem>
                    <SelectItem value="resolved">해결완료</SelectItem>
                    <SelectItem value="closed">종료</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={priorityFilter}
                  onValueChange={(value: typeof priorityFilter) => setPriorityFilter(value)}
                >
                  <SelectTrigger className="w-40">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">모든 우선순위</SelectItem>
                    <SelectItem value="urgent">긴급</SelectItem>
                    <SelectItem value="high">높음</SelectItem>
                    <SelectItem value="medium">보통</SelectItem>
                    <SelectItem value="low">낮음</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>문의 정보</TableHead>
                      <TableHead>사용자</TableHead>
                      <TableHead>카테고리</TableHead>
                      <TableHead>우선순위</TableHead>
                      <TableHead>상태</TableHead>
                      <TableHead>등록일</TableHead>
                      <TableHead>작업</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedInquiries.map((inquiry) => (
                      <TableRow key={inquiry.id} className="border-border">
                        <TableCell>
                          <div>
                            <div className="font-medium">{inquiry.title}</div>
                            <div className="text-sm text-muted-foreground line-clamp-2">{inquiry.description}</div>
                            {inquiry.response && (
                              <div className="mt-2 p-2 bg-green-50 border-l-4 border-green-500 rounded">
                                <div className="text-sm font-medium text-green-800">답변:</div>
                                <div className="text-sm text-green-700">{inquiry.response}</div>
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <div className="font-medium text-sm">{inquiry.submittedBy}</div>
                              <div className="text-xs text-muted-foreground">{inquiry.submittedByEmail}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{getCategoryBadge(inquiry.category)}</TableCell>
                        <TableCell>{getPriorityBadge(inquiry.priority)}</TableCell>
                        <TableCell>{getStatusBadge(inquiry.status)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          <div className="flex items-center space-x-2">
                            <Calendar className="h-4 w-4" />
                            <span>{inquiry.submittedAt.toLocaleDateString("ko-KR")}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" onClick={() => handleRespond(inquiry)}>
                            <Reply className="h-3 w-3 mr-1" />
                            {inquiry.response ? "답변 수정" : "답변하기"}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        <Dialog open={isResponseDialogOpen} onOpenChange={setIsResponseDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>문의 답변</DialogTitle>
              <DialogDescription>{selectedInquiry?.submittedBy}님의 문의에 답변하세요</DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="bg-muted/20 p-4 rounded-lg">
                <h4 className="font-medium mb-2">원본 문의</h4>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">제목:</span>
                    <span className="text-sm">{selectedInquiry?.title}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">카테고리:</span>
                    {selectedInquiry && getCategoryBadge(selectedInquiry.category)}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">우선순위:</span>
                    {selectedInquiry && getPriorityBadge(selectedInquiry.priority)}
                  </div>
                  <div>
                    <span className="text-sm font-medium">내용:</span>
                    <div className="text-sm mt-1 p-2 bg-background rounded border">{selectedInquiry?.description}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="status">처리 상태</Label>
                  <Select
                    value={responseData.status}
                    onValueChange={(value: Inquiry["status"]) =>
                      setResponseData((prev) => ({ ...prev, status: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="in_progress">처리중</SelectItem>
                      <SelectItem value="resolved">해결완료</SelectItem>
                      <SelectItem value="closed">종료</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="response">답변 내용</Label>
                  <Textarea
                    id="response"
                    placeholder="사용자에게 전달할 답변을 작성하세요..."
                    value={responseData.response}
                    onChange={(e) => setResponseData((prev) => ({ ...prev, response: e.target.value }))}
                    rows={6}
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsResponseDialogOpen(false)}>
                  취소
                </Button>
                <Button onClick={handleSubmitResponse} disabled={responding}>
                  {responding ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      답변 중...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      답변 전송
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </ProtectedRoute>
  )
}
