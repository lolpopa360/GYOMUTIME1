"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { getUnreadNotificationCount } from "@/lib/firebase/firestore"

export function NotificationBadge() {
  const { user } = useAuth()
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    const loadUnreadCount = async () => {
      if (!user) return

      try {
        const count = await getUnreadNotificationCount(user.uid)
        setUnreadCount(count)
      } catch (error) {
        console.error("Error loading unread count:", error)
      }
    }

    loadUnreadCount()

    // Poll for updates every 30 seconds
    const interval = setInterval(loadUnreadCount, 30000)

    return () => clearInterval(interval)
  }, [user])

  if (unreadCount === 0) return null

  return (
    <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 text-xs flex items-center justify-center">
      {unreadCount > 99 ? "99+" : unreadCount}
    </Badge>
  )
}
