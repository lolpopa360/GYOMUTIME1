"use client"

import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Search,
  Bell,
  Check,
  CheckCheck,
  Trash2,
  ExternalLink,
  Info,
  CheckCircle,
  AlertTriangle,
  AlertCircle,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"
import {
  getUserNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  deleteNotification,
} from "@/lib/supabase/database"
import type { Notification } from "@/lib/supabase/database"
import { useToast } from "@/hooks/use-toast"
import { formatDistanceToNow } from "date-fns"
import { ko } from "date-fns/locale"

export default function NotificationsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [filteredNotifications, setFilteredNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  useEffect(() => {
    loadNotifications()
  }, [user])

  useEffect(() => {
    filterNotifications()
  }, [notifications, searchTerm, typeFilter, categoryFilter, statusFilter])

  const loadNotifications = async () => {
    if (!user) return

    try {
      const userNotifications = await getUserNotifications(user.id)
      setNotifications(userNotifications)
    } catch (error) {
      console.error("Error loading notifications:", error)
      toast({
        title: "오류",
        description: "알림을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterNotifications = () => {
    let filtered = notifications

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (notification) =>
          notification.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          notification.message.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Type filter
    if (typeFilter !== "all") {
      filtered = filtered.filter((notification) => notification.type === typeFilter)
    }

    // Category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter((notification) => notification.category === categoryFilter)
    }

    // Status filter
    if (statusFilter !== "all") {
      if (statusFilter === "read") {
        filtered = filtered.filter((notification) => notification.is_read)
      } else if (statusFilter === "unread") {
        filtered = filtered.filter((notification) => !notification.is_read)
      }
    }

    setFilteredNotifications(filtered)
  }

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markNotificationAsRead(notificationId)
      toast({
        title: "성공",
        description: "알림을 읽음으로 표시했습니다.",
      })
      loadNotifications()
    } catch (error) {
      console.error("Error marking as read:", error)
      toast({
        title: "오류",
        description: "알림 상태 변경 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleMarkAllAsRead = async () => {
    if (!user) return

    try {
      await markAllNotificationsAsRead(user.id)
      toast({
        title: "성공",
        description: "모든 알림을 읽음으로 표시했습니다.",
      })
      loadNotifications()
    } catch (error) {
      console.error("Error marking all as read:", error)
      toast({
        title: "오류",
        description: "알림 상태 변경 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteNotification = async (notificationId: string) => {
    try {
      await deleteNotification(notificationId)
      toast({
        title: "성공",
        description: "알림이 삭제되었습니다.",
      })
      loadNotifications()
    } catch (error) {
      console.error("Error deleting notification:", error)
      toast({
        title: "오류",
        description: "알림 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "info":
        return <Info className="h-4 w-4 text-blue-500" />
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Bell className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "info":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            정보
          </Badge>
        )
      case "success":
        return (
          <Badge variant="default" className="bg-green-500/10 text-green-600 border-green-500/20">
            성공
          </Badge>
        )
      case "warning":
        return (
          <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
            경고
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive" className="bg-red-500/10 text-red-600 border-red-500/20">
            오류
          </Badge>
        )
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "submission":
        return <Badge variant="outline">제출물</Badge>
      case "system":
        return <Badge variant="secondary">시스템</Badge>
      case "reminder":
        return <Badge variant="outline">알림</Badge>
      case "update":
        return <Badge variant="secondary">업데이트</Badge>
      default:
        return <Badge variant="outline">{category}</Badge>
    }
  }

  const unreadCount = notifications.filter((n) => !n.is_read).length
  const totalCount = notifications.length

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">알림을 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <Bell className="h-8 w-8 mr-3" />
            알림 센터
          </h1>
          <p className="text-muted-foreground">시스템 알림과 업데이트를 확인하세요</p>
        </div>

        <div className="flex items-center space-x-2">
          <Button onClick={loadNotifications} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            새로고침
          </Button>

          {unreadCount > 0 && (
            <Button onClick={handleMarkAllAsRead} size="sm">
              <CheckCheck className="h-4 w-4 mr-2" />
              모두 읽음
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">총 알림</p>
                <p className="text-2xl font-bold text-primary">{totalCount}</p>
              </div>
              <Bell className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">읽지 않음</p>
                <p className="text-2xl font-bold text-red-600">{unreadCount}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">읽음</p>
                <p className="text-2xl font-bold text-green-600">{totalCount - unreadCount}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">이번 주</p>
                <p className="text-2xl font-bold text-blue-600">
                  {
                    notifications.filter((n) => {
                      const weekAgo = new Date()
                      weekAgo.setDate(weekAgo.getDate() - 7)
                      return new Date(n.created_at) > weekAgo
                    }).length
                  }
                </p>
              </div>
              <Info className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="알림 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="상태" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 상태</SelectItem>
                <SelectItem value="unread">읽지 않음</SelectItem>
                <SelectItem value="read">읽음</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="유형" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 유형</SelectItem>
                <SelectItem value="info">정보</SelectItem>
                <SelectItem value="success">성공</SelectItem>
                <SelectItem value="warning">경고</SelectItem>
                <SelectItem value="error">오류</SelectItem>
              </SelectContent>
            </Select>

            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="카테고리" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 카테고리</SelectItem>
                <SelectItem value="submission">제출물</SelectItem>
                <SelectItem value="system">시스템</SelectItem>
                <SelectItem value="reminder">알림</SelectItem>
                <SelectItem value="update">업데이트</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notifications List */}
      {filteredNotifications.length > 0 ? (
        <div className="space-y-4">
          {filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`transition-all hover:shadow-md ${
                !notification.is_read ? "border-l-4 border-l-primary bg-primary/5" : ""
              }`}
            >
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="mt-1">{getTypeIcon(notification.type)}</div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3
                          className={`font-semibold ${!notification.is_read ? "text-foreground" : "text-muted-foreground"}`}
                        >
                          {notification.title}
                        </h3>
                        {!notification.is_read && <div className="h-2 w-2 bg-primary rounded-full"></div>}
                      </div>

                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{notification.message}</p>

                      <div className="flex items-center space-x-2 mb-3">
                        {getTypeBadge(notification.type)}
                        {getCategoryBadge(notification.category)}
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true, locale: ko })}
                        </span>
                      </div>

                      {notification.action_url && notification.action_text && (
                        <Link href={notification.action_url}>
                          <Button variant="outline" size="sm" className="mb-2 bg-transparent">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            {notification.action_text}
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 ml-4">
                    {!notification.is_read && (
                      <Button variant="ghost" size="sm" onClick={() => handleMarkAsRead(notification.id!)}>
                        <Check className="h-4 w-4" />
                      </Button>
                    )}

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>알림 삭제</AlertDialogTitle>
                          <AlertDialogDescription>
                            이 알림을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>취소</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteNotification(notification.id!)}
                            className="bg-destructive hover:bg-destructive/90"
                          >
                            삭제
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <Bell className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">알림이 없습니다</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || typeFilter !== "all" || categoryFilter !== "all" || statusFilter !== "all"
                ? "검색 조건에 맞는 알림이 없습니다"
                : "새로운 알림이 도착하면 여기에 표시됩니다"}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
