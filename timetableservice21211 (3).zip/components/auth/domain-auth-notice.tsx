"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Copy, ExternalLink } from "lucide-react"

export function DomainAuthNotice() {
  const [currentDomain, setCurrentDomain] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined") {
      setCurrentDomain(window.location.origin)
    }
  }, [])

  const copyDomain = async () => {
    try {
      await navigator.clipboard.writeText(currentDomain)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy domain:", err)
    }
  }

  return (
    <Alert className="mb-6 border-orange-200 bg-orange-50">
      <AlertDescription className="space-y-4">
        <div>
          <h4 className="font-semibold text-orange-800 mb-2">Google 로그인을 위한 도메인 승인 필요</h4>
          <p className="text-orange-700 text-sm mb-3">
            Firebase에서 현재 도메인이 승인되지 않아 Google 로그인이 제한됩니다. Firebase Console에서 다음 도메인을
            승인해주세요:
          </p>
        </div>

        <div className="flex items-center gap-2 p-2 bg-white rounded border">
          <code className="flex-1 text-sm font-mono text-gray-800">{currentDomain}</code>
          <Button size="sm" variant="outline" onClick={copyDomain} className="h-8 bg-transparent">
            <Copy className="h-3 w-3 mr-1" />
            {copied ? "복사됨" : "복사"}
          </Button>
        </div>

        <div className="text-sm text-orange-700">
          <p className="font-medium mb-2">Firebase Console 설정 방법:</p>
          <ol className="list-decimal list-inside space-y-1 ml-2">
            <li>Firebase Console → Authentication → Settings → Authorized domains</li>
            <li>위 도메인을 추가하고 저장</li>
            <li>페이지를 새로고침하여 Google 로그인 재시도</li>
          </ol>
        </div>

        <Button
          size="sm"
          variant="outline"
          onClick={() =>
            window.open("https://console.firebase.google.com/project/gyomutime-61a6f/authentication/settings", "_blank")
          }
          className="w-full"
        >
          <ExternalLink className="h-3 w-3 mr-2" />
          Firebase Console 열기
        </Button>
      </AlertDescription>
    </Alert>
  )
}
