import Link from "next/link"
import { ArrowLeft, Shield } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link
              href="/"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>홈으로 돌아가기</span>
            </Link>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="font-semibold text-primary">개인정보처리방침</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-3xl font-bold text-foreground">개인정보처리방침</h1>
            <p className="text-muted-foreground">시간표 최적화 서비스의 개인정보 수집 및 이용에 관한 방침입니다.</p>
            <p className="text-sm text-muted-foreground">최종 업데이트: 2024년 1월 1일</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>1. 개인정보의 수집 및 이용목적</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                교무타임(이하 "회사")은 다음의 목적을 위하여 개인정보를 처리합니다. 처리하고 있는 개인정보는 다음의 목적
                이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는 경우에는 개인정보보호법 제18조에 따라 별도의
                동의를 받는 등 필요한 조치를 이행할 예정입니다.
              </p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">가. 회원가입 및 관리</h4>
                  <p className="text-muted-foreground ml-4">
                    회원 식별, 회원자격 유지·관리, 서비스 부정이용 방지, 각종 고지·통지, 고충처리 목적
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">나. 서비스 제공</h4>
                  <p className="text-muted-foreground ml-4">
                    시간표 최적화 서비스 제공, 선택과목 분반 알고리즘 서비스 제공, 맞춤형 서비스 제공
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">다. 고충처리</h4>
                  <p className="text-muted-foreground ml-4">
                    민원인의 신원 확인, 민원사항 확인, 사실조사를 위한 연락·통지, 처리결과 통보
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>2. 수집하는 개인정보의 항목</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">가. 필수항목</h4>
                  <ul className="text-muted-foreground ml-4 space-y-1">
                    <li>• 이메일 주소</li>
                    <li>• 비밀번호 (암호화 저장)</li>
                    <li>• 이름</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">나. 자동 수집 항목</h4>
                  <ul className="text-muted-foreground ml-4 space-y-1">
                    <li>• IP 주소</li>
                    <li>• 쿠키</li>
                    <li>• 서비스 이용 기록</li>
                    <li>• 접속 로그</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>3. 개인정보의 처리 및 보유기간</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 법령에 따른 개인정보 보유·이용기간 또는 정보주체로부터 개인정보를 수집 시에 동의받은 개인정보
                보유·이용기간 내에서 개인정보를 처리·보유합니다.
              </p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">가. 회원정보</h4>
                  <p className="text-muted-foreground ml-4">
                    보유기간: 회원탈퇴 시까지 (단, 관련 법령에 따라 보존이 필요한 경우 해당 기간까지)
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">나. 서비스 이용기록</h4>
                  <p className="text-muted-foreground ml-4">보유기간: 3개월 (통신비밀보호법에 따른 보존)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>4. 개인정보의 제3자 제공</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 정보주체의 개인정보를 개인정보의 수집 목적으로 명시한 범위 내에서만 처리하며, 정보주체의 동의,
                법률의 특별한 규정 등 개인정보보호법 제17조에 해당하는 경우에만 개인정보를 제3자에게 제공합니다.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>5. 개인정보처리의 위탁</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 원활한 개인정보 업무처리를 위하여 다음과 같이 개인정보 처리업무를 위탁하고 있습니다.
              </p>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-foreground">가. 클라우드 서비스</h4>
                  <p className="text-muted-foreground ml-4">
                    위탁받는 자: Firebase (Google LLC)
                    <br />
                    위탁하는 업무의 내용: 사용자 인증, 데이터베이스 관리, 파일 저장
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>6. 정보주체의 권리·의무 및 행사방법</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                정보주체는 회사에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다.
              </p>
              <ul className="space-y-2 text-foreground ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-primary">1.</span>
                  <span>개인정보 처리현황 통지요구</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">2.</span>
                  <span>개인정보 열람요구</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">3.</span>
                  <span>개인정보 정정·삭제요구</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">4.</span>
                  <span>개인정보 처리정지요구</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>7. 개인정보의 안전성 확보조치</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 개인정보보호법 제29조에 따라 다음과 같이 안전성 확보에 필요한 기술적/관리적 및 물리적 조치를 하고
                있습니다.
              </p>
              <ul className="space-y-2 text-foreground ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>개인정보 취급 직원의 최소화 및 교육</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>개인정보에 대한 접근 제한</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>개인정보의 암호화</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>해킹 등에 대비한 기술적 대책</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>개인정보처리시스템 등의 접근권한 관리</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>8. 개인정보보호책임자</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">
                회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및
                피해구제 등을 위하여 아래와 같이 개인정보보호책임자를 지정하고 있습니다.
              </p>
              <div className="bg-muted/50 p-4 rounded-lg">
                <h4 className="font-semibold text-foreground mb-2">개인정보보호책임자</h4>
                <p className="text-muted-foreground">
                  이메일: privacy@timetable.com
                  <br />
                  전화번호: 02-1234-5678
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="text-center pt-8">
            <p className="text-sm text-muted-foreground">
              개인정보 관련 문의사항이 있으시면{" "}
              <Link href="/contact" className="text-primary hover:underline">
                고객지원
              </Link>
              으로 연락해주세요.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
