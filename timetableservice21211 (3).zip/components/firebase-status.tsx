"use client"

import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle, CheckCircle, XCircle } from "lucide-react"

export function FirebaseStatus() {
  const [status, setStatus] = useState<"loading" | "connected" | "error">("loading")
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkFirebaseStatus = async () => {
      try {
        const { auth } = await import("@/lib/firebase/config")
        if (auth && typeof auth.onAuthStateChanged === "function") {
          setStatus("connected")
        } else {
          setStatus("error")
          setError("Firebase services not properly initialized")
        }
      } catch (error: any) {
        setStatus("error")
        setError(error.message)
      }
    }

    checkFirebaseStatus()
  }, [])

  if (status === "loading") {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Firebase Status</AlertTitle>
        <AlertDescription>Checking Firebase connection...</AlertDescription>
      </Alert>
    )
  }

  if (status === "error") {
    return (
      <Alert variant="destructive">
        <XCircle className="h-4 w-4" />
        <AlertTitle>Firebase Connection Error</AlertTitle>
        <AlertDescription>
          {error || "Firebase is not properly configured"}
          <br />
          <br />
          <strong>To fix this issue:</strong>
          <ol className="list-decimal list-inside mt-2 space-y-1">
            <li>Go to your Firebase Console</li>
            <li>Select your project (gyomutime-61a6f)</li>
            <li>Go to Authentication → Settings → Authorized domains</li>
            <li>Add the current domain to authorized domains</li>
            <li>For v0 preview, add: *.v0.dev</li>
          </ol>
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <Alert>
      <CheckCircle className="h-4 w-4" />
      <AlertTitle>Firebase Connected</AlertTitle>
      <AlertDescription>Firebase services are working properly</AlertDescription>
    </Alert>
  )
}
